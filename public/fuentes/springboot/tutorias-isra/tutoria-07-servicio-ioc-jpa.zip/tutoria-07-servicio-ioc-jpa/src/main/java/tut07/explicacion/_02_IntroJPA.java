package tut07.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 2: INTRODUCCIÓN A JPA — Conceptos clave antes de ver entidades
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * JPA vs JDBC vs HIBERNATE
 * ─────────────────────────
 *   JDBC    = API de bajo nivel para ejecutar SQL directamente
 *             (Connection, PreparedStatement, ResultSet...)
 *             Tú escribes el SQL, tú mapeas los ResultSet a objetos.
 *
 *   JPA     = especificación de alto nivel (jakarta.persistence)
 *             Define anotaciones y APIs para mapear clases Java a tablas.
 *             No tiene implementación propia — define el contrato.
 *
 *   Hibernate = implementación de JPA (la más usada)
 *             Genera SQL, gestiona caché, transacciones, lazy loading...
 *             Spring Boot lo usa por defecto.
 *
 *   ┌────────────────────────────────────────────────────────────┐
 *   │  Tu código (@Entity, EntityManager, @Query...)             │  ← JPA API
 *   ├────────────────────────────────────────────────────────────┤
 *   │  Hibernate                                                 │  ← implementación
 *   ├────────────────────────────────────────────────────────────┤
 *   │  JDBC                                                      │  ← bajo nivel
 *   ├────────────────────────────────────────────────────────────┤
 *   │  Driver MySQL / H2 / PostgreSQL                            │
 *   └────────────────────────────────────────────────────────────┘
 *
 *
 * EL ENTITYMANAGER — LA API CENTRAL DE JPA
 * ──────────────────────────────────────────
 * El EntityManager es el objeto que gestiona el ciclo de vida de las entidades:
 *
 *   // Guardar una nueva entidad
 *   entityManager.persist(empleado);     → INSERT INTO empleado ...
 *
 *   // Buscar por clave primaria
 *   Empleado e = entityManager.find(Empleado.class, 1L);  → SELECT * FROM empleado WHERE id=1
 *
 *   // Actualizar (la entidad es managed → Spring detecta cambios automáticamente)
 *   empleado.setNombre("Nuevo nombre");  → UPDATE al hacer commit
 *
 *   // Actualizar explícitamente
 *   entityManager.merge(empleado);       → UPDATE INTO empleado ...
 *
 *   // Eliminar
 *   entityManager.remove(empleado);      → DELETE FROM empleado WHERE id=...
 *
 *
 * PATRÓN DAO vs REPOSITORY
 * ─────────────────────────
 *   DAO (Data Access Object) — patrón clásico:
 *     Interfaz + implementación manual con EntityManager
 *     Tú escribes todos los métodos de acceso a datos
 *
 *   Repository (Spring Data JPA) — lo que usaremos:
 *     Extiende JpaRepository<Entidad, TipoId>
 *     Spring genera automáticamente: findAll, findById, save, delete...
 *     Solo declaras los métodos extras que necesitas
 *
 *   → En Spring Boot moderno: Spring Data JPA (Tut 10).
 *   → EntityManager sigue siendo útil para queries complejas.
 *
 *
 * EL CONTEXTO DE PERSISTENCIA
 * ────────────────────────────
 * El EntityManager mantiene un "contexto de persistencia":
 *   → Un espacio en memoria donde viven las entidades "managed"
 *   → Detecta cambios en las entidades managed automáticamente (dirty checking)
 *   → Al hacer commit de la transacción → sincroniza con la BBDD
 *
 * Esto es lo que hace que puedas hacer:
 *   Empleado e = em.find(Empleado.class, 1L);
 *   e.setNombre("Nuevo");  // sin llamar a merge ni save explícitamente
 *   // Al final de la transacción: Hibernate hace UPDATE automáticamente
 */
public class _02_IntroJPA {
    // Spring Data JPA (JpaRepository) se verá en Tutoría 10.
}
