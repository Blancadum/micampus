package tut07.avanzado;
/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO] @Scope("prototype"), @Lazy y @ConfigurationProperties
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * @SCOPE("prototype") — nueva instancia cada vez
 * ──────────────────────────────────────────────
 *   Por defecto los beans son singleton. Con prototype:
 *   @Service @Scope("prototype")
 *   public class CarritoCompra { private List<Item> items = new ArrayList<>(); }
 *   → Cada inyección recibe un objeto nuevo. Útil para objetos con estado por usuario.
 *
 *
 * @LAZY — inicialización diferida
 * ────────────────────────────────
 *   @Service @Lazy
 *   public class ServicioPesado { public ServicioPesado() { Thread.sleep(5000); } }
 *   → No se crea al arrancar; solo cuando se inyecta por primera vez.
 *   → Mejora tiempo de arranque pero no el tiempo de la primera petición.
 *
 *
 * @CONFIGURATIONPROPERTIES — externalizar configuración de beans
 * ───────────────────────────────────────────────────────────────
 *   En application.properties:
 *     app.nombre=MiAPI
 *     app.max-empleados=1000
 *     app.admin-email=admin@empresa.com
 *
 *   @ConfigurationProperties(prefix = "app")
 *   @Component
 *   public class AppConfig {
 *       private String nombre;
 *       private int maxEmpleados;
 *       private String adminEmail;
 *       // getters + setters
 *   }
 *
 *   → Más limpio que @Value("${app.nombre}") en cada campo.
 *   → Valida los tipos automáticamente.
 *   → Se puede usar @Validated encima para añadir Bean Validation.
 *
 *   CÓMO SE EMPAREJAN PROPIEDAD Y ATRIBUTO (relaxed binding)
 *   ─ prefix = "app" filtra las propiedades que empiezan por "app."
 *   ─ Lo que queda (max-empleados) se compara con el atributo (maxEmpleados).
 *   ─ No hace falta que se llamen igual: Spring normaliza ambos lados
 *     (quita "-" y "_" y pasa a minúsculas → "maxempleados").
 *   ─ Todas estas formas enlazan con "maxEmpleados":
 *         app.max-empleados=1000   ← kebab-case (recomendada en .properties/.yml)
 *         app.maxEmpleados=1000    ← camelCase
 *         app.max_empleados=1000   ← snake_case
 *         APP_MAXEMPLEADOS=1000    ← variable de entorno
 *   ─ Cada atributo se relaciona así:
 *         app.nombre          → String nombre
 *         app.max-empleados   → int maxEmpleados
 *         app.admin-email     → String adminEmail
 *   ─ El tipo se convierte solo: "1000" (texto) → int. Igual con boolean,
 *     Duration, List, etc.
 *
 *   CÓMO RELLENA Spring LA CLASE (necesita una de estas dos vías)
 *   ─ Setters: Spring crea el objeto con el constructor vacío y luego llama a
 *     setNombre(), setMaxEmpleados()... Sin setters los campos quedan a
 *     null/0 y NO da error.
 *   ─ Constructor (o record): los valores entran por el constructor y la clase
 *     puede ser inmutable (sin setters). Con un solo constructor Spring Boot 3
 *     lo usa solo; con varios, marca uno con @ConstructorBinding.
 *         @ConfigurationProperties(prefix = "app")
 *         public record AppConfig(String nombre, int maxEmpleados, String adminEmail) {}
 *
 *   DETALLES
 *   ─ Propiedad que no está en el archivo → el atributo conserva su valor por
 *     defecto (0, null o el que pongas: private int maxEmpleados = 50;).
 *   ─ Propiedad sin atributo en la clase → se ignora (ignoreUnknownFields).
 *   ─ @Value("${app.max-empleados}") es literal: la clave debe coincidir
 *     exacta. Solo @ConfigurationProperties aplica relaxed binding.
 */
public class _01_Scope_Lazy_ConfigProperties {}
