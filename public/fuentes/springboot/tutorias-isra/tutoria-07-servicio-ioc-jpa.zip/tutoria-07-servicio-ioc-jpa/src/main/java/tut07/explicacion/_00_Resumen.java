package tut07.explicacion;

public class _00_Resumen {
    public static void main(String[] args) {
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  TUTORÍA 7 — CAPA DE SERVICIO + IoC/DI + INTRODUCCIÓN A JPA");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println();
        System.out.println("1. CAPA DE SERVICIO — POR QUÉ EXISTE");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  El Controller gestiona HTTP. El Service gestiona LÓGICA.");
        System.out.println("  Si la lógica está en el Controller:");
        System.out.println("    → No puedes reutilizarla desde otro controller o batch job");
        System.out.println("    → No puedes testearla sin simular peticiones HTTP");
        System.out.println("    → Viola SRP (dos responsabilidades en un lugar)");
        System.out.println();
        System.out.println("  Ver: EmpleadoService (interfaz) + EmpleadoServiceImpl (lógica)");
        System.out.println("  Controller depende de la INTERFAZ → DIP en acción");
        System.out.println();
        System.out.println("2. IoC y DI EN LA PRÁCTICA");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  @Service anota la implementación → Spring la registra como bean");
        System.out.println("  El Controller declara EmpleadoService en el constructor");
        System.out.println("  Spring inyecta EmpleadoServiceImpl automáticamente");
        System.out.println();
        System.out.println("3. INTRODUCCIÓN A JPA — El puente Java↔BBDD");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  JPA = especificación   (define las reglas)");
        System.out.println("  Hibernate = implementación (ejecuta las reglas)");
        System.out.println("  EntityManager = la API que usas para persistir/recuperar objetos");
        System.out.println();
        System.out.println("  En Spring Boot 3.x, JPA + Hibernate se configuran automáticamente");
        System.out.println("  con spring-boot-starter-data-jpa + tu DataSource.");
        System.out.println("  La demo está en http://localhost:8087/api/v1/empleados");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
    }
}
