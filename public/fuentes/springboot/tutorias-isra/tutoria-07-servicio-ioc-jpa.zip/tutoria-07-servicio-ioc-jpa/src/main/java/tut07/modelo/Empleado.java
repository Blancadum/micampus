package tut07.modelo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @NoArgsConstructor @AllArgsConstructor
public class Empleado {
    private Long id;
    private String nombre;
    private String departamento;
    private Double salario;
}
