package tut07.servicio;
import tut07.modelo.Empleado;
import java.util.List;
import java.util.Optional;

/** Interfaz que define el contrato del servicio — DIP en acción. */
public interface EmpleadoService {
    List<Empleado> findAll();
    Optional<Empleado> findById(Long id);
    Empleado create(Empleado empleado);
    Optional<Empleado> update(Long id, Empleado datos);
    boolean delete(Long id);
    /** Lógica de negocio: devuelve empleados con salario > umbral. */
    List<Empleado> findBySalarioMayorQue(Double umbral);
}
