package tut07.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 1: CAPA DE SERVICIO — Patrón interfaz + implementación
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * POR QUÉ SEPARAR INTERFAZ DE IMPLEMENTACIÓN
 * ───────────────────────────────────────────
 *   // Solo con la clase concreta:
 *   @Service
 *   public class EmpleadoServiceImpl { ... }
 *
 *   @Controller
 *   EmpleadoServiceImpl service;  ← acoplado a la impl concreta
 *
 *   // Con interfaz (DIP):
 *   public interface EmpleadoService { ... }
 *
 *   @Service
 *   public class EmpleadoServiceImpl implements EmpleadoService { ... }
 *
 *   @Controller
 *   EmpleadoService service;  ← desacoplado, cualquier impl sirve
 *
 *   Ventajas:
 *   1. En tests: inyectas un mock de EmpleadoService → sin datos reales
 *   2. Si creas EmpleadoServiceCacheImpl, el Controller no cambia
 *   3. Documenta el contrato (qué puede hacer el servicio)
 *
 *
 * QUÉ VA EN EL SERVICE Y QUÉ NO
 * ───────────────────────────────
 *   ✅ EN EL SERVICE:
 *      - Lógica de negocio (calcular salario neto, filtrar por criterios...)
 *      - Validaciones de negocio (¿puede este empleado tener este salario?)
 *      - Coordinación entre repositorios
 *      - Transacciones (@Transactional)
 *
 *   ❌ NO EN EL SERVICE:
 *      - Gestión de HTTP (códigos de estado, headers...)  → eso es el Controller
 *      - Queries SQL / JPQL directas                     → eso es el Repository
 *      - Lógica de presentación (formatear JSON)         → eso son los DTOs
 *
 *
 * @SERVICE vs @COMPONENT
 * ──────────────────────
 * Técnicamente equivalentes para registrar el bean.
 * @Service comunica intención: "esta clase tiene lógica de negocio".
 * Usar siempre @Service en la capa de negocio por legibilidad.
 *
 *
 * INYECCIÓN POR CONSTRUCTOR — POR QUÉ ES LA MEJOR
 * ──────────────────────────────────────────────────
 *   public class EmpleadoController {
 *       private final EmpleadoService service;  // ← final: inmutable
 *
 *       public EmpleadoController(EmpleadoService service) {
 *           this.service = service;
 *       }
 *   }
 *
 *   → final garantiza que la dependencia nunca será null después de la construcción.
 *   → En tests: new EmpleadoController(mockService) — sin contenedor Spring.
 *   → Spring Boot: si hay UN SOLO constructor, inyecta automáticamente (sin @Autowired).
 */
public class _01_CapaServicio {
    // Ver implementación: tut07/servicio/EmpleadoService.java + EmpleadoServiceImpl.java
}
