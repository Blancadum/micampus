package tut07.explicacion;

public class Preguntas {
    public static void main(String[] args) {
        p1(); p2(); p3(); p4(); p5();
    }
    static void p1() {
        System.out.println("┌────────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P1                                                               │");
        System.out.println("└────────────────────────────────────────────────────────────────────┘");
        System.out.println("  a) Leer el header Authorization de la petición HTTP");
        System.out.println("  b) Calcular el salario neto de un empleado aplicando IRPF");
        System.out.println("  c) Serializar la respuesta a JSON");
        System.out.println("  d) Abrir la conexión a la BBDD antes de procesar cualquier petición");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) Lógica de negocio — el resto pertenece a otras capas.");
        System.out.println();
    }
    static void p2() {
        System.out.println("┌────────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P2                                                               │");
        System.out.println("└────────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Cuál es la relación correcta entre JPA e Hibernate?");
        System.out.println("  a) Son lo mismo, diferentes nombres del mismo producto");
        System.out.println("  b) Hibernate es más antiguo que JPA y lo reemplaza");
        System.out.println("  c) JPA es la especificación; Hibernate es una implementación de JPA");
        System.out.println("  d) JPA funciona sin Hibernate en Spring Boot,");
        System.out.println("     ya que ambos son intercambiables entre sí");
        System.out.println();




























































        // System.out.println("  RESPUESTA: c) JPA = contrato, Hibernate = implementación.");
        System.out.println();
    }
    static void p3() {
        System.out.println("┌────────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P3                                                               │");
        System.out.println("└────────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Cuándo usas merge() en lugar de persist()?");
        System.out.println("  a) Para entidades nuevas sin id, ya que persist() las ignoraría");
        System.out.println("  b) Para eliminar entidades");
        System.out.println("  c) merge() y persist() son equivalentes");
        System.out.println("  d) Para actualizar entidades que ya tienen id (detached)");
        System.out.println();




























































        // System.out.println("  RESPUESTA: d) merge() para entidades existentes (detached → managed).");
        System.out.println();
    }
    static void p4() {
        System.out.println("┌────────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P4                                                               │");
        System.out.println("└────────────────────────────────────────────────────────────────────┘");
        System.out.println("  Spring Boot ve un @Service con un único constructor que recibe");
        System.out.println("  EmpleadoRepository. ¿Lo inyecta automáticamente?");
        System.out.println("  a) Sí — si hay un único constructor, Spring lo inyecta solo");
        System.out.println("  b) No — siempre necesitas @Autowired");
        System.out.println("  c) Solo si el constructor es public y está anotado con @Autowired");
        System.out.println("  d) Solo si usas Lombok @RequiredArgsConstructor");
        System.out.println();




























































        // System.out.println("  RESPUESTA: a) Spring Boot: un solo constructor → inyección automática.");
        System.out.println();
    }
    static void p5() {
        System.out.println("┌────────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P5                                                               │");
        System.out.println("└────────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Cuál es la diferencia entre el patrón DAO y Spring Data JpaRepository?");
        System.out.println("  a) Son idénticos, diferente nombre");
        System.out.println("  b) JpaRepository genera automáticamente CRUD básico;");
        System.out.println("     DAO requiere implementación manual de cada método");
        System.out.println("  c) DAO usa JPA; JpaRepository usa JDBC");
        System.out.println("  d) JpaRepository no permite queries personalizadas,");
        System.out.println("     hay que usar EntityManager directamente para eso");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) JpaRepository genera el CRUD; DAO lo implementas tú.");
        System.out.println();
    }
}
