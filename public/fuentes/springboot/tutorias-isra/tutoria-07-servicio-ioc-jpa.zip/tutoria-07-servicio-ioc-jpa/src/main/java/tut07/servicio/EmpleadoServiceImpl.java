package tut07.servicio;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tut07.modelo.Empleado;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;

@Service
@Slf4j
public class EmpleadoServiceImpl implements EmpleadoService {

    private final List<Empleado> empleados = new ArrayList<>(List.of(
            new Empleado(1L, "Ana García", "IT", 42000.0),
            new Empleado(2L, "Luis Pérez", "RRHH", 35000.0),
            new Empleado(3L, "María López", "IT", 48000.0)
    ));
    private final AtomicLong seq = new AtomicLong(4);

    @Override public List<Empleado> findAll() { return empleados; }

    @Override
    public Optional<Empleado> findById(Long id) {
        return empleados.stream().filter(e -> e.getId().equals(id)).findFirst();
    }

    @Override
    public Empleado create(Empleado e) {
        e.setId(seq.getAndIncrement());
        empleados.add(e);
        log.info("Empleado creado: {}", e.getNombre());
        return e;
    }

    @Override
    public Optional<Empleado> update(Long id, Empleado datos) {
        return findById(id).map(e -> {
            e.setNombre(datos.getNombre());
            e.setDepartamento(datos.getDepartamento());
            e.setSalario(datos.getSalario());
            return e;
        });
    }

    @Override
    public boolean delete(Long id) { return empleados.removeIf(e -> e.getId().equals(id)); }

    // Lógica de negocio — esta es la razón de ser de la capa Service
    @Override
    public List<Empleado> findBySalarioMayorQue(Double umbral) {
        return empleados.stream().filter(e -> e.getSalario() > umbral).toList();
    }
}
