package tut11.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * MANEJO DE ERRORES (excepciones y respuestas de error)
 * ═══════════════════════════════════════════════════════════════════════════
 * (La parte de cómo se detectan los datos incorrectos está en _01_Validacion.java.
 *  Aquí se explica QUÉ SE DEVUELVE al cliente cuando algo falla, sea una validación,
 *  un recurso que no existe o un fallo inesperado.)
 *
 *
 * 1. EL PROBLEMA QUE RESUELVE
 * ─────────────────────────────
 *   Sin una solución centralizada, cada método del Controller trata los errores a mano:
 *
 *     @GetMapping("/{id}")
 *     public ResponseEntity<Pedido> find(@PathVariable Long id) {
 *         try {
 *             return ResponseEntity.ok(service.findById(id));
 *         } catch (NoSuchElementException e) {
 *             return ResponseEntity.notFound().build();      // 404 sin cuerpo
 *         }
 *     }
 *   → el try/catch se repite en cada método y en cada Controller,
 *   → cada desarrollador devuelve un formato distinto (texto, JSON, vacío...),
 *   → el cliente no sabe qué esperar.
 *
 *   Y si no capturas nada, Spring devuelve su respuesta por defecto (otro formato,
 *   a veces demasiado detallada o sin el mensaje).
 *
 *
 * 2. LA IDEA: LANZAR EN UN SITIO, CONTAR EN OTRO
 * ────────────────────────────────────────────────
 *   Service / Controller:  throw new PedidoNotFoundException(id);     ← solo lanzan
 *   GlobalExceptionHandler: decide el código HTTP y el JSON               ← un único sitio
 *
 *   Qué hace Spring por dentro:
 *     1. Una excepción sale de un Controller (o de lo que éste llama).
 *     2. El DispatcherServlet pregunta a sus "resolvedores de excepciones".
 *     3. Busca un @ExceptionHandler cuyo tipo encaje con la excepción:
 *          primero en el propio Controller, después en los @RestControllerAdvice.
 *     4. Ejecuta ese método; su ResponseEntity es la respuesta HTTP.
 *   Si ningún handler encaja → respuesta de error por defecto de Spring.
 *
 *
 * 3. LAS CUATRO PIEZAS
 * ──────────────────────
 *   ① Excepción propia de negocio (extiende RuntimeException):
 *        public class PedidoNotFoundException extends RuntimeException {
 *            public PedidoNotFoundException(Long id) {
 *                super("Pedido con id " + id + " no encontrado");   // el mensaje incluye el id
 *            }
 *        }
 *      ¿Por qué RuntimeException y no Exception? Porque las "unchecked" no obligan a
 *      declarar throws ni a hacer try/catch en cada capa: sube sola hasta el handler.
 *
 *   ② Estructura de la respuesta (siempre la misma):
 *        public class ErrorResponse {
 *            LocalDateTime timestamp;   // cuándo ocurrió
 *            int status;                // 404, 400, 500...
 *            String error;              // "Not Found", "Bad Request"...
 *            String message;            // texto claro para el cliente
 *            String path;               // ruta de la petición: /api/v1/pedidos/99
 *        }
 *      Nota: esta es una estructura GENÉRICA de respuesta de error, no una obligatoria: puedes
 *      elegir otros campos. Lo importante es que toda la aplicación use SIEMPRE la misma, para que
 *      el cliente sepa qué esperar sea cual sea el error.
 *
 *   ③ Clase manejadora:
 *        @RestControllerAdvice                  // vale para TODOS los controllers; devuelve JSON
 *        public class GlobalExceptionHandler {
 *
 *            @ExceptionHandler(PedidoNotFoundException.class)     // "si salta esta excepción..."
 *            public ResponseEntity<ErrorResponse> handle404(PedidoNotFoundException ex,
 *                                                           HttpServletRequest req) {
 *                ErrorResponse body = new ErrorResponse(LocalDateTime.now(), 404, "Not Found",
 *                                                       ex.getMessage(), req.getRequestURI());
 *                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(body);
 *            }
 *        }
 *      Basta UN GlobalExceptionHandler para toda la aplicación (10 controllers = 1 handler).
 *      Un Controller nuevo no obliga a tocarlo.
 *
 *   ④ Handler genérico de Exception → 500 (red de seguridad):
 *        @ExceptionHandler(Exception.class)
 *        public ResponseEntity<ErrorResponse> handle500(Exception ex, HttpServletRequest req) {
 *            // el detalle técnico se queda en el log, NO se envía al cliente
 *            log.error("Error no controlado en {}", req.getRequestURI(), ex);
 *            ... new ErrorResponse(..., 500, "Internal Server Error",
 *                                  "Error interno del servidor", req.getRequestURI()) ...
 *        }
 *      Sin este handler un fallo inesperado (BBDD caída, NullPointerException) mostraría la
 *      respuesta por defecto de Spring, con otro formato y a veces con información interna.
 *
 *
 * 3b. VARIANTES (equivalentes a lo anterior)
 * ─────────────────────────────────────────────────────────────────────
 *   • @ResponseStatus en la propia excepción: la forma "manual", sin handler, para que la
 *     excepción ya lleve su código HTTP:
 *        @ResponseStatus(HttpStatus.NOT_FOUND)
 *        public class ResourceNotFoundException extends RuntimeException { ... }
 *     Funciona, pero el cuerpo de la respuesta es el formato por defecto de Spring (con detalles
 *     que no interesan).
 *   • Excepción con mensaje construido a partir de (recurso, campo, valor):
 *        super(String.format("%s no fue encontrado con %s: '%s'", recurso, campo, valor));
 *        throw new ResourceNotFoundException("Cliente", "id", id);
 *        → "Cliente no fue encontrado con id: '5'". Sirve igual para cualquier recurso.
 *   • Lista vacía: se lanza la excepción con solo el recurso ("No hay registros de clientes").
 *     Es una decisión de diseño: muchas APIs devuelven 200 con lista vacía en vez de un 404.
 *   • Una segunda excepción propia para el 400 (BadRequestException) con @ResponseStatus(BAD_REQUEST),
 *     que se usa en los catch para no repetir códigos HTTP: catch (...) { throw new BadRequestException(msg); }
 *     y su propio @ExceptionHandler. Es la idea "una excepción por código HTTP".
 *
 * 4. CUÁL SE EJECUTA SI HAY VARIOS
 * ──────────────────────────────────
 *   Spring elige el handler MÁS ESPECÍFICO (el de la clase más cercana en la herencia).
 *   El orden en el que los escribas en la clase NO importa.
 *   Ejemplo: se lanza PedidoNotFoundException y existen handlers para
 *   PedidoNotFoundException, RuntimeException y Exception → gana PedidoNotFoundException.
 *   Por eso Exception.class puede estar siempre: solo atrapa lo que nadie más atrapó.
 *
 *
 * 5. EXCEPCIONES QUE LANZA SPRING POR SU CUENTA (y su código HTTP)
 * ──────────────────────────────────────────────────────────────────
 *   No hace falta lanzarlas tú: ocurren solas, y si no las capturas salen en el
 *   formato por defecto. Lo habitual es capturar cada una con su @ExceptionHandler:
 *
 *   Excepción                                   Código  Cuándo ocurre (ejemplo)
 *   ────────────────────────────────────────    ──────  ───────────────────────────────────────────
 *   MethodArgumentNotValidException             400     falla @Valid (nombre vacío, cantidad 0)
 *   HttpMessageNotReadableException             400     JSON mal formado o enum inexistente:
 *                                                         {"estado":"INVENTADO"}
 *   MethodArgumentTypeMismatchException         400     GET /pedidos/abc (esperaba un Long)
 *                                                         GET /pedidos?estado=XYZ (enum inválido)
 *   MissingServletRequestParameterException     400     falta un @RequestParam obligatorio
 *   PropertyReferenceException (Spring Data)    400     ?sort=campoInventado,asc
 *   NoResourceFoundException                    404     GET /api/v1/ruta-que-no-existe
 *   (EXTRAS, menos habituales: HandlerMethodValidationException 400 para parámetros sueltos,
 *    DataIntegrityViolationException 409 y HttpRequestMethodNotSupportedException 405
 *    → avanzado/_02_Manejo_Errores_Avanzado.java, que también explica el estándar ProblemDetail)
 *   Exception (cualquier otra)                  500     error no previsto
 *
 *   Y las que lanza TU código de negocio:
 *   PedidoNotFoundException                     404     el recurso que se pide no existe
 *   NoSuchElementException                      404     un "get()" de un Optional vacío o un
 *                                                         buscar-por-id de otra entidad sin excepción propia
 *   IllegalArgumentException                    400     un dato recibido es incorrecto (p. ej. el body
 *                                                         lleva el id de un cliente que no existe)
 *
 *   ⚠ Mismo "id que no existe", distinto código según de dónde viene:
 *        GET /clientes/99                 → 404  el recurso que PIDES no existe
 *        POST /pedidos {"clienteId":99}   → 400  un DATO de tu petición es inválido
 *
 *
 *
 * 5b. PLANTILLAS DE LOS HANDLERS "RAROS" (los que más cuesta escribir sin ejemplo)
 * ─────────────────────────────────────────────────────────────────────────────────
 *   Todas devuelven ResponseEntity<ErrorResponse> y reciben (excepción, HttpServletRequest req).
 *   Implementación: tut11/excepcion/GlobalExceptionHandler.java.
 *
 *   JSON ilegible / valor de enum inválido → 400 indicando el campo y el valor:
 *     @ExceptionHandler(HttpMessageNotReadableException.class)
 *     ... String msg = "El cuerpo de la petición no es un JSON válido";
 *         if (ex.getCause() instanceof InvalidFormatException ife) {       // valor que no encaja con el tipo
 *             String campo = ife.getPath().get(ife.getPath().size() - 1).getFieldName();   // Boot 3 (Jackson 2)
 *             msg = "El valor '" + ife.getValue() + "' no es válido para el campo '" + campo + "'";
 *         }
 *     En Boot 4 (Jackson 3): import tools.jackson.databind.exc.InvalidFormatException y el nombre
 *     del campo se saca con .getPropertyName() en vez de .getFieldName().
 *     (Si lo escribes con IA y no compila, casi siempre es el import del paquete de Jackson.)
 *
 *   /pedidos/abc  o  ?estado=XYZ → 400:
 *     @ExceptionHandler(MethodArgumentTypeMismatchException.class)
 *     ... "El valor '" + ex.getValue() + "' no es válido para el parámetro '" + ex.getName() + "'" ...
 *
 *   Falta un @RequestParam obligatorio → 400:
 *     @ExceptionHandler(MissingServletRequestParameterException.class)
 *     ... "Falta el parámetro obligatorio '" + ex.getParameterName() + "'" ...
 *
 *   Ruta que no existe → 404:
 *     @ExceptionHandler(NoResourceFoundException.class)
 *     ... "La ruta solicitada no existe: " + req.getRequestURI() ...
 *
 *   Campo de ordenación inexistente (?sort=campoInventado,asc) → 400. Solo existe si el proyecto
 *   usa Spring Data (la demo no lo tiene):
 *     import org.springframework.data.mapping.PropertyReferenceException;
 *     @ExceptionHandler(PropertyReferenceException.class)
 *     ... "El campo de ordenación '" + ex.getPropertyName() + "' no es válido" ...
 *     Sin este handler ese error acaba en el de Exception y sale como un 500.
 *
 *   Dato incorrecto que detecta TU lógica → 400, y recurso que no existe → 404:
 *     @ExceptionHandler(IllegalArgumentException.class)  → 400 con ex.getMessage()
 *     @ExceptionHandler(NoSuchElementException.class)    → 404 con ex.getMessage()
 *     Para que el mensaje sea claro ("Cliente con id 99 no encontrado"), el Service lanza la
 *     excepción con ese texto: throw new IllegalArgumentException("Cliente con id " + id + " no encontrado");
 *
 *
 * 6. EXTRAER LOS MENSAJES DE UNA VALIDACIÓN FALLIDA
 * ───────────────────────────────────────────────────
 *   MethodArgumentNotValidException trae todo en ex.getBindingResult():
 *
 *     @ExceptionHandler(MethodArgumentNotValidException.class)
 *     public ResponseEntity<ErrorResponse> handle400(MethodArgumentNotValidException ex, HttpServletRequest req) {
 *         StringBuilder mensajes = new StringBuilder();
 *         for (FieldError fe : ex.getBindingResult().getFieldErrors()) {      // errores de campo
 *             if (mensajes.length() > 0) mensajes.append("; ");
 *             mensajes.append(fe.getDefaultMessage());                         // el message="..." del DTO
 *         }
 *         for (ObjectError oe : ex.getBindingResult().getGlobalErrors()) {    // errores de clase (custom)
 *             if (mensajes.length() > 0) mensajes.append("; ");
 *             mensajes.append(oe.getDefaultMessage());
 *         }
 *         ... 400 con message = mensajes.toString() ...
 *     }
 *
 *   Resultado:  "message": "El nombre del cliente es obligatorio; La cantidad mínima es 1"
 *   (Es una forma de hacerlo. La demo de esta tutoría lo guarda en una lista "detalles"
 *    con "campo: mensaje", otra puede ser devolverlo como Map campo→mensaje con un forEach.
 *    Las tres formas valen; lo importante es que SIEMPRE salgan todos los mensajes.)
 *   Las validaciones a nivel de clase (anotación sobre la clase) aparecen como
 *   getGlobalErrors(), no como getFieldErrors().
 *
 *
 * 7. EJEMPLOS DE RESPUESTA (siempre el mismo formato)
 * ─────────────────────────────────────────────────────
 *   GET /api/v1/pedidos/99                     → 404
 *   { "timestamp":"2026-01-15T10:30:00", "status":404, "error":"Not Found",
 *     "message":"Pedido con id 99 no encontrado", "path":"/api/v1/pedidos/99" }
 *
 *   POST /api/v1/pedidos  {"nombreCliente":"", "cantidad":0}   → 400
 *   { ..., "status":400, "error":"Bad Request",
 *     "message":"El nombre del cliente es obligatorio; La cantidad mínima es 1", ... }
 *
 *   POST /api/v1/pedidos  {"estado":"INVENTADO"}               → 400
 *   { ..., "message":"El valor 'INVENTADO' no es válido para el campo 'estado'", ... }
 *
 *   GET /api/v1/pedidos/abc                    → 400
 *   { ..., "message":"El valor 'abc' no es válido para el parámetro 'id'", ... }
 *
 *   BBDD caída                                 → 500
 *   { ..., "status":500, "message":"Error interno del servidor", ... }   (sin stacktrace)
 *
 *
 * 8. QUÉ CÓDIGO HTTP ELEGIR (criterio rápido)
 * ─────────────────────────────────────────────
 *   400  la petición está mal: datos inválidos, JSON roto, parámetro erróneo.
 *   404  el recurso (o la ruta) no existe.
 *   409  conflicto con el estado actual (email duplicado, restricción única).
 *   500  fallo del servidor (nunca por culpa del cliente).
 *   Regla: errores del cliente → 4xx; errores del servidor → 5xx.
 *
 *
 * 9. RESPUESTA POR DEFECTO DE SPRING (cuando NO hay handler) Y SUS OPCIONES
 * ───────────────────────────────────────────────────────────────────────────
 *   Formato:  { "timestamp", "status", "error", "path" }  (y "message" solo si se activa)
 *   Opciones (application.properties):
 *      Spring Boot 4:   spring.web.error.include-message=always
 *                       spring.web.error.include-binding-errors=always   ← lista de errores de campo
 *                       spring.web.error.include-stacktrace=never
 *      Spring Boot 3:   server.error.include-message=always  (mismos nombres con "server.error.")
 *   ⚠ En Boot 4 la propiedad antigua server.error.include-message ya NO tiene efecto.
 *   Cuando tienes tu GlobalExceptionHandler estas opciones dejan de hacer falta: el mensaje
 *   lo decides tú en cada handler (por eso, al añadir el manejador, esa línea se puede quitar).
 *
 *
 * 10. NOTAS PARA SPRING BOOT 4
 * ──────────────────────────────
 *   • Jackson 3: el paquete de las clases de Jackson para excepciones es tools.jackson...
 *     Para decir "el campo estado trae un valor no válido" se usa
 *     tools.jackson.databind.exc.InvalidFormatException (está en la causa de
 *     HttpMessageNotReadableException); se importa distinto que en Boot 3 (com.fasterxml...).
 *     Para el nombre del campo: ex.getPath() → último elemento → getPropertyName().
 *   • Las anotaciones de Jackson (@JsonIgnore, @JsonProperty) siguen en com.fasterxml.jackson.annotation.
 *
 *
 * 11. ERRORES TÍPICOS
 * ─────────────────────
 *   ✗ El handler no se ejecuta → la clase no tiene @RestControllerAdvice o está fuera del
 *     paquete que escanea Spring (debe colgar del paquete de la clase @SpringBootApplication).
 *   ✗ La respuesta sale como texto plano → el método devuelve String en lugar de un objeto/ResponseEntity.
 *   ✗ Siempre sale 500 → falta el handler de la excepción concreta y cae en Exception.
 *   ✗ Se enseña el mensaje de una excepción técnica (SQL, rutas, clases) → en el handler de
 *     Exception devuelve un mensaje genérico y registra el detalle con log.error.
 *   ✗ Siguen los try/catch en los Controllers → bórralos: lanzan la excepción y ya.
 *
 *
 * ¿Y los try/catch de siempre? Siguen siendo válidos para otros usos (recuperarse, traducir,
 * limpiar recursos...): ver avanzado/_02_Manejo_Errores_Avanzado.java.
 *
 * Ver implementación: tut11/excepcion/GlobalExceptionHandler.java, ErrorResponse.java y
 * PedidoNotFoundException.java
 */
public class _02_Manejo_Errores {}
