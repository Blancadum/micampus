package tut11.avanzado;
/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO — NO OBLIGATORIO] EXTRAS DE MANEJO DE ERRORES
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 1. CON EL MANEJADOR GLOBAL, ¿YA NO HACEN FALTA LOS try/catch?
 * ───────────────────────────────────────────────────────────────
 *   Siguen siendo compatibles. Lo que cambia es PARA QUÉ se usan:
 *   el manejador global sustituye al try/catch SOLO para convertir una excepción en respuesta HTTP.
 *   Si el try/catch del Controller solo existía para elegir el código (404, 400...), sobra:
 *   la excepción sube sola hasta el @RestControllerAdvice (es lo que se quita al añadir el manejador global).
 *
 *   Cuándo SÍ sigue haciendo falta un try/catch:
 *     a) RECUPERARTE y seguir (el cliente no llega a ver el error):
 *          try { precio = servicioExterno.consultar(id); }
 *          catch (RestClientException e) { precio = PRECIO_POR_DEFECTO; }
 *     b) TRADUCIR una excepción técnica a una de negocio con un mensaje claro:
 *          try { repo.save(pedido); }
 *          catch (DataIntegrityViolationException e) { throw new EmailYaRegistradoException(email); }
 *          → el manejador global recoge después EmailYaRegistradoException.
 *     c) LIMPIAR recursos: try-with-resources (ficheros, conexiones, streams) o finally.
 *     d) PROCESAR UNA LISTA sin cortar todo: si falla un elemento, lo anotas y sigues con el resto.
 *     e) REGISTRAR contexto y RELANZAR:
 *          catch (Exception e) { log.error("Fallo al procesar el pedido {}", id, e); throw e; }
 *
 *   Dos precauciones:
 *     ✗ No tragues la excepción: un catch vacío (o que solo imprime) impide que el manejador global
 *       se entere y el cliente recibiría un 200 aunque algo haya fallado.
 *     ✗ En un método @Transactional, si capturas la excepción y no la relanzas, NO se hace rollback.
 *
 *   Regla práctica: el try/catch es para resolver o traducir el problema en el sitio donde se
 *   puede hacer algo con él; el manejador global es para contarle el resultado al cliente.
 *
 *
 * 2. ESTÁNDAR ACTUAL: ProblemDetail (RFC 9457) + ResponseEntityExceptionHandler
 * ───────────────────────────────────────────────────────────────────────────────
 *   Spring 6 / Boot 3+ incluye de serie un formato de error estándar (RFC 9457, antes 7807) y
 *   una clase base que ya maneja TODAS las excepciones habituales de Spring MVC. En vez de
 *   escribir un handler para cada una (JSON roto, tipo de parámetro, ruta inexistente, 405,
 *   validación de @Valid y de parámetros sueltos...), se hereda:
 *
 *     @RestControllerAdvice
 *     public class ProblemHandler extends ResponseEntityExceptionHandler {
 *
 *         @ExceptionHandler(PedidoNotFoundException.class)       // solo añades las TUYAS
 *         public ProblemDetail notFound(PedidoNotFoundException ex) {
 *             ProblemDetail pd = ProblemDetail.forStatusAndDetail(HttpStatus.NOT_FOUND, ex.getMessage());
 *             pd.setTitle("Pedido no encontrado");
 *             return pd;
 *         }
 *     }
 *
 *   Sin escribir ningún handler más, las respuestas salen así 
 *    (Content-Type application/problem+json):
 *     GET /pedidos/99    → {"type":"about:blank","title":"Pedido no encontrado","status":404,
 *                           "detail":"Pedido con id 99 no encontrado","instance":"/api/v1/pedidos/99"}
 *     GET /pedidos/abc   → 400 "Failed to convert 'id' with value: 'abc'"
 *     GET /zzz           → 404 "No static resource zzz."
 *     POST con @Valid inválido, o parámetro suelto con @Min inválido → 400
 *
 *   Qué cambia respecto al formato propio de la demo:
 *     • Los campos son type, title, status, detail e instance (en vez de timestamp, error, message, path);
 *       puedes añadir los tuyos con pd.setProperty("timestamp", ...).
 *     • Los textos "detail" de las excepciones de Spring salen en inglés; se traducen sobrescribiendo
 *       el método correspondiente de ResponseEntityExceptionHandler o con un messages.properties.
 *   La demo usa su propio ErrorResponse; en un proyecto nuevo es habitual
 *   usar este estándar para que cualquier cliente lo entienda sin documentación.
 *
 *
 * 3. HANDLERS EXTRA QUE SUELEN HACER FALTA CON TU PROPIO FORMATO
 * ────────────────────────────────────────────────────────────────
 *   HandlerMethodValidationException (Spring 6.1+)  → 400  parámetros sueltos con @Min, @Positive...
 *       ⚠ Sin handler, cae en el de Exception y devuelve 500 (comprobado). Ver _01_Validacion_Avanzada.java.
 *   DataIntegrityViolationException                  → 409  email duplicado, FK, restricción única
 *       @ExceptionHandler(DataIntegrityViolationException.class)
 *       public ResponseEntity<ErrorResponse> handle409(DataIntegrityViolationException ex, HttpServletRequest req) {
 *           // mensaje genérico: el texto de la excepción contiene nombres de tablas y SQL
 *           return respuesta(HttpStatus.CONFLICT, "Los datos entran en conflicto con otro registro", req, null);
 *       }
 *   HttpRequestMethodNotSupportedException           → 405  DELETE sobre una ruta que solo admite GET
 *
 *
 * 4. ERRORES QUE EL @RestControllerAdvice NO VE
 * ───────────────────────────────────────────────
 *   El manejador solo atrapa excepciones lanzadas DENTRO de Spring MVC (Controller y lo que llama).
 *   No ve los errores que ocurren antes: los filtros de Spring Security (401 sin autenticar,
 *   403 sin permiso) responden antes de que la petición llegue al Controller. Esas respuestas se
 *   configuran en la propia seguridad (AuthenticationEntryPoint / AccessDeniedHandler), no aquí.
 *
 *
 * 5. BUENAS PRÁCTICAS CON LOS MENSAJES
 * ───────────────────────────────────────
 *   • 4xx: mensaje claro para quien consume la API (qué ha hecho mal), con el id/valor problemático
 *     ("Pedido con id 99 no encontrado"): ahorra mucho tiempo de depuración.
 *   • 5xx: mensaje genérico al cliente y el detalle (stacktrace) en el log del servidor
 *     (log.error("...", ex) para que quede la traza). Nunca nombres de tablas, rutas de ficheros
 *     o clases internas en la respuesta.
 */
public class _02_Manejo_Errores_Avanzado {}
