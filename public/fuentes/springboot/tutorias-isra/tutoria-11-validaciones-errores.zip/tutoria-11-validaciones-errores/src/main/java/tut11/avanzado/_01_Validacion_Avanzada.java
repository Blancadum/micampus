package tut11.avanzado;
/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO — NO OBLIGATORIO] EXTRAS DE VALIDACIÓN
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 1. ASOCIAR EL ERROR DE UNA REGLA DE CLASE A UN CAMPO CONCRETO
 * ───────────────────────────────────────────────────────────────
 *   Por defecto el error de una anotación de clase es "global" (no pertenece a ningún campo):
 *   sale en getGlobalErrors(). Si quieres que figure como error de fechaEntrega, en el validador:
 *
 *     public boolean isValid(PedidoRequestDTO dto, ConstraintValidatorContext context) {
 *         if (dto.isUrgente() && dto.getFechaEntrega() == null) {
 *             context.disableDefaultConstraintViolation();               // quita el error global
 *             context.buildConstraintViolationWithTemplate("Un pedido urgente necesita fecha")
 *                    .addPropertyNode("fechaEntrega")                    // lo ata a ese campo
 *                    .addConstraintViolation();
 *             return false;
 *         }
 *         return true;
 *     }
 *   Resultado: en getFieldErrors() aparece  fechaEntrega: Un pedido urgente necesita fecha.
 *   Útil cuando el frontend pinta el error junto al campo concreto del formulario.
 *
 *
 * 2. VALIDAR PARÁMETROS SUELTOS (@RequestParam / @PathVariable)
 * ───────────────────────────────────────────────────────────────
 *   Las anotaciones también valen delante de los parámetros del método (Spring 6.1+ / Boot 3.2+):
 *     @GetMapping("/param")
 *     public String param(@RequestParam @Min(value = 1, message = "cantidad mínima 1") int cantidad) { ... }
 *
 *   ⚠ La excepción NO es MethodArgumentNotValidException (esa es solo para @Valid + @RequestBody):
 *   es HandlerMethodValidationException. Si no tienes un handler para ella, cae en tu handler de
 *   Exception y la respuesta es un 500 aunque el error sea del cliente (comprobado).
 *   Hay que añadir su propio handler:
 *
 *     @ExceptionHandler(HandlerMethodValidationException.class)
 *     public ResponseEntity<ErrorResponse> handle400(HandlerMethodValidationException ex, HttpServletRequest req) {
 *         List<String> detalles = new ArrayList<>();
 *         for (MessageSourceResolvable e : ex.getAllErrors()) {
 *             detalles.add(e.getDefaultMessage());               // "cantidad mínima 1"
 *         }
 *         ... 400 con esos detalles ...
 *     }
 *   (Si además la clase del Controller lleva @Validated, entra la vía antigua y la excepción
 *    pasa a ser jakarta.validation.ConstraintViolationException.)
 *
 *
 * 3. VALIDAR A MANO CON EL Validator DE SPRING
 * ──────────────────────────────────────────────
 *   Para validar un objeto fuera del Controller (en un Service, en un proceso batch, en un test)
 *   se inyecta jakarta.validation.Validator, que Spring Boot ya registra como bean:
 *
 *     private final Validator validator;                       // inyección por constructor
 *
 *     Set<ConstraintViolation<ItemDto>> errores = validator.validate(dto);
 *     for (ConstraintViolation<ItemDto> cv : errores) {
 *         System.out.println(cv.getPropertyPath() + ": " + cv.getMessage());   // cantidad: La cantidad mínima es 1
 *     }
 *   Sirve además para probar tus anotaciones propias con un test unitario sin levantar el servidor:
 *   construyes el DTO, llamas a validator.validate(dto) y compruebas que la lista tiene (o no) errores.
 *
 *
 * 4. @Valid FRENTE A @Validated
 * ───────────────────────────────
 *   Son anotaciones DISTINTAS, aunque en el caso de validar un objeto producen el mismo resultado:
 *     • @Valid  → del ESTÁNDAR (jakarta.validation): vale en cualquier proyecto Java.
 *                 Va delante del @RequestBody y sobre los campos con objetos anidados.
 *     • @Validated → de SPRING (org.springframework.validation.annotation): hace lo mismo en esos
 *                 sitios y además permite cosas propias de Spring:
 *                   a) grupos de validación: @Validated(Crear.class) para aplicar reglas distintas
 *                      al crear y al actualizar (el atributo groups de cada anotación);
 *                   b) puesta sobre un Controller o Service, activa la validación de los parámetros
 *                      sueltos de sus métodos (apartado 2 de este fichero).
 *   @Validated sobre la clase del objeto anidado (DepartmentDto): no
 *   hace falta, la validación anidada la activa el @Valid del campo. Sobre un DTO (que no es un bean
 *   de Spring) @Validated no tiene efecto.
 */
public class _01_Validacion_Avanzada {}
