package tut11.dto;

import jakarta.validation.constraints.*;
import lombok.Data;
import tut11.validacion.EntregaRequerida;

import java.time.LocalDate;

/**
 * DTO con Bean Validation. Muestra las anotaciones más comunes y una regla a nivel de clase.
 *
 * Qué rechaza cada campo (para probar en Postman):
 *   nombreCliente  → null, "", "   " y menos de 2 / más de 100 caracteres
 *   email          → null, "" y formatos como "ana.correo"
 *   cantidad       → null, 0 y mayores de 1000
 *   precioUnitario → null, 0 y negativos
 *   dniCliente     → opcional (null vale); si viene, debe cumplir el patrón
 *   estado         → opcional; si viene, debe ser NUEVO, EN_PROCESO o ENTREGADO (si no: JSON no legible → 400)
 *   fechaEntrega   → opcional; si viene, debe ser futura
 *   urgente + fechaEntrega → regla de clase: si urgente = true, la fecha de entrega es obligatoria
 */
@Data
@EntregaRequerida          // validación a nivel de CLASE (mira varios campos a la vez)
public class PedidoRequestDTO {

    @NotBlank(message = "El nombre del cliente es obligatorio")
    @Size(min = 2, max = 100, message = "El nombre debe tener entre 2 y 100 caracteres")
    private String nombreCliente;

    @NotBlank(message = "El email es obligatorio")
    @Email(message = "El email no tiene un formato válido")
    private String email;

    @NotNull(message = "La cantidad es obligatoria")
    @Min(value = 1, message = "La cantidad mínima es 1")
    @Max(value = 1000, message = "La cantidad máxima es 1000")
    private Integer cantidad;

    @NotNull(message = "El precio unitario es obligatorio")
    @Positive(message = "El precio debe ser positivo")
    private Double precioUnitario;

    @Pattern(regexp = "^[A-Z]{2}\\d{8}[A-Z]$",
             message = "El DNI debe tener formato: 2 letras + 8 dígitos + 1 letra (ej: ES12345678X)")
    private String dniCliente;  // opcional pero si se envía, debe tener formato correcto

    private EstadoPedido estado;   // opcional; un valor que no esté en el enum provoca HttpMessageNotReadableException

    private boolean urgente;       // se usa en la regla de clase @EntregaRequerida

    @Future(message = "La fecha de entrega debe ser futura")
    private LocalDate fechaEntrega;   // opcional (null vale), pero si viene debe ser futura
}
