package tut11.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * VALIDACIÓN DE DATOS DE ENTRADA (Bean Validation)
 * ═══════════════════════════════════════════════════════════════════════════
 * (La parte de qué se devuelve al cliente cuando la validación falla está en
 *  _02_Manejo_Errores.java. Aquí solo se explica CÓMO SE VALIDA.)
 *
 *
 * 1. PARA QUÉ SIRVE
 * ──────────────────
 *   El backend no puede fiarse de lo que envía el cliente (frontend, Postman, otra app).
 *   Sin validar, a la base de datos pueden llegar: null donde no toca, textos vacíos o
 *   de 5000 caracteres, emails mal escritos, cantidades negativas, fechas imposibles...
 *
 *   Se valida en el DTO de ENTRADA (PedidoRequestDTO), NO en la entidad JPA:
 *     • el DTO describe lo que la API ACEPTA; la entidad describe cómo se guarda.
 *     • el error se detecta en el Controller, antes de llegar al Service y a la BBDD.
 *
 *
 * 2. LAS TRES PIEZAS QUE HAY QUE TENER (si falta una, no valida)
 * ────────────────────────────────────────────────────────────────
 *   ① Dependencia en el pom.xml:
 *        <dependency>
 *            <groupId>org.springframework.boot</groupId>
 *            <artifactId>spring-boot-starter-validation</artifactId>
 *        </dependency>
 *      Sin ella NO COMPILAN las anotaciones (jakarta.validation.constraints.*).
 *      Ojo: con "mvn compile" a secas a veces no falla porque reutiliza clases ya
 *      compiladas; con "mvn clean compile" sí se ve el error.
 *
 *   ② Anotaciones sobre los campos del DTO:
 *        public class PedidoRequestDTO {
 *            @NotBlank(message = "El nombre del cliente es obligatorio")
 *            private String nombreCliente;
 *
 *            @Min(value = 1, message = "La cantidad mínima es 1")
 *            private Integer cantidad;
 *        }
 *
 *   ③ @Valid delante del @RequestBody en el Controller:
 *        @PostMapping
 *        public PedidoResponseDTO create(@Valid @RequestBody PedidoRequestDTO dto) { ... }
 *
 *   Sin @Valid las anotaciones del DTO son decorativas: Spring no las mira
 *   y el pedido se crearía igualmente con datos incorrectos.
 *   Va en CADA método que reciba el DTO: el POST (crear) Y el PUT (actualizar):
 *        @PutMapping("/{id}")
 *        public PedidoResponseDTO update(@PathVariable Long id, @Valid @RequestBody PedidoRequestDTO dto) { ... }
 *   Si lo olvidas en el PUT, se podrá actualizar con datos que el POST rechazaría.
 *
 *
 * 3. QUÉ PASA EXACTAMENTE CON @VALID
 * ────────────────────────────────────
 *   JSON recibido → Jackson crea el DTO → Spring llama al validador (Hibernate Validator)
 *   → recorre TODAS las anotaciones de TODOS los campos → junta TODAS las violaciones
 *      ├─ ninguna violación → se ejecuta el método del Controller con normalidad
 *      └─ alguna violación  → el método NO se ejecuta; Spring lanza
 *                              MethodArgumentNotValidException
 *                              (su BindingResult contiene la lista de errores)
 *
 *   Importante: informa de TODOS los fallos a la vez, no solo del primero.
 *   Ejemplo: {"nombreCliente":"", "cantidad":0} produce 2 errores (nombre y cantidad).
 *
 *
 * 4. CATÁLOGO DE ANOTACIONES CON EJEMPLOS (jakarta.validation.constraints)
 * ──────────────────────────────────────────────────────────────────────────
 *  Nulos y vacíos
 *   @NotNull   → distinto de null. Acepta "" y "   ".        Úsala para números, enums, fechas.
 *   @NotBlank  → String no null, no "" y no solo espacios.    Úsala para textos obligatorios.
 *   @NotEmpty  → colección/array/String con al menos 1 elemento.   (List<String> telefonos → mínimo 1)
 *
 *  Textos
 *   @Size(min=2, max=100)  → longitud entre 2 y 100 ("A" falla, "Ana" pasa).
 *   @Email                 → formato de email ("ana@correo.com" pasa, "ana.correo" falla).
 *   @Pattern(regexp="...") → cumple la expresión regular, p. ej. DNI "^[0-9]{8}[A-Z]$".
 *
 *  Números
 *   @Min(1) / @Max(1000)   → valor >= 1 / valor <= 1000.
 *   @Positive              → > 0.        @PositiveOrZero → >= 0.
 *   @Digits(integer=3, fraction=2) → como mucho 3 dígitos enteros y 2 decimales (123.45 pasa).
 *
 *  Fechas
 *   @Future / @FutureOrPresent → fecha posterior a hoy / hoy o posterior.
 *   @Past   / @PastOrPresent   → fecha anterior a hoy / hoy o anterior.
 *
 *  Booleanos
 *   @AssertTrue / @AssertFalse → debe valer true / false (p. ej. "aceptaCondiciones").
 *
 *  Otros
 *   @CreditCardNumber → comprueba el algoritmo de las tarjetas de crédito (apps bancarias; es de
 *                       Hibernate Validator, no del estándar jakarta).
 *
 *  Todas aceptan message="...": el texto que verá el cliente.
 *
 *    IMPORTANTE: casi todas consideran VÁLIDO el valor null.
 *    @Size, @Email, @Pattern, @Min, @Future... no fallan si el campo es null.
 *    Si el campo es obligatorio hay que combinar:   @NotBlank @Size(max=150)
 *                                                   @NotNull  @Future
 *    Y al revés: una fecha OPCIONAL se marca solo con @Future (null vale, 2000-01-01 no).
 *
 *
 * 5. MENSAJES PERSONALIZADOS
 * ────────────────────────────
 *   a) En la anotación:
 *        @Size(min = 2, max = 100, message = "El nombre debe tener entre 2 y 100 caracteres")
 *
 *   b) Con marcadores {min} y {max} para no repetir números:
 *        @Size(min = 2, max = 100, message = "El nombre debe tener entre {min} y {max} caracteres")
 *
 *   c) Externalizados en un fichero:
 *        application.properties →  spring.messages.basename=messages
 *        messages.properties    →  pedido.cantidad.minima=La cantidad mínima es 1
 *        DTO                    →  @Min(value = 1, message = "{pedido.cantidad.minima}")
 *      Las llaves {clave} se sustituyen por el texto del properties.
 *      Si DevTools no recarga el .properties, reinicia la aplicación.
 *
 *   Los mensajes deben estar en el idioma de tu API (en el curso: español).
 *
 *
 * 6. COMBINAR VARIAS ANOTACIONES EN UN CAMPO
 * ───────────────────────────────────────────
 *   @NotBlank(message = "El nombre es obligatorio")
 *   @Size(max = 100, message = "El nombre no puede superar 100 caracteres")
 *   private String nombre;
 *
 *   Con nombre = ""   → falla @NotBlank (el @Size sí se cumple: 0 <= 100) → 1 error.
 *   Con nombre = null → falla @NotBlank → 1 error.
 *   Con 200 letras    → falla @Size     → 1 error.
 *   Si varias fallan a la vez, se informan todas.
 *
 *
 * 7. OBJETOS ANIDADOS Y LISTAS
 * ──────────────────────────────
 *   @Valid sobre el campo para que "entre" a validar el objeto interior:
 *        public class PedidoRequestDTO {
 *            @NotNull
 *            @Valid                         // sin esto NO se validan los campos de DireccionDTO
 *            private DireccionDTO direccion;
 *
 *            @NotEmpty
 *            private List<@Valid LineaPedidoDTO> lineas;   // valida cada elemento de la lista
 *        }
 *        @Validated                          
 *        public class DireccionDTO {
 *            @NotBlank private String calle;
 *            @Size(min = 3, max = 10) private String ciudad;
 *        }
 *   En el vídeo el objeto anidado lleva además @Validated a nivel de clase.
 *   la validación anidada funciona igual solo con @Valid sobre el campo. Qué es @Validated y en qué
 *   se diferencia de @Valid: ver avanzado/_01_Validacion_Avanzada.java, apartado 4.
 *
 *
 * 8. VALIDACIONES PERSONALIZADAS (anotación propia + ConstraintValidator)
 * ───────────────────────────────────────────────────────────────────────────
 *   Cuando las anotaciones estándar no alcanzan, se crea una propia. Hay DOS casos:
 *     A) Regla sobre UN CAMPO: "el nombre debe empezar en mayúscula".
 *     B) Regla que mira VARIOS CAMPOS a la vez: "si el pedido es urgente, la fecha de entrega
 *        es obligatoria" (esta demo) · "fechaFin posterior a fechaInicio". Es una anotación
 *        sobre la CLASE.
 *
 *   Siempre son DOS piezas, conectadas con @Constraint(validatedBy = ...):
 *     ① la ANOTACIÓN (mensaje por defecto y dónde se puede usar),
 *     ② el VALIDADOR (clase aparte con la lógica en isValid()).
 *
 *   8.1 CASO A — anotación sobre un campo
 *       @Target({ElementType.FIELD, ElementType.METHOD})   // dónde se coloca
 *       @Retention(RetentionPolicy.RUNTIME)                // viva en ejecución (si no, Spring no la ve)
 *       @Documented                                        // sale en el Javadoc
 *       @Constraint(validatedBy = ValidNameValidator.class)
 *       public @interface ValidName {
 *           String message() default "{custom.validation.message}";   // clave de messages.properties
 *           Class<?>[] groups() default {};                           // obligatorio por contrato
 *           Class<? extends Payload>[] payload() default {};          // obligatorio por contrato
 *       }
 *
 *       public class ValidNameValidator implements ConstraintValidator<ValidName, String> {
 *           //                                                          anotación ↑   tipo del campo ↑
 *           @Override
 *           public boolean isValid(String value, ConstraintValidatorContext context) {
 *               if (value == null) return false;
 *               if (value.length() < 3 || value.length() > 15) return false;
 *               return Character.isUpperCase(value.charAt(0));    // true = válido, false = error
 *           }
 *       }
 *       Uso:  @ValidName private String name;
 *       Mensaje externalizado:  spring.messages.basename=messages  (application.properties)
 *                               custom.validation.message=Debe empezar en mayúscula  (messages.properties)
 *
 *   8.2 CASO B — anotación sobre la CLASE
 *       Cambian dos cosas: @Target(ElementType.TYPE) y el validador recibe el DTO COMPLETO.
 *
 *       @Constraint(validatedBy = EntregaRequeridaValidator.class)
 *       @Target(ElementType.TYPE)
 *       @Retention(RetentionPolicy.RUNTIME)
 *       public @interface EntregaRequerida {
 *           String message() default "Un pedido urgente debe tener fecha de entrega";
 *           Class<?>[] groups() default {};
 *           Class<? extends Payload>[] payload() default {};
 *       }
 *
 *       public class EntregaRequeridaValidator
 *               implements ConstraintValidator<EntregaRequerida, PedidoRequestDTO> {
 *           @Override
 *           public boolean isValid(PedidoRequestDTO dto, ConstraintValidatorContext context) {
 *               if (dto == null) return true;
 *               if (dto.isUrgente()) return dto.getFechaEntrega() != null;   // urgente exige fecha
 *               return true;                                                  // si no, no se exige nada
 *           }
 *       }
 *
 *       Uso (sobre la clase):   @Data  @EntregaRequerida  public class PedidoRequestDTO { ... }
 *       Implementación real: tut11/validacion/EntregaRequerida.java y EntregaRequeridaValidator.java.
 *
 *       NOTA — ¿Para qué se usa la validación de clase?
 *       Para reglas que dependen de varios campos a la vez, que una anotación sobre un solo campo
 *       no puede expresar. Ej.: "si es urgente, la fecha de entrega es obligatoria" o
 *       "fechaFin posterior a fechaInicio".
 *
 *   8.3 DETALLES QUE CONVIENE RECORDAR
 *       • isValid devuelve TRUE si es válido y FALSE si hay error (al revés es un fallo típico).
 *       • Con null: en reglas "opcionales" devuelve true y que @NotNull decida si es obligatorio.
 *       • Un error de CLASE aparece como error "global" (getGlobalErrors()), no ligado a un campo:
 *         el handler de errores debe leer también getGlobalErrors() (ver _02_Manejo_Errores.java).
 *       • message / groups / payload son obligatorios en la anotación (aunque no los uses):
 *         sin ellos Hibernate Validator lanza ConstraintDefinitionException al intentar validar.
 *       • El validador va en una clase aparte (no inline): reutilizable y fácil de probar.
 *       • Errores típicos: falta @Retention(RUNTIME) o @Valid → no valida; anotación de clase
 *         puesta sobre un campo → nunca se activa; tipo genérico del validador distinto del
 *         elemento anotado → ClassCastException; mensaje "{clave}" literal → falta messages.properties.
 *
 *
 * 9. (AVANZADO, no obligatorio) más detalles de validación
 * ───────────────────────────────────────────────────────────
 *   asociar el error de una regla de clase a un campo concreto, validar
 *   parámetros sueltos (@PathVariable/@RequestParam) y validar a mano con el Validator:
 *   ver avanzado/_01_Validacion_Avanzada.java.
 *
 *
 * 10. ERRORES TÍPICOS (revisa esta lista cuando "no valida")
 * ───────────────────────────────────────────────────────────
 *   ✗ No añadiste spring-boot-starter-validation → no compila.
 *   ✗ Falta @Valid en el @RequestBody → el DTO no se valida (se crea el recurso).
 *   ✗ Pusiste solo @Size/@Email/@Past en un campo obligatorio → null pasa. Añade @NotNull/@NotBlank.
 *   ✗ Usaste @NotNull en un String y esperabas rechazar "" → usa @NotBlank.
 *   ✗ Objeto anidado sin @Valid en el campo → no se valida por dentro.
 *   ✗ Las anotaciones están en la entidad y el Controller recibe el DTO → no se validan.
 *   ✗ Esperabas ver los mensajes en español en la respuesta y solo ves "Validation failed":
 *     es la respuesta por defecto de Spring; hace falta un @RestControllerAdvice que los
 *     extraiga (parte B) o activar spring.web.error.include-binding-errors=always en Boot 4
 *     (en Boot 3: server.error.include-binding-errors).
 *
 */
public class _01_Validacion {}
