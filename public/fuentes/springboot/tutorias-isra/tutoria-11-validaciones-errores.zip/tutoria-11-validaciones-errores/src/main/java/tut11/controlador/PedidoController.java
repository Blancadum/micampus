package tut11.controlador;

import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import tut11.dto.PedidoRequestDTO;
import tut11.excepcion.PedidoNotFoundException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Controller de demostración. FÍJATE: no tiene ningún try/catch. Solo lanza excepciones
 * y el GlobalExceptionHandler decide el código HTTP y el JSON.
 *
 * Qué probar y qué excepción provoca cada cosa:
 *   POST /api/v1/pedidos {"nombreCliente":""}              → MethodArgumentNotValidException (400)
 *   POST /api/v1/pedidos {"urgente":true, ...sin fecha}    → error de clase @EntregaRequerida (400)
 *   POST /api/v1/pedidos {"estado":"INVENTADO", ...}       → HttpMessageNotReadableException (400)
 *   POST /api/v1/pedidos con JSON roto: {"nombreCliente":  → HttpMessageNotReadableException (400)
 *   GET  /api/v1/pedidos/99                                → PedidoNotFoundException (404)
 *   GET  /api/v1/pedidos/abc                               → MethodArgumentTypeMismatchException (400)
 *   GET  /api/v1/pedidos/buscar            (sin ?cliente)  → MissingServletRequestParameterException (400)
 *   GET  /api/v1/ruta-que-no-existe                        → NoResourceFoundException (404)
 *   GET  /api/v1/pedidos/error                             → excepción inesperada (500)
 */
@RestController
@RequestMapping("/api/v1/pedidos")
public class PedidoController {

    private final Map<Long, PedidoRequestDTO> pedidos = new ConcurrentHashMap<>();
    private final AtomicLong seq = new AtomicLong(1);

    // @Valid activa Bean Validation sobre el @RequestBody
    @PostMapping
    public PedidoRequestDTO create(@Valid @RequestBody PedidoRequestDTO dto) {
        pedidos.put(seq.getAndIncrement(), dto);
        return dto;
    }

    @GetMapping("/{id}")
    public PedidoRequestDTO findById(@PathVariable Long id) {
        PedidoRequestDTO pedido = pedidos.get(id);
        if (pedido == null) throw new PedidoNotFoundException(id);
        return pedido;
    }

    // @RequestParam obligatorio: si falta, Spring lanza MissingServletRequestParameterException
    @GetMapping("/buscar")
    public List<PedidoRequestDTO> buscar(@RequestParam String cliente) {
        List<PedidoRequestDTO> resultado = new ArrayList<>();
        for (PedidoRequestDTO p : pedidos.values()) {
            if (p.getNombreCliente() != null && p.getNombreCliente().equalsIgnoreCase(cliente)) {
                resultado.add(p);
            }
        }
        return resultado;
    }

    // Provoca un fallo no previsto para ver el handler de Exception (500)
    @GetMapping("/error")
    public PedidoRequestDTO provocarError() {
        throw new IllegalStateException("Fallo interno que NO debe verse en la respuesta");
    }
}
