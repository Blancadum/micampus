package tut11.excepcion;

/** Excepción de negocio cuando un recurso no se encuentra. */
public class PedidoNotFoundException extends RuntimeException {
    public PedidoNotFoundException(Long id) {
        super("Pedido con id " + id + " no encontrado");
    }
}
