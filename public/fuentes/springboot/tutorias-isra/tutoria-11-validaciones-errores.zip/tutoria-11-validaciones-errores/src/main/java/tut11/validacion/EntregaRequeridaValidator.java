package tut11.validacion;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import tut11.dto.PedidoRequestDTO;

/**
 * Lógica de @EntregaRequerida. Recibe el DTO COMPLETO (no un solo campo).
 * Se ejecuta durante la validación, después de que Jackson haya creado el objeto.
 */
public class EntregaRequeridaValidator implements ConstraintValidator<EntregaRequerida, PedidoRequestDTO> {

    @Override
    public boolean isValid(PedidoRequestDTO dto, ConstraintValidatorContext context) {
        if (dto == null) {
            return true;                  // lo que sea "obligatorio" lo decide @NotNull, no esta regla
        }
        if (dto.isUrgente()) {
            return dto.getFechaEntrega() != null;   // urgente → exige fecha
        }
        return true;                      // no urgente → no se exige nada
    }
}
