package tut11;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class Tut11Application {
    public static void main(String[] args) { SpringApplication.run(Tut11Application.class, args); }
}
