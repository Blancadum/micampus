package tut11.explicacion;
public class Preguntas {
    public static void main(String[] args) { p1(); p2(); p3(); p4(); p5(); p6(); p7(); p8(); p9(); p10(); p11(); }
    // ───── PARTE A — VALIDACIÓN ─────
    static void p1() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P1                                                             │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  Campo: String nombre. ¿Qué anotación rechaza también \" \" (espacios)?");
        System.out.println("  a) @NotNull  b) @NotBlank  c) @NotEmpty  d) @NonNull");
        System.out.println();


























































        // System.out.println("  RESPUESTA: b) @NotBlank rechaza null, vacío Y solo-espacios.");
        System.out.println();
    }
    static void p2() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P2                                                             │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  Tu DTO tiene @NotBlank pero el Controller no tiene @Valid.");
        System.out.println("  ¿Qué ocurre si envías un nombre vacío?");
        System.out.println("  a) 400 Bad Request, ya que Spring rechaza cualquier campo vacío");
        System.out.println("  b) Error de compilación");
        System.out.println("  c) El pedido se crea igualmente (validación no activa)");
        System.out.println("  d) 500 Internal Server Error");
        System.out.println();


























































        // System.out.println("  RESPUESTA: c) Sin @Valid, las anotaciones son decorativas.");
        System.out.println();
    }
    static void p3() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P3                                                             │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  Campo opcional: @Size(max = 100) String observaciones. Se envía observaciones = null.");
        System.out.println("  ¿Qué ocurre al validar?");
        System.out.println("  a) Falla: todas las anotaciones de validación rechazan siempre el valor null");
        System.out.println("  b) Falla con un 500 porque @Size no sabe calcular la longitud de un valor null en tiempo de ejecución");
        System.out.println("  c) Pasa: @Size da por válido el null (para obligarlo habría que añadir @NotNull)");
        System.out.println("  d) Pasa solo si el DTO lleva además @Valid colocado sobre el propio campo");
        System.out.println();


























































        // System.out.println("  RESPUESTA: c) La mayoría de anotaciones (@Size, @Email, @Pattern, @Min...) dan por válido el null.");
        System.out.println();
    }
    static void p4() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P4                                                             │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  Quieres una regla que dependa de DOS campos del DTO (si urgente = true, fechaEntrega es obligatoria).");
        System.out.println("  ¿Qué necesitas?");
        System.out.println("  a) Una anotación propia sobre la clase y un ConstraintValidator que recibe el DTO completo");
        System.out.println("  b) Poner @NotNull en el campo fechaEntrega, porque esa anotación ya comprueba también el valor del otro campo");
        System.out.println("  c) Un @ExceptionHandler específico para fechaEntrega en el GlobalExceptionHandler");
        System.out.println("  d) Dos anotaciones estándar, una en cada campo, para que se validen entre sí");
        System.out.println();


























































        // System.out.println("  RESPUESTA: a) Una anotación sobre la CLASE: su validador recibe el DTO completo y puede comparar ambos campos.");
        System.out.println();
    }
    // ───── PARTE B — MANEJO DE ERRORES ─────
    static void p5() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P5                                                             │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  PedidoNotFoundException extiende RuntimeException, no Exception.");
        System.out.println("  ¿Por qué?");
        System.out.println("  a) No obliga a declarar throws ni a hacer try/catch en cada capa");
        System.out.println("  b) Se ejecuta más rápido que una excepción checked en runtime");
        System.out.println("  c) Spring solo es capaz de manejar excepciones de tipo RuntimeException");
        System.out.println("  d) No hay ninguna diferencia práctica entre ambas para este caso de uso");
        System.out.println();


























































        // System.out.println("  RESPUESTA: a) Unchecked exception — código más limpio sin try-catch en cascada.");
        System.out.println();
    }
    static void p6() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P6                                                             │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Cuántos GlobalExceptionHandler necesitas para 10 controllers?");
        System.out.println("  a) Uno por controller (10)  b) Uno por módulo");
        System.out.println("  c) Tantos como tipos de excepción distintos existan  d) Uno solo para toda la aplicación");
        System.out.println();


























































        // System.out.println("  RESPUESTA: d) Uno solo — @RestControllerAdvice captura de TODOS los controllers.");
        System.out.println();
    }
    static void p7() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P7                                                             │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  Tienes handler para PedidoNotFoundException y para Exception (genérica).");
        System.out.println("  Se lanza PedidoNotFoundException. ¿Cuál se ejecuta?");
        System.out.println("  a) El de Exception (más general) b) El de PedidoNotFoundException (más específico)");
        System.out.println("  c) Ambos handlers se ejecutan en el orden en que fueron declarados");
        System.out.println("  d) Depende del orden de declaración");
        System.out.println();


























































        // System.out.println("  RESPUESTA: b) Spring elige el handler más específico que coincide.");
        System.out.println();
    }
    static void p8() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P8                                                             │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  Antes de guardar un pedido hay que comprobar que su email no esté ya registrado");
        System.out.println("  (hay que consultar la base de datos). ¿Dónde va esa comprobación?");
        System.out.println("  a) Con @Email en el DTO, que además de comprobar el formato lo comprueba contra la base de datos");
        System.out.println("  b) En el GlobalExceptionHandler, justo antes de devolver la respuesta de error al cliente");
        System.out.println("  c) Con @Valid en el Controller, que consulta el repositorio por sí solo antes de llamar al Service");
        System.out.println("  d) En el Service, lanzando una excepción si ya existe");
        System.out.println();


























































        // System.out.println("  RESPUESTA: d) Es una regla de negocio que necesita datos: va en el Service y el manejador global la traduce.");
        System.out.println();
    }
    static void p9() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P9                                                             │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  GET /clientes/99 devuelve 404, pero POST /pedidos con {\"clienteId\": 99} devuelve 400.");
        System.out.println("  ¿Por qué códigos distintos?");
        System.out.println("  a) Porque Spring convierte siempre en 400 las excepciones lanzadas durante un POST");
        System.out.println("  b) En el GET falta el recurso pedido; en el POST el dato erróneo viaja dentro de la petición");
        System.out.println("  c) Porque el handler de Exception se ejecuta antes que el de NoSuchElementException");
        System.out.println("  d) Es un error del enunciado: en los dos casos debería devolverse siempre exactamente el mismo código");
        System.out.println();


























































        // System.out.println("  RESPUESTA: b) 404 = el recurso que pides no existe; 400 = un DATO de tu petición es inválido.");
        System.out.println();
    }
    static void p10() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P10                                                            │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  Un Controller tiene un try/catch que solo captura la excepción para devolver un 404.");
        System.out.println("  Ya existe el GlobalExceptionHandler. ¿Qué haces?");
        System.out.println("  a) Lo dejas: el manejador global no puede traducir excepciones lanzadas desde un Controller");
        System.out.println("  b) Lo cambias por un catch vacío para que el manejador global no se entere del fallo");
        System.out.println("  c) Lo quitas y dejas que la excepción suba hasta el manejador, que ya devuelve el 404");
        System.out.println("  d) Lo mueves al Repository, que es donde el try/catch tiene sentido");
        System.out.println();


























































        // System.out.println("  RESPUESTA: c) El try/catch que solo elige el código HTTP sobra: se lanza la excepción y el manejador responde.");
        System.out.println();
    }
    static void p11() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P11                                                            │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  En Spring Boot 4, ¿qué propiedad hace que la respuesta de error POR DEFECTO");
        System.out.println("  (sin tu GlobalExceptionHandler) incluya el mensaje de la excepción?");
        System.out.println("  a) spring.web.error.include-message=always");
        System.out.println("  b) server.error.include-message=always, igual que en Spring Boot 3");
        System.out.println("  c) spring.mvc.error.show-message=true");
        System.out.println("  d) logging.level.org.springframework.web=ERROR");
        System.out.println();


























































        // System.out.println("  RESPUESTA: a) En Boot 4 es spring.web.error.*; la antigua server.error.* ya no tiene efecto.");
        System.out.println();
    }
}
