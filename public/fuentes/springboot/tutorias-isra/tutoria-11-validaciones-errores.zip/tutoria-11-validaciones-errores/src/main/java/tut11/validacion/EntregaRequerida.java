package tut11.validacion;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Anotación de validación A NIVEL DE CLASE: un pedido urgente debe tener fecha de entrega.
 * Es la regla que mira DOS campos a la vez (urgente + fechaEntrega), por eso no vale una
 * anotación estándar sobre un solo campo.
 *
 * Los tres atributos message / groups / payload son obligatorios en cualquier anotación de validación.
 */
@Documented
@Constraint(validatedBy = EntregaRequeridaValidator.class)   // conecta la anotación con su validador
@Target(ElementType.TYPE)                                     // se coloca sobre la CLASE
@Retention(RetentionPolicy.RUNTIME)                           // disponible en ejecución
public @interface EntregaRequerida {

    String message() default "Un pedido urgente debe tener fecha de entrega";

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};
}
