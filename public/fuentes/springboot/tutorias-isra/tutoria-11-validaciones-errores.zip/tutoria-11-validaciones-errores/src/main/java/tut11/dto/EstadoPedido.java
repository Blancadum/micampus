package tut11.dto;

/** Estados posibles de un pedido. Sirve para ver el error de "valor de enum no válido" en el JSON. */
public enum EstadoPedido {
    NUEVO,
    EN_PROCESO,
    ENTREGADO
}
