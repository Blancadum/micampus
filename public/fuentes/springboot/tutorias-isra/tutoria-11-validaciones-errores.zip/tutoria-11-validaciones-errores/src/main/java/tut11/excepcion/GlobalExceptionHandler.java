package tut11.excepcion;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.resource.NoResourceFoundException;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * Manejador global de excepciones — captura errores de toda la aplicación.
 * @RestControllerAdvice = @ControllerAdvice + @ResponseBody
 *
 * Un @ExceptionHandler por tipo de excepción. Spring ejecuta el MÁS ESPECÍFICO,
 * así que el orden en que están escritos no importa y el de Exception queda como red de seguridad.
 *
 * (Nota Spring Boot 4: la clase InvalidFormatException sería tools.jackson.databind.exc.InvalidFormatException
 *  y el nombre del campo se obtendría con ex.getPath() → último elemento → getPropertyName().
 *  Esta demo usa Boot 3.3, por eso se importa de com.fasterxml.jackson.)
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /** Construye siempre la misma respuesta: así el cliente sabe qué esperar. */
    private ResponseEntity<ErrorResponse> respuesta(HttpStatus status, String mensaje, HttpServletRequest req,
                                                    List<String> detalles) {
        ErrorResponse body = new ErrorResponse(LocalDateTime.now(), status.value(), status.getReasonPhrase(),
                mensaje, req.getRequestURI(), detalles);
        return ResponseEntity.status(status).body(body);
    }

    // Excepción de negocio: pedido no encontrado → 404
    @ExceptionHandler(PedidoNotFoundException.class)
    public ResponseEntity<ErrorResponse> handlePedidoNotFound(PedidoNotFoundException ex, HttpServletRequest req) {
        return respuesta(HttpStatus.NOT_FOUND, ex.getMessage(), req, null);
    }

    // Otro recurso (categoría, tag...) no encontrado con un Optional.get() / NoSuchElementException → 404
    @ExceptionHandler(NoSuchElementException.class)
    public ResponseEntity<ErrorResponse> handleNoSuchElement(NoSuchElementException ex, HttpServletRequest req) {
        return respuesta(HttpStatus.NOT_FOUND, ex.getMessage(), req, null);
    }

    // Bean Validation falló (@Valid) → 400 con todos los mensajes de error
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidation(MethodArgumentNotValidException ex, HttpServletRequest req) {
        List<String> detalles = new ArrayList<>();
        for (FieldError fe : ex.getBindingResult().getFieldErrors()) {      // errores de un campo
            detalles.add(fe.getField() + ": " + fe.getDefaultMessage());
        }
        for (ObjectError oe : ex.getBindingResult().getGlobalErrors()) {    // errores de clase (@EntregaRequerida)
            detalles.add(oe.getDefaultMessage());
        }
        return respuesta(HttpStatus.BAD_REQUEST, "Error de validación", req, detalles);
    }

    // JSON mal formado o valor que no existe en un enum → 400
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErrorResponse> handleNotReadable(HttpMessageNotReadableException ex, HttpServletRequest req) {
        String mensaje = "El cuerpo de la petición no es un JSON válido";
        if (ex.getCause() instanceof InvalidFormatException) {
            InvalidFormatException ife = (InvalidFormatException) ex.getCause();
            String campo = ife.getPath().isEmpty() ? "desconocido" : ife.getPath().get(ife.getPath().size() - 1).getFieldName();
            mensaje = "El valor '" + ife.getValue() + "' no es válido para el campo '" + campo + "'";
        }
        return respuesta(HttpStatus.BAD_REQUEST, mensaje, req, null);
    }

    // Dato de entrada incorrecto detectado por la lógica (p. ej. id de categoría inexistente en el body) → 400
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ErrorResponse> handleIllegalArgument(IllegalArgumentException ex, HttpServletRequest req) {
        return respuesta(HttpStatus.BAD_REQUEST, ex.getMessage(), req, null);
    }

    // /pedidos/abc cuando se esperaba un número, o ?estado=XYZ en un enum → 400
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ErrorResponse> handleTypeMismatch(MethodArgumentTypeMismatchException ex, HttpServletRequest req) {
        return respuesta(HttpStatus.BAD_REQUEST,
                "El valor '" + ex.getValue() + "' no es válido para el parámetro '" + ex.getName() + "'", req, null);
    }

    // Falta un @RequestParam obligatorio → 400
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<ErrorResponse> handleMissingParam(MissingServletRequestParameterException ex, HttpServletRequest req) {
        return respuesta(HttpStatus.BAD_REQUEST, "Falta el parámetro obligatorio '" + ex.getParameterName() + "'", req, null);
    }

    // Ruta inexistente → 404
    @ExceptionHandler(NoResourceFoundException.class)
    public ResponseEntity<ErrorResponse> handleNoResource(NoResourceFoundException ex, HttpServletRequest req) {
        return respuesta(HttpStatus.NOT_FOUND, "La ruta solicitada no existe: " + req.getRequestURI(), req, null);
    }

    // Cualquier otro error no controlado → 500. El detalle va al LOG, no al cliente.
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneral(Exception ex, HttpServletRequest req) {
        log.error("Error no controlado en {}", req.getRequestURI(), ex);
        return respuesta(HttpStatus.INTERNAL_SERVER_ERROR, "Error interno del servidor", req, null);
    }
}
