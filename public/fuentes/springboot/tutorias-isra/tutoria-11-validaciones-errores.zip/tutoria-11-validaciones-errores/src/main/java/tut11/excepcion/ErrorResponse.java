package tut11.excepcion;

import lombok.AllArgsConstructor;
import lombok.Data;
import java.time.LocalDateTime;
import java.util.List;

/** Estructura estándar de respuesta de error para toda la API. */
@Data @AllArgsConstructor
public class ErrorResponse {
    private LocalDateTime timestamp;
    private int status;
    private String error;
    private String message;
    private String path;
    private List<String> detalles;  // mensajes de validación individuales (puede ser null)
}
