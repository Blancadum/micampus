package tut05.controlador;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tut05.modelo.Libro;
import tut05.servicio.LibroService;

import java.util.List;

/**
 * Capa Controlador: solo gestiona HTTP.
 * No contiene lógica de negocio — delega todo al servicio.
 */
@RestController
@RequestMapping("/api/v1/libros")
public class LibroController {

    // Inyección por constructor (recomendada) — campo final
    private final LibroService libroService;

    public LibroController(LibroService libroService) {
        this.libroService = libroService;
    }

    /** GET /api/v1/libros → 200 + lista de libros */
    @GetMapping
    public ResponseEntity<List<Libro>> findAll() {
        return ResponseEntity.ok(libroService.findAll());
    }

    /** GET /api/v1/libros/{id} → 200 + libro / 404 si no existe */
    @GetMapping("/{id}")
    public ResponseEntity<Libro> findById(@PathVariable Long id) {
        Libro libro = libroService.findById(id);
        if (libro == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(libro);
    }
}
