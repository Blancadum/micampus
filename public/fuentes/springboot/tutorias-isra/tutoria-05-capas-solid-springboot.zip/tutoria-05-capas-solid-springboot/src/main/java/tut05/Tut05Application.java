package tut05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Punto de entrada de la aplicación de demo de la Tutoría 5.
 * Arrancar con: mvn spring-boot:run  o ejecutar este main.
 *
 * URLs disponibles una vez arrancada:
 *   http://localhost:8085/api/v1/libros
 *   http://localhost:8085/api/v1/libros/{id}
 *   http://localhost:8085/actuator/health
 *   http://localhost:8085/actuator/info
 *   http://localhost:8085/actuator/beans
 */
@SpringBootApplication
public class Tut05Application {
    public static void main(String[] args) {
        SpringApplication.run(Tut05Application.class, args);
    }
}
