package tut05.modelo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Modelo de demo: Libro.
 * Sin anotaciones JPA todavía — solo un POJO Lombok.
 * Los datos se guardan en memoria (lista en el servicio).
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Libro {
    private Long id;
    private String titulo;
    private String autor;
    private Double precio;
}
