package tut05.servicio;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tut05.modelo.Libro;

import java.util.ArrayList;
import java.util.List;

/** Implementación en memoria del servicio de libros. */
@Service
@Slf4j
public class LibroServiceImpl implements LibroService {

    // Datos en memoria — sin BBDD todavía
    private final List<Libro> libros = new ArrayList<>(List.of(
            new Libro(1L, "Clean Code", "Robert C. Martin", 29.99),
            new Libro(2L, "The Pragmatic Programmer", "David Thomas", 35.50),
            new Libro(3L, "Design Patterns", "Gang of Four", 45.00)
    ));

    @Override
    public List<Libro> findAll() {
        log.info("findAll: {} libros disponibles", libros.size());
        return libros;
    }

    @Override
    public Libro findById(Long id) {
        log.info("findById: buscando libro con id={}", id);
        return libros.stream()
                .filter(l -> l.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
}
