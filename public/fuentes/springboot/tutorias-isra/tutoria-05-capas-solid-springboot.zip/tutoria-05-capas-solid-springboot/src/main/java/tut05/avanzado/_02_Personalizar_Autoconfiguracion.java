package tut05.avanzado;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO] PERSONALIZAR LA AUTOCONFIGURACIÓN — cuando application.properties no basta
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * ⚠️ Contenido extra — no entra en el temario estándar del curso.
 *
 * Ya sabes configurar Spring de las 3 formas clásicas (tut04): XML,
 * clase @Configuration + @Bean, y @Component + @ComponentScan.
 * Esto no añade una 4ª forma nueva — explica cómo esas mismas 3 formas
 * conviven con la autoconfiguración de Spring Boot, y qué hacer cuando
 * necesitas algo que application.properties no expone como clave.
 *
 *
 * LA AUTOCONFIGURACIÓN NO ES MAGIA, ES @CONFIGURATION + @BEAN
 * ───────────────────────────────────────────────────────────────
 * Cuando añades spring-boot-starter-web, dentro del .jar de Spring Boot
 * hay una clase parecida a esta (simplificada, la real es más larga):
 *
 *   @Configuration
 *   @ConditionalOnClass(Servlet.class)                       // solo si Tomcat está en el classpath
 *   @ConditionalOnMissingBean(TomcatServletWebServerFactory.class)  // solo si TÚ no has creado ya el tuyo
 *   public class TomcatAutoConfiguration {
 *       @Bean
 *       public TomcatServletWebServerFactory tomcatFactory() { ... }
 *   }
 *
 * Es exactamente la Opción 2 de tut04 (clase @Configuration + @Bean),
 * solo que la escribió el equipo de Spring y viene ya compilada dentro
 * de spring-boot-autoconfigure.jar. application.properties solo sirve
 * para rellenar los valores que esas clases han decidido leer
 * (server.port, spring.datasource.url...). Si necesitas algo que esas
 * clases no expusieron como propiedad, no hay ninguna clave mágica
 * para eso — hay que volver a la Opción 2 de siempre.
 *
 *
 * LA PIEZA CLAVE: @CONDITIONALONMISSINGBEAN
 * ─────────────────────────────────────────────
 * Las clases de autoconfiguración se retiran solas en cuanto detectan
 * que TÚ ya has definido un bean del mismo tipo. No hay que desactivar
 * nada ni pelearte con Spring Boot — solo declara tu propio @Bean:
 *
 *   @Configuration
 *   public class JacksonConfig {
 *       @Bean
 *       public ObjectMapper objectMapper() {
 *           return new ObjectMapper()
 *               .registerModule(new JavaTimeModule())
 *               .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
 *       }
 *   }
 *
 *   → Spring Boot iba a crear su propio ObjectMapper por defecto.
 *   → Al ver que ya existe uno tuyo, JacksonAutoConfiguration cede el paso.
 *   → A partir de aquí, TODO el proyecto (Jackson en los @RestController
 *     incluidos) usa tu ObjectMapper, sin tocar ni un @RestController.
 *
 *
 * EJEMPLOS REALES QUE TE VAS A ENCONTRAR EN CUALQUIER PROYECTO
 * ────────────────────────────────────────────────────────────────
 *
 *   1. CORS (típico en cuanto el frontend vive en otro puerto/dominio):
 *
 *      @Configuration
 *      public class CorsConfig implements WebMvcConfigurer {
 *          @Override
 *          public void addCorsMappings(CorsRegistry registry) {
 *              registry.addMapping("/api/**")
 *                      .allowedOrigins("http://localhost:4200")
 *                      .allowedMethods("GET", "POST", "PUT", "DELETE");
 *          }
 *      }
 *
 *   2. Un bean de librería externa que no puedes anotar tú
 *      (no es tuya la clase, no le puedes poner @Component):
 *
 *      @Configuration
 *      public class ClienteHttpConfig {
 *          @Bean
 *          public RestTemplate restTemplate(RestTemplateBuilder builder) {
 *              return builder
 *                  .setConnectTimeout(Duration.ofSeconds(3))
 *                  .setReadTimeout(Duration.ofSeconds(5))
 *                  .build();
 *          }
 *      }
 *
 *   3. Sobrescribir la cadena de seguridad por defecto (verás esto en Tut 15):
 *
 *      @Configuration
 *      public class SecurityConfig {
 *          @Bean
 *          public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
 *              return http
 *                  .csrf(csrf -> csrf.disable())
 *                  .authorizeHttpRequests(auth -> auth.anyRequest().authenticated())
 *                  .build();
 *          }
 *      }
 *
 *      → spring-boot-starter-security trae una SecurityFilterChain por
 *        defecto (pide login a TODO). En cuanto declaras la tuya con
 *        @Bean, la de Spring Boot se retira — otra vez @ConditionalOnMissingBean.
 *
 *
 * CÓMO SABER QUÉ HA AUTOCONFIGURADO SPRING BOOT (PARA NO ADIVINAR)
 * ──────────────────────────────────────────────────────────────────
 *   Arrancando con --debug (o "debug=true" en application.properties)
 *   Spring Boot imprime el "CONDITIONS EVALUATION REPORT": qué
 *   autoconfiguraciones se aplicaron y cuáles se descartaron, y por qué.
 *
 *   También puedes consultarlo en caliente si tienes Actuator (Tut05
 *   avanzado 01): GET /actuator/beans lista todos los beans activos,
 *   incluidos los que trajo la autoconfiguración.
 *
 *
 * RESUMEN EN UNA FRASE
 * ───────────────────────
 *   Spring Boot no reemplaza las 3 formas de configurar Spring — las usa
 *   internamente para darte defaults razonables, y tú recuperas el control
 *   total con una clase @Configuration en cuanto ese default no te sirve.
 */
public class _02_Personalizar_Autoconfiguracion {
    // Contenido avanzado — referencia conceptual.
}
