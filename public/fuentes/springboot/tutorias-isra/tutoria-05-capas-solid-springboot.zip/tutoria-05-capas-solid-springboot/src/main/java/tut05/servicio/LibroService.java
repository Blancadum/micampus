package tut05.servicio;

import tut05.modelo.Libro;
import java.util.List;

/** Interfaz que define qué puede hacer el servicio de libros. */
public interface LibroService {
    List<Libro> findAll();
    Libro findById(Long id);
}
