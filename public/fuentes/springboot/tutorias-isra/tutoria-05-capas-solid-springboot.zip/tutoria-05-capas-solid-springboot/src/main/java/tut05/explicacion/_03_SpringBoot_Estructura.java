package tut05.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 3: SPRING BOOT — Qué hay dentro de @SpringBootApplication
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *
 * SPRING FRAMEWORK vs SPRING BOOT
 * ─────────────────────────────────
 *
 *   Spring Framework:
 *   → Potente y flexible, pero requiere configuración manual.
 *   → Hay que configurar Tomcat, el DataSource, Jackson, Security...
 *   → Un proyecto nuevo puede requerir 300-500 líneas de config XML/Java.
 *
 *   Spring Boot:
 *   → Toma Spring Framework y añade AUTOCONFIGURACIÓN.
 *   → Detecta qué dependencias tienes y configura todo automáticamente.
 *   → Tomcat embebido → un .jar ejecutable.
 *   → Zero config para empezar.
 *
 *   Un proyecto Spring Boot es Spring Framework + convenciones + autoconfig.
 *   NO son tecnologías distintas: Spring Boot ES Spring Framework simplificado.
 *
 *
 * @SpringBootApplication — LO QUE HAY DENTRO
 * ────────────────────────────────────────────
 *
 *   @SpringBootApplication ≡ tres anotaciones en una:
 *
 *   ┌─────────────────────────────────────────────────────────────┐
 *   │  @SpringBootApplication                                     │
 *   │  = @Configuration                                           │
 *   │  + @ComponentScan(basePackages = "tut05")                   │
 *   │  + @EnableAutoConfiguration                                 │
 *   └─────────────────────────────────────────────────────────────┘
 *
 *   @Configuration:         esta clase puede definir @Bean
 *   @ComponentScan:         busca @Component/@Service/@Repository en el paquete y sub-paquetes
 *   @EnableAutoConfiguration: detecta las dependencias del classpath y configura automáticamente
 *
 *   Ejemplo de autoconfiguración:
 *   → si tienes spring-boot-starter-web → configura Tomcat, DispatcherServlet, Jackson
 *   → si añades spring-boot-starter-data-jpa → configura DataSource, EntityManager, JPA
 *   → si añades spring-boot-starter-security → activa Spring Security con defaults
 *
 *
 * EL MÉTODO MAIN Y SpringApplication.run()
 * ─────────────────────────────────────────
 *
 *   @SpringBootApplication
 *   public class Tut05Application {
 *       public static void main(String[] args) {
 *           SpringApplication.run(Tut05Application.class, args);
 *       }
 *   }
 *
 *   SpringApplication.run() hace en orden:
 *   1. Crea el ApplicationContext (contenedor IoC)
 *   2. Ejecuta la autoconfiguración (configura Tomcat, Jackson...)
 *   3. Ejecuta el @ComponentScan (registra todos los beans)
 *   4. Inyecta dependencias entre los beans
 *   5. Arranca el servidor Tomcat embebido
 *   6. La app está lista para recibir peticiones
 *
 *
 * SPRING INITIALIZR — CÓMO CREAR UN PROYECTO
 * ─────────────────────────────────────────────
 * https://start.spring.io
 *
 *   Opciones a elegir:
 *   → Project:      Maven
 *   → Language:     Java
 *   → Spring Boot:  3.x (la versión más reciente estable)
 *   → Group:        com.empresa
 *   → Artifact:     mi-api
 *   → Java:         17
 *   → Dependencies: Spring Web, Lombok, Spring Boot DevTools
 *
 *   → Generate → descarga un .zip listo para abrir en VS Code
 *
 *   También desde VS Code: Ctrl+Shift+P → "Spring Initializr: Create Maven Project"
 *   (requiere la extensión "Spring Initializr Java Support")
 *
 *
 * ESTRUCTURA QUE GENERA INITIALIZR
 * ──────────────────────────────────
 *
 *   mi-api/
 *   ├── pom.xml                           ← parent spring-boot-starter-parent
 *   ├── mvnw / mvnw.cmd                   ← Maven Wrapper
 *   └── src/
 *       ├── main/
 *       │   ├── java/com/empresa/MiApiApplication.java  ← @SpringBootApplication
 *       │   └── resources/
 *       │       └── application.properties              ← configuración vacía
 *       └── test/
 *           └── java/com/empresa/MiApiApplicationTests.java  ← test de contexto
 *
 *
 * application.properties — CONFIGURACIÓN DE LA APP
 * ──────────────────────────────────────────────────
 *   # Puerto del servidor (por defecto: 8080)
 *   server.port=8085
 *
 *   # Nombre de la aplicación (aparece en logs)
 *   spring.application.name=mi-api
 *
 *   # Conexión a BBDD (se añade en Tut 8)
 *   # spring.datasource.url=jdbc:mysql://localhost:3306/mibbdd
 *
 *   # Formato de fechas en JSON
 *   # spring.jackson.serialization.write-dates-as-timestamps=false
 */
public class _03_SpringBoot_Estructura {
    // Ver la app arrancable: Tut05Application.java + application.properties
}
