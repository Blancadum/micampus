package tut05.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 1: ARQUITECTURA POR CAPAS EN SPRING BOOT
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *
 * CÓMO SE MAPEAN LAS 3 CAPAS A SPRING BOOT
 * ──────────────────────────────────────────
 *
 *   ┌──────────────────────────────────────────────────────────────┐
 *   │  Capa Presentación → @RestController                         │
 *   │  Responsabilidad: gestionar HTTP (request/response).         │
 *   │  NO tiene lógica de negocio. Delega todo al Service.         │
 *   │                                                              │
 *   │  package tut05.controlador;                                  │
 *   │  @RestController                                             │
 *   │  public class LibroController { ... }                        │
 *   └─────────────────────┬────────────────────────────────────────┘
 *                         │ llama a ↓
 *   ┌─────────────────────▼────────────────────────────────────────┐
 *   │  Capa Negocio → @Service                                     │
 *   │  Responsabilidad: lógica de negocio, validaciones, reglas.   │
 *   │  NO sabe de HTTP. NO sabe de BBDD directamente.              │
 *   │                                                              │
 *   │  package tut05.servicio;                                     │
 *   │  @Service                                                    │
 *   │  public class LibroServiceImpl implements LibroService { ... }│
 *   └─────────────────────┬────────────────────────────────────────┘
 *                         │ llama a ↓
 *   ┌─────────────────────▼────────────────────────────────────────┐
 *   │  Capa Datos → @Repository                                    │
 *   │  Responsabilidad: acceso y persistencia de datos.            │
 *   │  En este demo: datos en memoria (se añade JPA en Tut 8-10).  │
 *   │                                                              │
 *   │  package tut05.repositorio;  (lo veremos en Tut 8-10)        │
 *   │  @Repository / JpaRepository                                 │
 *   └──────────────────────────────────────────────────────────────┘
 *
 *
 * ESTRUCTURA DE PAQUETES RECOMENDADA
 * ────────────────────────────────────
 *
 *   com.empresa.miapp/
 *   ├── MiappApplication.java     ← clase main (@SpringBootApplication)
 *   ├── modelo/                   ← clases POJO / entidades (sin lógica)
 *   ├── controlador/              ← @RestController
 *   ├── servicio/                 ← interfaz @Service + @ServiceImpl
 *   ├── repositorio/              ← @Repository / JpaRepository
 *   ├── dto/                      ← Data Transfer Objects (Tut 12)
 *   ├── excepcion/                ← excepciones custom (Tut 13)
 *   └── config/                   ← @Configuration clases (seguridad, etc.)
 *
 *   Esta estructura es visible en la demo: tut05/ con modelo/, controlador/, servicio/
 *
 *
 * POR QUÉ SEPARAR EN CAPAS
 * ──────────────────────────
 *
 *   MANTENIBILIDAD:
 *   → Si cambia el framework HTTP (de Spring a Quarkus), solo cambia controlador/.
 *   → Si cambia la BBDD, solo cambia repositorio/.
 *   → La lógica en servicio/ no se toca.
 *
 *   TESTEABILIDAD:
 *   → Puedes testear servicio/ con un repositorio falso (mock).
 *   → Puedes testear controlador/ con un servicio falso.
 *   → Puedes testear repositorio/ contra H2 sin HTTP ni servicio.
 *
 *   TRABAJO EN EQUIPO:
 *   → El desarrollador A trabaja en controlador/, el B en servicio/.
 *   → Siempre que respeten la interfaz entre capas, no se bloquean.
 *
 *
 * LA INTERFAZ ENTRE CAPAS
 * ────────────────────────
 * El Controller NO depende de LibroServiceImpl.
 * El Controller depende de la INTERFAZ LibroService.
 *
 *   // LibroController.java
 *   private final LibroService libroService;  // ← interfaz, no la impl concreta
 *
 *   public LibroController(LibroService libroService) {  // Spring inyecta la impl
 *       this.libroService = libroService;
 *   }
 *
 * → Si mañana hay LibroServiceV2Impl, el Controller no cambia.
 * → Esto es el principio DIP de SOLID en acción.
 */
public class _01_ArquitecturaPorCapas {
    // Ver la implementación en: tut05/controlador/ + tut05/servicio/ + tut05/modelo/
}
