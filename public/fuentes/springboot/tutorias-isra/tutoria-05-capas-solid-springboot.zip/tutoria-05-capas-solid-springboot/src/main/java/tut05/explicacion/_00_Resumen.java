package tut05.explicacion;

/**
 * Ejecuta esta clase para ver el mapa conceptual de la Tutoría 5.
 * La app de demo arranca con Tut05Application.java (puerto 8085).
 */
public class _00_Resumen {

    public static void main(String[] args) {

        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  TUTORÍA 5 — CAPAS + SOLID + INTRODUCCIÓN A SPRING BOOT");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println();

        System.out.println("1. ARQUITECTURA POR CAPAS EN SPRING BOOT");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  @RestController  → Capa Presentación: recibe HTTP, devuelve JSON");
        System.out.println("  @Service         → Capa Negocio: lógica, validaciones, reglas");
        System.out.println("  @Repository      → Capa Datos: acceso a BBDD (JPA/Spring Data)");
        System.out.println();
        System.out.println("  Regla: cada capa solo habla con la de abajo. NUNCA al revés.");
        System.out.println("  Demo: tut05/controlador/ → servicio/ → (datos: en memoria ahora)");
        System.out.println();

        System.out.println("2. SOLID — Los 5 principios (los más relevantes para Spring Boot)");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  S — SRP: cada clase UNA sola responsabilidad");
        System.out.println("  O — OCP: abierto a extensión, cerrado a modificación");
        System.out.println("  L — LSP: una subclase debe poder sustituir a su padre");
        System.out.println("  I — ISP: interfaces pequeñas y específicas");
        System.out.println("  D — DIP: depender de abstracciones (interfaces), no implementaciones");
        System.out.println();
        System.out.println("  → LibroService (interfaz) + LibroServiceImpl (implementación)");
        System.out.println("    es DIP en acción: el Controller depende de la interfaz.");
        System.out.println();

        System.out.println("3. SPRING BOOT VS SPRING FRAMEWORK");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  Spring Framework: potente, pero requires mucha configuración manual");
        System.out.println("  Spring Boot:      Spring Framework + autoconfiguración + Tomcat embebido");
        System.out.println();
        System.out.println("  @SpringBootApplication = @Configuration + @ComponentScan + @EnableAutoConfiguration");
        System.out.println();
        System.out.println("  Arrancar: mvn spring-boot:run  →  http://localhost:8085/api/v1/libros");
        System.out.println();

        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  App arrancable: Tut05Application.java (puerto 8085)");
        System.out.println("  Preguntas: Preguntas.java");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
    }
}
