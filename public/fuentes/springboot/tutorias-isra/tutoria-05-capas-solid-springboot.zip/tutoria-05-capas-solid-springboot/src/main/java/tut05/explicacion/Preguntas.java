package tut05.explicacion;

/**
 * TEST DE 6 PREGUNTAS — TUTORÍA 5: CAPAS + SOLID + SPRING BOOT
 */
public class Preguntas {

    public static void main(String[] args) {
        pregunta1();
        pregunta2();
        pregunta3();
        pregunta4();
        pregunta5();
        pregunta6();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta1() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 1                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  @SpringBootApplication es equivalente a combinar:");
        System.out.println();
        System.out.println("  a) @Component + @Service + @Repository");
        System.out.println("  b) @Controller + @Service + @Autowired");
        System.out.println("  c) @Configuration + @ComponentScan + @EnableAutoConfiguration");
        System.out.println("  d) @Bean + @Scope + @Primary");
        System.out.println();




























































        // System.out.println("  RESPUESTA: c)");
        // System.out.println("  → @Configuration: puede definir @Bean");
        // System.out.println("    @ComponentScan: busca @Component/@Service/... en el paquete");
        // System.out.println("    @EnableAutoConfiguration: configura Tomcat, Jackson, etc. automáticamente");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta2() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 2                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  Un @RestController contiene la lógica de cálculo de descuentos.");
        System.out.println("  ¿Qué principio SOLID viola?");
        System.out.println();
        System.out.println("  a) OCP — Open/Closed Principle");
        System.out.println("  b) LSP — Liskov Substitution Principle");
        System.out.println("  c) ISP — Interface Segregation Principle");
        System.out.println("  d) SRP — Single Responsibility Principle");
        System.out.println();




























































        // System.out.println("  RESPUESTA: d) SRP");
        // System.out.println("  → El Controller tiene 2 responsabilidades: gestionar HTTP Y calcular descuentos.");
        // System.out.println("    La lógica de negocio debe ir en @Service.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta3() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 3                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  LibroController inyecta LibroService (interfaz).");
        System.out.println("  ¿Qué ventaja concreta da esto?");
        System.out.println();
        System.out.println("  a) En tests se puede inyectar un mock de LibroService");
        System.out.println("     sin arrancar la app completa");
        System.out.println("  b) El Controller puede llamar directamente a la BBDD");
        System.out.println("     sin pasar por el Service, ahorrando una capa");
        System.out.println("  c) Se reduce el número de beans en el contexto");
        System.out.println("  d) No es necesario el @Service en la implementación");
        System.out.println();




























































        // System.out.println("  RESPUESTA: a) Testabilidad con mock");
        // System.out.println("  → Si el Controller dependiera de LibroServiceImpl, el test");
        // System.out.println("    necesitaría una BBDD real. Con la interfaz, basta un mock.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta4() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 4                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  ¿Por qué Spring Boot no necesita instalar Tomcat por separado?");
        System.out.println();
        System.out.println("  a) Spring Boot usa su propio servidor HTTP, no Tomcat");
        System.out.println("  b) Tomcat está embebido dentro del .jar gracias al starter-web");
        System.out.println("  c) Spring Boot solo funciona en la nube, no necesita servidor");
        System.out.println("  d) Hay que configurar Tomcat manualmente en application.properties");
        System.out.println("     antes de poder arrancar la aplicación desde el .jar");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) Tomcat embebido en el .jar");
        // System.out.println("  → spring-boot-starter-web incluye spring-boot-starter-tomcat.");
        // System.out.println("    java -jar mi-app.jar es suficiente para arrancar el servidor.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta5() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 5                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  Tu @SpringBootApplication está en 'com.empresa.miapp'.");
        System.out.println("  Tienes un @Service en 'com.empresa.utilidades'.");
        System.out.println("  Spring Boot NO detecta ese servicio. ¿Por qué?");
        System.out.println();
        System.out.println("  a) @Service no es compatible con @ComponentScan");
        System.out.println("  b) Hay que añadir manualmente el paquete 'utilidades'");
        System.out.println("     dentro de application.properties");
        System.out.println("  c) @ComponentScan escanea el paquete de la clase main");
        System.out.println("     y sus sub-paquetes. 'utilidades' no es sub-paquete de 'miapp'");
        System.out.println("  d) Los beans deben estar en el mismo fichero que Application");
        System.out.println();




























































        // System.out.println("  RESPUESTA: c)");
        // System.out.println("  → @ComponentScan(basePackages) escanea el paquete de la clase main");
        // System.out.println("    y todos sus hijos. 'com.empresa.utilidades' no es hijo de 'com.empresa.miapp'.");
        // System.out.println("    Solución: mover la clase main a 'com.empresa' o configurar @ComponentScan.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta6() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 6                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  ¿Cuál es la afirmación CORRECTA sobre Spring Boot?");
        System.out.println();
        System.out.println("  a) Spring Boot reemplaza a Spring Framework; son incompatibles");
        System.out.println("  b) Spring Boot solo sirve para microservicios, no para monolitos");
        System.out.println("  c) Spring Boot no usa IoC ni DI; esas son características");
        System.out.println("     solo de Spring Framework puro");
        System.out.println("  d) Spring Boot ES Spring Framework con autoconfiguración");
        System.out.println("     y convenciones predefinidas encima");
        System.out.println();




























































        // System.out.println("  RESPUESTA: d)");
        // System.out.println("  → Spring Boot ES Spring Framework + @EnableAutoConfiguration.");
        // System.out.println("    Usa IoC, DI y todos los módulos de Spring. Solo los configura automáticamente.");
        System.out.println();
    }
}
