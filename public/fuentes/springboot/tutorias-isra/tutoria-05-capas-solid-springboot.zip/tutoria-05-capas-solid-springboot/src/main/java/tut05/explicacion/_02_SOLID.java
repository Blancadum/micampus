package tut05.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 2: PRINCIPIOS SOLID — Los que más impactan en Spring Boot
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *
 * SOLID no es un mandamiento absoluto. Es una GUÍA para tomar mejores decisiones.
 * Hay que conocerlos para poder aplicarlos conscientemente — y para saber
 * cuándo NO aplicarlos (over-engineering).
 *
 *
 * S — SINGLE RESPONSIBILITY PRINCIPLE (SRP)
 * ──────────────────────────────────────────
 * "Una clase debe tener una sola razón para cambiar."
 *
 *   ❌ Violación:
 *   public class LibroController {
 *       public ResponseEntity<Libro> findById(Long id) {
 *           // consulta directa a la BBDD aquí
 *           // envío de email de auditoría aquí
 *           // lógica de descuento aquí
 *           // todo mezclado
 *       }
 *   }
 *
 *   ✅ Correcto:
 *   LibroController     → solo gestiona HTTP
 *   LibroService        → solo tiene lógica de negocio
 *   LibroRepository     → solo accede a la BBDD
 *   AuditService        → solo gestiona auditoría
 *   DescuentoCalculator → solo calcula descuentos
 *
 *
 * O — OPEN/CLOSED PRINCIPLE (OCP)
 * ────────────────────────────────
 * "Abierto a extensión, cerrado a modificación."
 *
 *   ❌ Violación:
 *   public double calcularDescuento(String tipoCliente, double precio) {
 *       if (tipoCliente.equals("VIP")) return precio * 0.20;
 *       if (tipoCliente.equals("EMPLEADO")) return precio * 0.30;
 *       // añadir un nuevo tipo = MODIFICAR este método
 *       return 0;
 *   }
 *
 *   ✅ Correcto:
 *   interface EstrategiaDescuento { double calcular(double precio); }
 *
 *   @Component class DescuentoVip implements EstrategiaDescuento { ... }
 *   @Component class DescuentoEmpleado implements EstrategiaDescuento { ... }
 *   // nuevo tipo = AÑADIR una clase nueva, sin tocar las existentes
 *
 *
 * L — LISKOV SUBSTITUTION PRINCIPLE (LSP)
 * ────────────────────────────────────────
 * "Una subclase debe poder sustituir a su superclase sin romper nada."
 *
 *   ❌ Violación:
 *   class Cuadrado extends Rectangulo {
 *       @Override setAncho(int w) { super.setAncho(w); super.setAlto(w); }
 *       // Cuadrado fuerza comportamiento distinto → rompe el contrato de Rectangulo
 *   }
 *
 *   void test(Rectangulo r) {
 *       r.setAncho(5);
 *       r.setAlto(10);
 *       // Rectangulo promete: area() == ancho * alto
 *       assert r.area() == 50;
 *   }
 *
 *   → Si le pasas un Rectangulo normal: area() = 50 ✅ (cumple lo prometido)
 *   → Si le pasas un Cuadrado (que "sustituye" a Rectangulo): setAlto(10)
 *     fuerza también ancho = 10 → area() = 100 ❌ (rompe lo prometido)
 *   → El código que confiaba en el contrato de Rectangulo se rompe en
 *     cuanto recibe la subclase → viola LSP.
 *
 *   En Spring pasa lo mismo con cualquier interfaz: si un @Service
 *   concreto no se comporta como su interfaz promete (p. ej. un método
 *   que debería guardar datos y en su lugar lanza una excepción siempre),
 *   el Controller que depende de esa interfaz se rompe en cuanto Spring
 *   le inyecta esa implementación en vez de otra.
 *
 *
 * I — INTERFACE SEGREGATION PRINCIPLE (ISP)
 * ───────────────────────────────────────────
 * "Es mejor tener varias interfaces pequeñas que una grande."
 *
 *   ❌ Violación:
 *   interface LibroOperaciones {
 *       List<Libro> findAll(); Libro findById(Long id);
 *       void create(Libro l); void update(Libro l); void delete(Long id);
 *       void exportarPDF(); void enviarEmail(); void calcularEstadisticas();
 *   }
 *
 *   ✅ Correcto:
 *   interface LibroCrud { List<Libro> findAll(); Libro findById(Long id); ... }
 *   interface LibroExport { void exportarPDF(); }
 *   interface LibroNotificaciones { void enviarEmail(); }
 *
 *
 * D — DEPENDENCY INVERSION PRINCIPLE (DIP) ← EL MÁS IMPORTANTE EN SPRING
 * ─────────────────────────────────────────────────────────────────────────
 * "Depende de abstracciones (interfaces), no de implementaciones (clases concretas)."
 *
 *   ❌ Violación:
 *   public class LibroController {
 *       private LibroServiceImpl servicio = new LibroServiceImpl(); // impl concreta
 *   }
 *
 *   ✅ Correcto (en la demo de esta tutoría):
 *   public class LibroController {
 *       private final LibroService servicio;  // interfaz (abstracción)
 *       public LibroController(LibroService servicio) { this.servicio = servicio; }
 *   }
 *
 *   → Spring inyecta LibroServiceImpl en tiempo de ejecución.
 *   → Para tests, inyectas un mock de LibroService.
 *   → Si mañana hay LibroServiceCached, el Controller no cambia ni una línea.
 *
 *
 * RELACIÓN SOLID ↔ ARQUITECTURA POR CAPAS
 * ─────────────────────────────────────────
 *   SRP → cada capa tiene una responsabilidad: Controller=HTTP, Service=negocio, Repository=datos
 *   OCP → añadir un nuevo tipo de descuento = nueva clase @Service, no modificar la existente
 *   ISP → interfaces de repositorio pequeñas y específicas (JpaRepository ya aplica esto)
 *   DIP → Controller depende de la interfaz LibroService, no de LibroServiceImpl
 */
public class _02_SOLID {
    // Ver DIP en acción: LibroController usa LibroService (interfaz), no LibroServiceImpl
}
