package tut05.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Bean de ejemplo, sin ninguna utilidad funcional.
 * Sirve solo para localizarlo fácilmente en GET /actuator/beans y comprobar
 * que ese endpoint muestra TODO el ApplicationContext: tanto los beans que
 * autoconfigura Spring Boot como los que registra este @Configuration.
 */
@Configuration
public class DemoBeansConfig {

    @Bean
    public String pruebaIsra() {
        return "Esto es una prueba!!";
    }

    // Ejemplo de override real (ver tut05.avanzado._02_Personalizar_Autoconfiguracion):
    // Spring Boot ya autoconfigura un ObjectMapper por defecto para Jackson.
    // Búscalo en /actuator/beans: se llama "jacksonObjectMapper" (lo crea
    // JacksonAutoConfiguration.JacksonObjectMapperConfiguration).
    //
    // Importante: @ConditionalOnMissingBean(ObjectMapper.class) comprueba por
    // TIPO, no por nombre. No hace falta que tu bean se llame "jacksonObjectMapper"
    // ni "objectMapper" — basta con que sea de tipo ObjectMapper para que Spring
    // Boot detecte que ya hay uno y NI SIQUIERA CREE el suyo (no compiten dos
    // ObjectMapper en el contexto; el autoconfigurado desaparece del todo).
    // A partir de ahí, TODOS los @RestController de la app usan el tuyo.
    //
    // El "name" de abajo (con dos valores) no sirve para "igualar" el nombre de
    // Spring Boot — es solo para que veas en /actuator/beans que un mismo bean
    // puede registrarse con un nombre principal + un alias, y pedirse por
    // cualquiera de los dos con @Qualifier. @Scope("singleton") es el valor por
    // defecto; se deja explícito solo para que también aparezca en el JSON.
    /* 
     @Bean(name = {"miObjectMapper", "miObjectMapperPersonalizado"})
     @org.springframework.context.annotation.Scope("singleton")
     public com.fasterxml.jackson.databind.ObjectMapper miObjectMapper() {
         return new com.fasterxml.jackson.databind.ObjectMapper()
             .disable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
     }
    */
}
