package tut05.avanzado;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO] SPRING BOOT ACTUATOR — Monitorización y métricas
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * ⚠️ Contenido extra — no entra en el temario estándar del curso.
 *
 *
 * ¿QUÉ ES ACTUATOR?
 * ──────────────────
 * Spring Boot Actuator es un módulo que expone ENDPOINTS de monitorización
 * de la aplicación en producción, sin escribir ningún código.
 *
 *   Añadir la dependencia:
 *   <dependency>
 *       <groupId>org.springframework.boot</groupId>
 *       <artifactId>spring-boot-starter-actuator</artifactId>
 *   </dependency>
 *
 *
 * ENDPOINTS DISPONIBLES
 * ──────────────────────
 *   GET /actuator/health      → estado de la app (UP / DOWN)
 *   GET /actuator/info        → información del proyecto
 *   GET /actuator/metrics     → métricas de JVM, HTTP, etc.
 *   GET /actuator/env         → variables de entorno y propiedades
 *   GET /actuator/beans       → todos los beans registrados en el contexto
 *   GET /actuator/mappings    → todos los endpoints HTTP de la aplicación
 *   POST /actuator/shutdown   → apagar la app (requiere habilitarlo)
 *
 *
 * CONFIGURACIÓN BÁSICA
 * ─────────────────────
 *   # Exponer todos los endpoints
 *   management.endpoints.web.exposure.include=*
 *
 *   # Solo exponer health e info (más seguro en producción)
 *   management.endpoints.web.exposure.include=health,info
 *
 *   # Puerto separado para Actuator (buena práctica en producción)
 *   management.server.port=8086
 *
 *
 * /actuator/health — El más útil
 * ───────────────────────────────
 *   {
 *     "status": "UP",
 *     "components": {
 *       "db": { "status": "UP" },
 *       "diskSpace": { "status": "UP" },
 *       "ping": { "status": "UP" }
 *     }
 *   }
 *
 *   → Los orquestadores de contenedores (Kubernetes, Docker Swarm)
 *     usan este endpoint para saber si reiniciar la aplicación.
 *   → Las pipelines de CI/CD comprueban /health antes de completar el deploy.
 *
 *
 * NOTA: /actuator/info APARECE VACÍO POR DEFECTO ({})
 * ─────────────────────────────────────────────────────
 * Spring Boot no rellena /actuator/info automáticamente, hay que decirle
 * qué mostrar. Dos formas de hacerlo:
 *
 *   Opción 1 — a mano, en application.properties:
 *   info.app.name=Tutoria 5 - Capas y SOLID
 *   info.app.description=Demo de arquitectura por capas y SOLID
 *   info.app.version=1.0.0
 *
 *   Opción 2 — generado automáticamente desde el build, en el pom.xml:
 *   <plugin>
 *       <groupId>org.springframework.boot</groupId>
 *       <artifactId>spring-boot-maven-plugin</artifactId>
 *       <executions>
 *           <execution>
 *               <goals><goal>build-info</goal></goals>
 *           </execution>
 *       </executions>
 *   </plugin>
 *
 *   → La opción 2 expone un bloque "build": {...} con la versión, el
 *     nombre y la fecha de compilación tomados directamente del pom.xml,
 *     sin duplicar esa información a mano en application.properties.
 *
 *
 * DEVTOOLS — RECARGA AUTOMÁTICA EN DESARROLLO
 * ─────────────────────────────────────────────
 * spring-boot-devtools detecta cambios en clases compiladas y
 * reinicia la aplicación automáticamente.
 *
 *   → Guarda el archivo (Ctrl+S) — el Java Language Server de VS Code
 *     compila en segundo plano, o ejecuta `mvn compile` manualmente
 *   → DevTools reinicia el servidor en ~1-2 segundos
 *   → No es hot-swap completo (para eso existe JRebel), pero es suficiente
 *     para el desarrollo cotidiano.
 *   → Solo funciona en `scope=runtime` (no va al .jar de producción).
 */
public class _01_Actuator_DevTools {
    // Contenido avanzado — referencia conceptual.
}
