﻿package tut02;

/**
 * TEST DE 6 PREGUNTAS — TUTORÍA 2: JSON + ECOSISTEMA JAVA WEB
 */
public class Preguntas {

    public static void main(String[] args) {
        pregunta1();
      //  pregunta2();
      //  pregunta3();
      //  pregunta4();
      //  pregunta5();
      //  pregunta6();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta1() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 1                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  ¿Cuál de estos fragmentos JSON tiene un ERROR de sintaxis?");
        System.out.println();
        System.out.println("  a) { \"precio\": 29.99 }");
        System.out.println("  b) { \"disponible\": True }");
        System.out.println("  c) { \"titulo\": \"Clean Code\" }");
        System.out.println("  d) { \"paginas\": 431 }");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) True con mayúscula no es JSON válido.");
        // System.out.println("  → En JSON los booleanos son: true / false (minúsculas).");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta2() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 2                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  Quieres deserializar este JSON en Java:");
        System.out.println("  [ { \"titulo\": \"Clean Code\" }, { \"titulo\": \"Refactoring\" } ]");
        System.out.println();
        System.out.println("  ¿Cuál es la forma CORRECTA con Jackson?");
        System.out.println();
        System.out.println("  a) mapper.readValue(json, List.class)");
        System.out.println("  b) mapper.readValue(json, new TypeReference<List<Libro>>() {})");
        System.out.println("  c) mapper.readValue(json, Libro[].class)  → (válido también)");
        System.out.println("  d) Las opciones b y c son ambas correctas");
        System.out.println();




























































        // System.out.println("  RESPUESTA: d) Tanto TypeReference como array[] funcionan.");
        // System.out.println("  → a) da una List<Object> (pierde el tipo genérico por type erasure).");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta3() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 3                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  En un proyecto Spring Boot 3.x, ¿qué import usas para");
        System.out.println("  la anotación de validación @NotBlank?");
        System.out.println();
        System.out.println("  a) import javax.validation.constraints.NotBlank;");
        System.out.println("  b) import jakarta.validation.constraints.NotBlank;");
        System.out.println("  c) import org.springframework.validation.NotBlank;");
        System.out.println("  d) import java.validation.constraints.NotBlank;");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) jakarta.validation — Spring Boot 3.x usa jakarta.*");
        // System.out.println("  → Spring Boot 2.x usaba javax.*. El cambio fue en Jakarta EE 9 (2019).");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta4() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 4                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  En un @RestController de Spring Boot, cuando el método");
        System.out.println("  devuelve un objeto Java, ¿quién lo convierte a JSON?");
        System.out.println();
        System.out.println("  a) El programador, llamando a ObjectMapper.writeValueAsString()");
        System.out.println("  b) Spring Boot automáticamente, usando Jackson como librería interna");
        System.out.println("  c) El navegador del cliente");
        System.out.println("  d) El servidor Tomcat embebido");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) Spring Boot / Jackson — automáticamente.");
        // System.out.println("  → spring-boot-starter-web incluye Jackson. @RestController");
        // System.out.println("    usa HttpMessageConverter que llama a Jackson internamente.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta5() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 5                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  ¿Cuál es la relación correcta entre Jakarta EE y Spring?");
        System.out.println();
        System.out.println("  a) Son competidores excluyentes — hay que elegir uno");
        System.out.println("  b) Jakarta EE es el estándar; Spring lo implementa y extiende");
        System.out.println("  c) Spring es anterior a J2EE");
        System.out.println("  d) Jakarta EE es más moderno y ha reemplazado a Spring");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) Jakarta EE = estándar; Spring = implementación + más.");
        // System.out.println("  → Spring usa Jakarta EE internamente (@RestController usa jakarta.servlet).");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta6() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 6                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  Tu API recibe un POST con este body JSON:");
        System.out.println("  { \"titulo\": \"Clean Code\", \"precio\": 29.99 }");
        System.out.println("  y Spring Boot lo convierte a un objeto Libro Java.");
        System.out.println("  ¿Cómo se llama esta operación?");
        System.out.println();
        System.out.println("  a) Serialización");
        System.out.println("  b) Deserialización");
        System.out.println("  c) Marshalling (término antiguo, también correcto)");
        System.out.println("  d) Las opciones b y c son correctas");
        System.out.println();




























































        // System.out.println("  RESPUESTA: d) Deserialización / Unmarshalling — ambos términos.");
        // System.out.println("  → JSON → Java Object = deserialización.");
        // System.out.println("    Java Object → JSON = serialización.");
        System.out.println();
    }
}
