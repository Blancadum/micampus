package tut02;

/**
 * Ejecuta esta clase para ver el mapa conceptual de la Tutoría 2.
 */
public class _00_Resumen {

    public static void main(String[] args) {

        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  TUTORÍA 2 — JSON + ECOSISTEMA JAVA WEB");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // 1. ¿QUÉ ES JSON?
        // ════════════════════════════════════════════════════════════════════
        System.out.println("1. JSON — El formato de intercambio");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  JSON = JavaScript Object Notation");
        System.out.println("  Es TEXTO PLANO con estructura clave-valor.");
        System.out.println("  Es lo que Spring Boot envía y recibe en cada petición HTTP.");
        System.out.println();
        System.out.println("  { \"titulo\": \"Clean Code\", \"precio\": 29.99, \"disponible\": true }");
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // 2. TIPOS DE DATOS EN JSON
        // ════════════════════════════════════════════════════════════════════
        System.out.println("2. TIPOS DE DATOS EN JSON");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  String   → \"texto entre comillas dobles\"");
        System.out.println("  Number   → 42  /  3.14  (sin comillas, punto decimal)");
        System.out.println("  Boolean  → true  /  false  (sin comillas, minúsculas)");
        System.out.println("  null     → null  (sin comillas)");
        System.out.println("  Array    → [1, 2, 3]  /  [\"a\", \"b\"]");
        System.out.println("  Object   → { \"clave\": valor }");
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // 3. JACKSON EN SPRING BOOT
        // ════════════════════════════════════════════════════════════════════
        System.out.println("3. JACKSON — Lo que hace Spring Boot por ti");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  Java Object → JSON   →  serialización    (ObjectMapper.writeValueAsString)");
        System.out.println("  JSON → Java Object   →  deserialización  (ObjectMapper.readValue)");
        System.out.println();
        System.out.println("  Spring Boot incluye Jackson automáticamente.");
        System.out.println("  Cuando un @RestController devuelve un objeto Java,");
        System.out.println("  Jackson lo convierte a JSON sin que tengas que hacer nada.");
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // 4. ECOSISTEMA JAVA WEB
        // ════════════════════════════════════════════════════════════════════
        System.out.println("4. ECOSISTEMA JAVA WEB");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  Jakarta EE  = el estándar oficial de Java empresarial");
        System.out.println("               (antes llamado Java EE, antes J2EE)");
        System.out.println("  Spring      = framework que implementa y extiende Jakarta EE");
        System.out.println("  javax.*     = paquetes del PASADO (Java EE / J2EE)");
        System.out.println("  jakarta.*   = paquetes del PRESENTE (Jakarta EE 9+)");
        System.out.println();
        System.out.println("  Spring Boot 3.x usa jakarta.* — no javax.*");
        System.out.println();

        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  Demo ejecutable: _03_Jackson_ObjectMapper.java");
        System.out.println("  Preguntas tipo test: Preguntas.java");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
    }
}
