package tut02.avanzado;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO] JACKSON — Anotaciones y configuración avanzada
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * ⚠️ Contenido extra — no entra en el temario estándar del curso.
 *
 *
 * @JsonProperty — Renombrar campos en el JSON
 * ──────────────────────────────────────────────
 *   A veces el nombre del campo en Java no coincide con el que espera el cliente.
 *
 *   public class Libro {
 *       @JsonProperty("book_title")   // en JSON se verá como "book_title"
 *       private String titulo;
 *   }
 *
 *   → Útil cuando integras con APIs externas que usan snake_case.
 *   → O cuando tu cliente frontend espera nombres específicos.
 *
 *
 * @JsonIgnore — Excluir campos del JSON
 * ──────────────────────────────────────
 *   public class Usuario {
 *       private String nombre;
 *
 *       @JsonIgnore   // este campo NO aparece en la respuesta JSON
 *       private String password;
 *   }
 *
 *   → Fundamental para no exponer datos sensibles (contraseñas, tokens...).
 *   → En Spring Boot la alternativa es usar DTOs (más limpia y segura).
 *
 *
 * @JsonInclude — Omitir nulls del JSON
 * ──────────────────────────────────────
 *   @JsonInclude(JsonInclude.Include.NON_NULL)
 *   public class Libro {
 *       private String titulo;
 *       private String descripcion;  // si es null, no aparece en el JSON
 *   }
 *
 *   → Reduce el tamaño del JSON cuando hay campos opcionales.
 *   → Se puede aplicar a nivel de clase o campo.
 *
 *
 * @JsonFormat — Formato de fechas
 * ────────────────────────────────
 *   public class Libro {
 *       @JsonFormat(pattern = "yyyy-MM-dd")
 *       private LocalDate fechaPublicacion;
 *   }
 *
 *   → Sin esta anotación, Jackson serializa LocalDate como un array [2024,1,15].
 *   → Con ella, aparece como "2024-01-15".
 *   → En Spring Boot 3.x es necesario añadir jackson-datatype-jsr310
 *     o registrar el módulo JavaTimeModule.
 *
 *
 * CONFIGURACIÓN GLOBAL EN Spring Boot
 * ─────────────────────────────────────
 *   En application.properties:
 *
 *   # Serializar LocalDate como "2024-01-15" (no como array)
 *   spring.jackson.serialization.write-dates-as-timestamps=false
 *
 *   # Omitir campos null globalmente
 *   spring.jackson.default-property-inclusion=non_null
 *
 *   # Ignorar campos desconocidos al deserializar (útil en integraciones)
 *   spring.jackson.deserialization.fail-on-unknown-properties=false
 *
 *
 * ALTERNATIVAS A JSON
 * ────────────────────
 *   XML:              texto, verboso, usado en sistemas legacy
 *   YAML:             legible, usado en configuración (application.yml)
 *   Protocol Buffers: binario, muy eficiente, complejo, microservicios de alto rendimiento
 *   MessagePack:      binario, más compacto que JSON, menos extendido
 *
 *   → JSON sigue siendo el estándar para APIs REST públicas y la mayoría de proyectos.
 */
public class _01_JacksonAvanzado {
    // Contenido avanzado — referencia conceptual.
}
