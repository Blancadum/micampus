package tut02;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 1: JSON — SINTAXIS Y TIPOS DE DATOS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *
 * ¿QUÉ ES JSON?
 * ─────────────
 * JSON = JavaScript Object Notation
 *
 * Formato de texto ligero para intercambiar datos entre sistemas.
 * Aunque nació en JavaScript, es INDEPENDIENTE del lenguaje.
 * Hoy es el estándar universal de las APIs REST.
 *
 *
 * ESTRUCTURA BÁSICA
 * ─────────────────
 * Un objeto JSON es una colección de pares CLAVE: VALOR
 * entre llaves { }. Las claves son siempre strings (comillas dobles).
 *
 *   {
 *     "titulo":     "Clean Code",
 *     "precio":     29.99,
 *     "disponible": true,
 *     "paginas":    431,
 *     "autor":      null,
 *     "etiquetas":  ["java", "clean", "refactoring"],
 *     "editorial": {
 *       "nombre": "Prentice Hall",
 *       "pais":   "USA"
 *     }
 *   }
 *
 *
 * LOS 6 TIPOS DE DATOS EN JSON
 * ─────────────────────────────
 *
 *   ┌──────────────┬────────────────────────────────┬──────────────────────────┐
 *   │  Tipo JSON   │  Ejemplo                       │  Java equivalente        │
 *   ├──────────────┼────────────────────────────────┼──────────────────────────┤
 *   │  String      │  "Clean Code"                  │  String                  │
 *   │  Number      │  29.99  /  431                 │  Double / Integer        │
 *   │  Boolean     │  true  /  false                │  boolean                 │
 *   │  null        │  null                          │  null                    │
 *   │  Array       │  ["java", "clean"]             │  List<String>            │
 *   │  Object      │  { "nombre": "Prentice Hall" } │  Clase Java (POJO)       │
 *   └──────────────┴────────────────────────────────┴──────────────────────────┘
 *
 *
 * REGLAS DE SINTAXIS (LAS QUE MÁS FALLAN)
 * ─────────────────────────────────────────
 *
 *   ✅ Las claves van siempre entre COMILLAS DOBLES:
 *      { "titulo": "Clean Code" }   ← correcto
 *      { titulo: "Clean Code" }     ← error (sin comillas en la clave)
 *
 *   ✅ Los strings van entre COMILLAS DOBLES (no simples):
 *      { "titulo": "Clean Code" }   ← correcto
 *      { "titulo": 'Clean Code' }   ← error en JSON estricto
 *
 *   ✅ Los números NO llevan comillas:
 *      { "precio": 29.99 }          ← número
 *      { "precio": "29.99" }        ← string con texto "29.99"
 *
 *   ✅ Los booleanos en MINÚSCULAS:
 *      { "disponible": true }       ← correcto
 *      { "disponible": True }       ← error (True con mayúscula no es JSON)
 *
 *   ✅ El separador decimal es el PUNTO (no la coma):
 *      { "precio": 29.99 }          ← correcto
 *      { "precio": 29,99 }          ← error
 *
 *   ✅ Sin coma al final del último elemento:
 *      { "a": 1, "b": 2 }           ← correcto
 *      { "a": 1, "b": 2, }          ← error (trailing comma)
 *
 *
 * JSON vs XML — ¿POR QUÉ GANÓ JSON?
 * ───────────────────────────────────
 *
 *   XML:
 *   <libro>
 *     <titulo>Clean Code</titulo>
 *     <precio>29.99</precio>
 *   </libro>
 *
 *   JSON equivalente:
 *   { "titulo": "Clean Code", "precio": 29.99 }
 *
 *   → JSON es más CORTO (menos bytes por la red)
 *   → JSON es más LEGIBLE
 *   → JSON se parsea más RÁPIDO
 *   → JSON es nativo en JavaScript (el lenguaje del navegador)
 *
 *
 * ¿DÓNDE APARECE JSON EN SPRING BOOT?
 * ──────────────────────────────────────
 * En TODAS PARTES:
 *
 *   → Request body:   el cliente envía JSON para crear/actualizar recursos
 *   → Response body:  Spring Boot responde con JSON
 *   → application.properties puede ser application.yml (basado en JSON-like)
 *   → Logs estructurados
 *   → Swagger UI muestra los schemas en JSON
 *
 * La conversión entre Java y JSON la hace Jackson automáticamente.
 * Ver la demo en _03_Jackson_ObjectMapper.java
 */
public class _01_JSONSintaxis {
    // Referencia conceptual. Demo ejecutable en _03_Jackson_ObjectMapper.java
}
