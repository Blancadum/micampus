package tut02;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 3: ECOSISTEMA JAVA WEB — Jakarta EE, Spring y la evolución
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *
 * EL PROBLEMA QUE RESUELVEN ESTOS ESTÁNDARES
 * ───────────────────────────────────────────
 * Desarrollar una aplicación web empresarial con Java puro es extremadamente
 * complejo: hay que gestionar conexiones HTTP, sesiones, transacciones,
 * seguridad, persistencia... Todo a mano.
 *
 * Los estándares y frameworks existen para ABSTRAER esa complejidad.
 *
 *
 * LÍNEA DE TIEMPO
 * ───────────────
 *
 *   1999   J2EE (Java 2 Enterprise Edition)
 *            → Sun Microsystems define el estándar empresarial
 *            → EJBs (Enterprise JavaBeans) muy pesados y complejos
 *            → Paquetes: javax.*
 *
 *   2003   Spring Framework
 *            → Rod Johnson crea Spring como alternativa ligera a J2EE/EJBs
 *            → IoC + DI + POJOs sin herencias obligatorias
 *            → Revoluciona el desarrollo Java empresarial
 *
 *   2006   Java EE 5 (rebrand de J2EE)
 *            → Sun simplifica los EJBs inspirándose en Spring
 *            → Anotaciones en vez de XML masivo
 *
 *   2017   Jakarta EE (Eclipse Foundation)
 *            → Oracle dona Java EE a la Eclipse Foundation
 *            → No puede usar el nombre "Java" (marca registrada de Oracle)
 *            → Nuevo nombre: Jakarta EE
 *
 *   2019   Jakarta EE 9 — El gran cambio de paquetes
 *            → javax.* → jakarta.*
 *            → javax.servlet → jakarta.servlet
 *            → javax.persistence → jakarta.persistence
 *            → javax.validation → jakarta.validation
 *
 *
 * javax.* VS jakarta.* — LA CAUSA DE MUCHOS ERRORES
 * ───────────────────────────────────────────────────
 *
 *   Spring Boot 2.x   → usaba javax.*   (Java EE)
 *   Spring Boot 3.x   → usa  jakarta.*  (Jakarta EE 9+)
 *
 *   Si mezclas dependencias de ambas versiones, obtienes errores
 *   como ClassNotFoundException o NoSuchMethodError en runtime.
 *
 *   Ejemplo práctico:
 *     Spring Boot 2:  import javax.validation.constraints.NotBlank;
 *     Spring Boot 3:  import jakarta.validation.constraints.NotBlank;
 *
 *   ⚠️ Regla: si usas Spring Boot 3.x, TODO es jakarta.* — busca
 *      siempre la versión compatible.
 *
 *
 * ¿QUÉ ES JAKARTA EE HOY?
 * ─────────────────────────
 * Jakarta EE es el ESTÁNDAR. Spring es un FRAMEWORK que IMPLEMENTA ese estándar
 * y añade mucho más encima.
 *
 *   ┌──────────────────────────────────────────────────────┐
 *   │                   Tu aplicación                      │
 *   ├──────────────────────────────────────────────────────┤
 *   │           Spring Boot / Spring Framework             │  ← el framework
 *   ├──────────────────────────────────────────────────────┤
 *   │              Jakarta EE (APIs estándar)              │  ← el estándar
 *   │  Servlet API, JPA, Bean Validation, JAX-RS...        │
 *   ├──────────────────────────────────────────────────────┤
 *   │  Implementaciones (Hibernate, Tomcat, Hibernate Validator...) │
 *   └──────────────────────────────────────────────────────┘
 *
 *
 * SPRING VS JAKARTA EE — DIFERENCIA CLAVE
 * ─────────────────────────────────────────
 *
 *   Jakarta EE:  define QUÉ debe poder hacer una app empresarial Java
 *                (es una especificación / estándar)
 *
 *   Spring:      define CÓMO hacerlo, añadiendo IoC, DI y cientos de módulos
 *                (es una implementación + extensión del estándar)
 *
 *   No son rivales: Spring usa Jakarta EE internamente.
 *   @RestController de Spring usa jakarta.servlet internamente.
 *
 *
 * SERVIDOR DE APLICACIONES VS SERVIDOR EMBEBIDO
 * ───────────────────────────────────────────────
 *
 *   Jakarta EE tradicional:
 *     → Necesitas un servidor de aplicaciones externo (WildFly, GlassFish)
 *     → Despliegas un .war dentro del servidor
 *     → El servidor arranca, luego tu app
 *
 *   Spring Boot:
 *     → Tomcat está EMBEBIDO dentro del .jar
 *     → java -jar miapp.jar es suficiente
 *     → No necesitas instalar ni gestionar un servidor externo
 *     → Mucho más simple para despliegue y Docker
 */
public class _03_EcosistemaJavaWeb {
    // Referencia conceptual.
}
