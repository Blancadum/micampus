package tut02;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.util.List;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 2: JACKSON ObjectMapper
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Jackson es la librería que Spring Boot usa internamente para convertir
 * entre objetos Java y JSON. Esta demo muestra las 3 operaciones básicas:
 *
 *   1. Serialización:   Java Object → JSON String
 *   2. Deserialización: JSON String → Java Object
 *   3. Colecciones:     JSON Array  → List<Libro>  (requiere TypeReference)
 *
 * En Spring Boot esto ocurre AUTOMÁTICAMENTE en los @RestController.
 * Aquí lo vemos "a mano" para entender qué hay debajo.
 */
public class _02_Jackson_ObjectMapper {

    // ── Modelo de datos de ejemplo ───────────────────────────────────────────
    // Se usa record para eliminar boilerplate (Java 16+). Jackson lo soporta.
    record Libro(Long id, String titulo, String autor, Double precio, boolean disponible) {}

    // ────────────────────────────────────────────────────────────────────────

    public static void main(String[] args) throws Exception {

        ObjectMapper mapper = new ObjectMapper();
        // Formato bonito en la salida (indentado) — en producción se desactiva
        mapper.enable(SerializationFeature.INDENT_OUTPUT);

        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  JACKSON ObjectMapper — Serialización y Deserialización");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // EJEMPLO 1: Serialización — Java Object → JSON String
        // ════════════════════════════════════════════════════════════════════
        System.out.println("EJEMPLO 1: Serialización (Java Object → JSON)");
        System.out.println("─".repeat(60));

        Libro libro = new Libro(1L, "Clean Code", "Robert C. Martin", 29.99, true);

        // writeValueAsString convierte el objeto Java en String JSON
        String json = mapper.writeValueAsString(libro);

        System.out.println("Objeto Java: " + libro);
        System.out.println();
        System.out.println("JSON resultante:");
        System.out.println(json);
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // EJEMPLO 2: Deserialización — JSON String → Java Object
        // ════════════════════════════════════════════════════════════════════
        System.out.println("EJEMPLO 2: Deserialización (JSON → Java Object)");
        System.out.println("─".repeat(60));

        String jsonRecibido = """
                {
                  "id": 2,
                  "titulo": "The Pragmatic Programmer",
                  "autor": "David Thomas",
                  "precio": 35.50,
                  "disponible": false
                }
                """;

        // readValue convierte el String JSON en un objeto Java
        Libro libroDeserializado = mapper.readValue(jsonRecibido, Libro.class);

        System.out.println("JSON de entrada:");
        System.out.println(jsonRecibido);
        System.out.println("Objeto Java resultante: " + libroDeserializado);
        System.out.println("Titulo: " + libroDeserializado.titulo());
        System.out.println("Precio: " + libroDeserializado.precio());
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // EJEMPLO 3: Colecciones — JSON Array → List<Libro>
        // ════════════════════════════════════════════════════════════════════
        System.out.println("EJEMPLO 3: Deserializar una colección (JSON Array → List<Libro>)");
        System.out.println("─".repeat(60));

        /*
         * ⚠️ NO se puede usar readValue(json, List.class) directamente.
         *    Por el "type erasure" de Java, en tiempo de ejecución List.class
         *    no sabe que es List<Libro>: sería una List<Object>.
         *
         *    Solución: TypeReference — captura el tipo genérico en compilación.
         */
        String jsonArray = """
                [
                  { "id": 1, "titulo": "Clean Code", "autor": "Martin", "precio": 29.99, "disponible": true },
                  { "id": 2, "titulo": "Refactoring", "autor": "Fowler", "precio": 39.99, "disponible": true }
                ]
                """;

        // TypeReference conserva el tipo genérico List<Libro>
        List<Libro> libros = mapper.readValue(jsonArray, new TypeReference<List<Libro>>() {});

        System.out.println("JSON Array de entrada:");
        System.out.println(jsonArray);
        System.out.println("Lista resultante (" + libros.size() + " libros):");
        libros.forEach(l -> System.out.println("  → " + l.titulo() + " - " + l.autor()));
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // ¿QUÉ HACE SPRING BOOT CON TODO ESTO?
        // ════════════════════════════════════════════════════════════════════
        System.out.println("─".repeat(60));
        System.out.println("En Spring Boot esto ocurre automáticamente:");
        System.out.println();
        System.out.println("  @PostMapping(\"/libros\")");
        System.out.println("  public Libro crear(@RequestBody Libro libro) {");
        System.out.println("      // Jackson deserializa el JSON del body → objeto Libro");
        System.out.println("      return libroService.guardar(libro);");
        System.out.println("      // Jackson serializa el Libro devuelto → JSON en la respuesta");
        System.out.println("  }");
        System.out.println();
        System.out.println("No necesitas llamar a ObjectMapper manualmente.");
        System.out.println("Spring Boot lo configura y lo usa de forma transparente.");
    }
}
