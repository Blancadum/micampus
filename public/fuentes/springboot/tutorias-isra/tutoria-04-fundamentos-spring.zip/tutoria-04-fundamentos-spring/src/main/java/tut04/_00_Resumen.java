package tut04;

/**
 * Ejecuta esta clase para ver el mapa conceptual de la Tutoría 4.
 */
public class _00_Resumen {

    public static void main(String[] args) {

        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  TUTORÍA 4 — FUNDAMENTOS DE SPRING (IoC + DI)");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println();

        System.out.println("1. EL PROBLEMA QUE RESUELVE SPRING");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  Sin Spring: cada clase crea sus propias dependencias con 'new'.");
        System.out.println("  Resultado: clases ACOPLADAS → difíciles de testear y cambiar.");
        System.out.println();
        System.out.println("  Con Spring: el contenedor crea y conecta los objetos.");
        System.out.println("  Resultado: clases DESACOPLADAS → fáciles de testear y cambiar.");
        System.out.println();

        System.out.println("2. IoC — INVERSIÓN DE CONTROL");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  Sin IoC: TU código controla el ciclo de vida de los objetos.");
        System.out.println("  Con IoC: EL FRAMEWORK controla el ciclo de vida de los objetos.");
        System.out.println();
        System.out.println("  El control se INVIERTE: ya no llamas tú a 'new', lo hace Spring.");
        System.out.println();

        System.out.println("3. DI — INYECCIÓN DE DEPENDENCIAS");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  Spring te 'inyecta' los objetos que necesitas.");
        System.out.println("  Tú declaras QUÉ necesitas; Spring decide CÓMO crearlo y dártelo.");
        System.out.println();
        System.out.println("  3 formas: constructor (✅ recomendada), setter, campo (@Autowired)");
        System.out.println();

        System.out.println("4. BEANS Y ANOTACIONES");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  Un BEAN = un objeto gestionado por el contenedor de Spring.");
        System.out.println();
        System.out.println("  @Component    → bean genérico");
        System.out.println("  @Service      → bean de capa de negocio");
        System.out.println("  @Repository   → bean de acceso a datos");
        System.out.println("  @Controller   → bean de capa web");
        System.out.println("  @Bean         → método en @Configuration que devuelve un bean");
        System.out.println();

        System.out.println("5. CÓMO SPRING SABE QUÉ INYECTAR");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  @Primary      → este bean tiene prioridad si hay varios del mismo tipo");
        System.out.println("  @Qualifier    → especifica exactamente qué bean inyectar");
        System.out.println();

        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  Demo ejecutable: _04_Demo_IoC_DI.java");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
    }
}
