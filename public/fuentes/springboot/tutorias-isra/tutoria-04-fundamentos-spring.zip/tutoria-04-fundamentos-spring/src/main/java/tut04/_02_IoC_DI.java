package tut04;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 1: IoC E INYECCIÓN DE DEPENDENCIAS — El problema y la solución
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *
 * EL PROBLEMA: ACOPLAMIENTO CON 'new'
 * ─────────────────────────────────────
 * Imagina un servicio de notificaciones:
 *
 *   public class PedidoService {
 *       // Dependencias creadas directamente con 'new'
 *       private EmailService emailService = new EmailService();
 *       private SmsService smsService = new SmsService();
 *
 *       public void procesarPedido(Pedido pedido) {
 *           // lógica...
 *           emailService.enviar(pedido.getEmail());
 *       }
 *   }
 *
 * PROBLEMAS:
 *   → PedidoService está ACOPLADO a EmailService y SmsService.
 *   → No se puede testear PedidoService sin que funcionen Email y SMS.
 *   → Si cambia EmailService (nueva versión, otro proveedor),
 *     hay que tocar PedidoService.
 *   → Si hay 50 servicios que usan EmailService, hay 50 instancias.
 *
 *
 * LA SOLUCIÓN: INVERSIÓN DE CONTROL (IoC)
 * ─────────────────────────────────────────
 *
 *   ANTES (sin IoC):
 *     Tu código crea sus dependencias → TÚ tienes el control
 *
 *   DESPUÉS (con IoC):
 *     El CONTENEDOR crea y gestiona los objetos → el FRAMEWORK tiene el control
 *     El control se ha INVERTIDO
 *
 *   Analogía:
 *   - Sin IoC: vas al supermercado, coges los ingredientes y cocinas.
 *   - Con IoC: llaman al servicio de catering; tú dices qué platos quieres
 *              y ellos traen los ingredientes y cocinan.
 *
 *
 * INYECCIÓN DE DEPENDENCIAS (DI)
 * ───────────────────────────────
 * DI es la TÉCNICA que implementa IoC.
 * En lugar de crear las dependencias, las RECIBES inyectadas desde fuera.
 *
 *   public class PedidoService {
 *       private final EmailService emailService;  // no hay 'new'
 *
 *       // Spring inyecta el EmailService al crear PedidoService
 *       public PedidoService(EmailService emailService) {
 *           this.emailService = emailService;
 *       }
 *   }
 *
 * Ahora PedidoService:
 *   → No sabe CÓMO se crea EmailService (¿email real o mock?)
 *   → Se puede testear con un EmailService falso (mock)
 *   → Si cambia EmailService, PedidoService no cambia
 *
 *
 * TRES FORMAS DE INYECCIÓN EN SPRING
 * ────────────────────────────────────
 *
 *   1. POR CONSTRUCTOR ✅ RECOMENDADA
 *      public class PedidoService {
 *          private final EmailService emailService;
 *
 *          public PedidoService(EmailService emailService) {
 *              this.emailService = emailService;
 *          }
 *      }
 * 
 *      → El campo es final → inmutabilidad garantizada.
 *      → Fácil de testear (solo pasas el mock en el constructor).
 *      → Spring Boot la inyecta automáticamente si hay un único constructor.
 *
 *   2. POR SETTER ⚠️ USAR SOLO PARA DEPENDENCIAS OPCIONALES
 *      @Autowired
 *      public void setEmailService(EmailService emailService) {
 *          this.emailService = emailService;
 *      }
 * 
 *      → La dependencia puede quedar null si no se inyecta.
 *
 *   3. POR CAMPO ❌ NO RECOMENDADA (aunque es la más corta)
 *      @Autowired
 *      private EmailService emailService;
 * 
 *      → Difícil de testear sin contenedor Spring.
 *      → No puedes hacer el campo final.
 *      → Oculta las dependencias de la clase (no aparecen en el constructor).
 *
 *
 * EL CONTENEDOR IoC DE SPRING
 * ─────────────────────────────
 * El contenedor IoC es el "almacén" de beans de Spring:
 *
 *   ┌──────────────────────────────────────────────────────────────┐
 *   │  Contenedor IoC (ApplicationContext)                         │
 *   │                                                              │
 *   │  EmailService (singleton)                                    │
 *   │  SmsService (singleton)                                      │
 *   │  PedidoService (singleton, inyectado EmailService + Sms)     │
 *   │  ...                                                         │
 *   └──────────────────────────────────────────────────────────────┘
 *
 * Por defecto los beans son SINGLETON: una sola instancia compartida.
 * → Eficiente en memoria.
 * → Los beans deben ser STATELESS (sin estado de sesión de usuario).
 *
 *
 * BEANS: CÓMO REGISTRARLOS EN SPRING
 * ─────────────────────────────────────
 *
 *   Opción 1 — Anotaciones en la clase (más común hoy):
 *     @Component, @Service, @Repository, @Controller
 *     + @ComponentScan para que Spring las encuentre
 *
 *   Opción 2 — Clase de configuración Java:
 *     @Configuration + @Bean en un método que devuelve el objeto
 *
 *   Opción 3 — XML (heredado, se sigue viendo en proyectos antiguos):
 *     <bean id="emailService" class="com.ejemplo.EmailService" />
 *
 * Spring Boot usa principalmente la opción 1 con @ComponentScan automático.
 */
public class _02_IoC_DI {
    // Referencia conceptual. Demo ejecutable en _04_Demo_IoC_DI.java
}
