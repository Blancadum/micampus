package tut04;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 1: INTRODUCCIÓN A SPRING — EL PROBLEMA Y LA SOLUCIÓN
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Antes de entrar en IoC y DI, conviene ver el problema real que resuelve Spring.
 *
 * Si cada clase crea sus propias dependencias con 'new', el código queda muy
 * acoplado. Un servicio que necesita enviar mensajes por email o SMS puede
 * crear esas clases dentro de sí mismo. Esto parece sencillo al principio,
 * pero al poco tiempo aparecen varios problemas:
 *
 *  - la clase depende de una implementación concreta, no de una abstracción;
 *  - si cambia la forma de enviar mensajes, hay que tocar la clase;
 *  - los tests se vuelven más complejos porque también hay que instanciar
 *    esas dependencias reales;
 *  - el código queda menos reutilizable y más difícil de mantener.
 *
 * En una aplicación real, esto se repite con servicios de pagos, acceso a datos,
 * notificaciones, auditoría, correo, seguridad, etc. Si cada clase crea a mano
 * todo lo que necesita, la aplicación termina con muchas conexiones entre piezas
 * y con un cambio en una parte que obliga a tocar otras.
 *
 * Spring propone cambiar ese flujo. En lugar de que cada clase se encargue de
 * crear sus dependencias, el contenedor de Spring crea los objetos y los conecta
 * cuando hace falta. El control pasa del código a un framework externo.
 *
 * Eso es la idea central de la Inversión de Control (IoC): no somos nosotros
 * quienes gestionamos la creación y el ciclo de vida de cada objeto, sino el
 * contenedor de Spring.
 *
 * Y la técnica concreta para implementar esta idea es la Inyección de Dependencias
 * (DI). En vez de construir a mano los objetos con 'new', Spring nos los entrega
 * ya preparados. Así una clase no necesita saber cómo se crea una dependencia,
 * solo necesita declararla.
 *
 * Por ejemplo, un servicio de pedidos no necesita conocer la clase concreta de
 * correo electrónico que envía los avisos. Solo necesita una interfaz o contrato,
 * y Spring le inyecta la implementación adecuada. De ese modo, el servicio depende
 * de la abstracción, no de una clase concreta.
 *
 * Esto trae varias ventajas muy claras:
 *
 *  - menos acoplamiento entre clases;
 *  - mejor separación de responsabilidades;
 *  - más facilidad para probar con mocks o implementaciones falsas;
 *  - menos cambios cuando cambia la implementación interna;
 *  - código más limpio y más mantenible.
 *
 * Por eso, cuando hablamos de Spring, no hablamos solo de "crear objetos", sino
 * de administrarlos, conectarlos y gestionarlos en un contenedor. El contenedor
 * es el encargado de mantener esos beans, resolver dependencias y entregártelos
 * al punto exacto donde se necesitan.
 *
 * En otras palabras:
 *  - Sin Spring: tú controlas la creación y la conexión de objetos.
 *  - Con Spring: el contenedor lo hace por ti.
 *
 * Ese es el punto de partida. A partir de aquí veremos qué es un bean, cómo se
 * registra, cómo Spring resuelve dependencias y qué significa exactamente IoC/DI
 * en la práctica.
 */
public class _01_Introduccion {
    // Referencia conceptual. Demo ejecutable en _04_Demo_IoC_DI.java
}
