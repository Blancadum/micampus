package tut04;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 2: BEANS, @QUALIFIER, @PRIMARY Y SCOPE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *
 * ANOTACIONES ESTEREOTIPADAS — @Component Y SUS VARIANTES
 * ─────────────────────────────────────────────────────────
 * Todas registran un bean en el contenedor IoC. La diferencia es semántica:
 * ayudan a entender el propósito de cada clase.
 *
 *   @Component    → bean genérico (sin rol específico)
 *   @Service      → lógica de negocio
 *   @Repository   → acceso a datos (también añade traducción de excepciones JPA)
 *   @Controller   → controlador web (MVC, no REST)
 *   @RestController → @Controller + @ResponseBody (devuelve JSON)
 *
 * Spring Boot detecta estas anotaciones gracias a @ComponentScan,
 * que escanea el paquete raíz y todos sus sub-paquetes.
 *
 *
 * ¿QUÉ PASA CUANDO HAY VARIAS IMPLEMENTACIONES?
 * ───────────────────────────────────────────────
 *
 *   // Interfaz
 *   public interface NotificacionService { void enviar(String mensaje); }
 *
 *   // Implementación 1
 *   @Service
 *   public class EmailNotificacion implements NotificacionService { ... }
 *
 *   // Implementación 2
 *   @Service
 *   public class SmsNotificacion implements NotificacionService { ... }
 *
 *   // El servicio que las usa
 *   @Service
 *   public class PedidoService {
 *       public PedidoService(NotificacionService notificacion) { ... }
 *   }
 *
 *   → ERROR: "Expected single matching bean but found 2: emailNotificacion, smsNotificacion"
 *   Spring no sabe cuál de las dos inyectar.
 *
 *
 * SOLUCIÓN 1: @Primary — un candidato por defecto
 * ──────────────────────────────────────────────────
 *   @Service
 *   @Primary  // ← esta es la implementación por defecto
 *   public class EmailNotificacion implements NotificacionService { ... }
 *
 *   → Cuando no se especifica cuál, Spring inyecta EmailNotificacion.
 *
 *
 * SOLUCIÓN 2: @Qualifier — especificar exactamente cuál
 * ───────────────────────────────────────────────────────
 *   @Service
 *   public class PedidoService {
 *       public PedidoService(@Qualifier("smsNotificacion") NotificacionService n) { ... }
 *   }
 *
 *   → El nombre del qualifier es el nombre del bean (clase con primera letra minúscula).
 *   → Se puede personalizar: @Component("miNombre") y luego @Qualifier("miNombre").
 *
 *
 * ¿CUÁNDO USAR @PRIMARY vs @QUALIFIER?
 * ──────────────────────────────────────
 *   @Primary:   cuando hay una implementación "por defecto" y el resto son excepciones.
 *   @Qualifier: cuando quieres un control explícito en cada punto de inyección.
 *
 *
 * SCOPE — CICLO DE VIDA DEL BEAN
 * ────────────────────────────────
 *
 *   SINGLETON (por defecto):
 *     → Una sola instancia por contenedor. Todos comparten el mismo objeto.
 *     → ✅ Usar para servicios sin estado (stateless).
 *     → ❌ NO guardar estado de usuario en un bean singleton (son compartidos).
 *
 *     @Service  // → singleton por defecto
 *     public class ProductoService { ... }
 *
 *   PROTOTYPE:
 *     → Nueva instancia cada vez que se inyecta.
 *     → Usar cuando el bean tiene estado propio por cliente/uso.
 *
 *     @Service
 *     @Scope("prototype")
 *     public class CarritoCompra { ... }
 *
 *   REQUEST / SESSION / APPLICATION (solo en contexto web):
 *     → Una instancia por petición HTTP, por sesión, o por aplicación.
 *
 *
 * @LAZY — INICIALIZACIÓN DIFERIDA
 * ─────────────────────────────────
 *   Por defecto, Spring crea todos los beans singleton al arrancar.
 *   Con @Lazy, el bean se crea solo cuando se usa por primera vez.
 *
 *   @Service
 *   @Lazy
 *   public class ServicioPesado { ... }  // solo se inicializa cuando se inyecta
 *
 *   → Útil para servicios lentos de inicializar que no se usan siempre.
 *   → Reduce el tiempo de arranque de la aplicación.
 *
 *
 * @CONFIGURATION Y @BEAN — REGISTRAR BEANS MANUALMENTE
 * ──────────────────────────────────────────────────────
 * Útil para registrar objetos de librerías externas (que no puedes anotar):
 *
 *   @Configuration
 *   public class AppConfig {
 *
 *       @Bean  // Spring llama a este método y guarda el resultado como bean
 *       public ObjectMapper objectMapper() {
 *           ObjectMapper mapper = new ObjectMapper();
 *           mapper.enable(SerializationFeature.INDENT_OUTPUT);
 *           return mapper;
 *       }
 *
 *       @Bean
 *       @Primary
 *       public NotificacionService emailNotificacion() {
 *           return new EmailNotificacion();
 *       }
 *   }
 */
public class _03_Beans_Anotaciones {
    // Referencia conceptual. Demo ejecutable en _04_Demo_IoC_DI.java
}
