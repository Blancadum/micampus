﻿package tut04;

/**
 * TEST DE 6 PREGUNTAS — TUTORÍA 4: FUNDAMENTOS DE SPRING
 */
public class Preguntas {

    public static void main(String[] args) {
        pregunta1();
        pregunta2();
        pregunta3();
        pregunta4();
        pregunta5();
        pregunta6();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta1() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 1                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  ¿Cuál es la diferencia entre una aplicación SIN IoC y CON IoC?");
        System.out.println();
        System.out.println("  a) Con IoC la aplicación es más lenta porque el framework");
        System.out.println("     crea los objetos");
        System.out.println("  b) Sin IoC el código crea sus dependencias con 'new';");
        System.out.println("     con IoC el framework las crea y las inyecta");
        System.out.println("  c) IoC solo aplica a aplicaciones web, no a consola");
        System.out.println("  d) Con IoC no se puede usar la palabra clave 'new' en Java");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) El framework gestiona la creación de dependencias.");
        // System.out.println("  → El control se 'invierte': antes lo tenías tú (new), ahora Spring.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta2() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 2                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  ¿Cuál es la forma de inyección de dependencias recomendada en Spring?");
        System.out.println();
        System.out.println("  a) Por campo con @Autowired");
        System.out.println("  b) Por setter con @Autowired");
        System.out.println("  c) Por constructor");
        System.out.println("  d) Todas son equivalentes, da igual cuál uses");
        System.out.println();




























































        // System.out.println("  RESPUESTA: c) Por constructor");
        // System.out.println("  → El campo puede ser final → inmutabilidad.");
        // System.out.println("    Más fácil de testear: solo pasas el mock como parámetro.");
        // System.out.println("    Las dependencias son explícitas en la firma del constructor.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta3() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 3                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  Tienes dos implementaciones de NotificacionService:");
        System.out.println("  EmailNotificacion (con @Primary) y SmsNotificacion.");
        System.out.println("  Un servicio inyecta NotificacionService sin más especificaciones.");
        System.out.println("  ¿Qué ocurre?");
        System.out.println();
        System.out.println("  a) Error: Spring no puede elegir entre dos implementaciones");
        System.out.println("  b) Spring inyecta EmailNotificacion porque tiene @Primary");
        System.out.println("  c) Spring inyecta SmsNotificacion porque es la última declarada");
        System.out.println("  d) Spring inyecta ambas y lanza una excepción en runtime");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) EmailNotificacion — tiene @Primary.");
        // System.out.println("  → @Primary define el candidato por defecto.");
        // System.out.println("    Si se quiere SmsNotificacion explícitamente → @Qualifier.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta4() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 4                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  PedidoService es un bean singleton. Dos controllers distintos");
        System.out.println("  lo inyectan. ¿Cuántas instancias de PedidoService existen?");
        System.out.println();
        System.out.println("  a) Dos: una por cada controller que lo inyecta");
        System.out.println("  b) Una sola instancia compartida por ambos controllers");
        System.out.println("  c) Una nueva instancia por cada petición HTTP");
        System.out.println("  d) Spring decide en runtime cuántas crear");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) Una sola instancia (singleton)");
        // System.out.println("  → Por eso los beans deben ser STATELESS: si guardan estado");
        // System.out.println("    de usuario, lo comparten entre todas las peticiones.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta5() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 5                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  ¿Qué diferencia técnica hay entre @Service y @Component?");
        System.out.println();
        System.out.println("  a) @Service tiene lógica adicional de transacciones automáticas");
        System.out.println("  b) @Component no puede inyectar dependencias; @Service sí");
        System.out.println("  c) Técnicamente ninguna: ambas registran un bean. @Service");
        System.out.println("     es una especialización semántica para la capa de negocio");
        System.out.println("  d) @Service solo funciona en Spring Boot, no en Spring Framework");
        System.out.println();




























































        // System.out.println("  RESPUESTA: c) Técnicamente son equivalentes en registro de bean.");
        // System.out.println("  → La diferencia es semántica: ayuda al lector a entender el rol.");
        // System.out.println("    @Repository sí añade traducción de excepciones JPA además.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta6() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 6                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  Quieres registrar un ObjectMapper de Jackson como bean de Spring.");
        System.out.println("  No puedes añadir @Component a ObjectMapper (es una clase externa).");
        System.out.println("  ¿Cuál es la forma correcta?");
        System.out.println();
        System.out.println("  a) Crear una subclase de ObjectMapper y añadir @Component");
        System.out.println("  b) Crear una clase @Configuration con un método @Bean");
        System.out.println("     que devuelva new ObjectMapper()");
        System.out.println("  c) Usar @Autowired en el campo directamente");
        System.out.println("  d) No se puede registrar clases externas como beans de Spring");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) @Configuration + @Bean");
        // System.out.println("  → @Bean en un método de @Configuration → el retorno se registra");
        // System.out.println("    como bean en el contenedor. Así se registran librerías externas.");
        System.out.println();
    }
}
