package tut04.demo;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * DEMO EJECUTABLE: IoC + DI con Spring Context
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Este fichero contiene todo lo necesario para ver IoC y DI en acción:
 * una interfaz, dos implementaciones, un servicio que las usa y la config.
 *
 * No usa Spring Boot: solo spring-context (el núcleo del framework).
 * Esto es exactamente lo que ocurre internamente en Spring Boot,
 * sin la capa de autoconfiguración.
 */
public class _04_Demo_IoC_DI {

    // ── INTERFAZ ─────────────────────────────────────────────────────────────
    interface NotificacionService {
        void enviar(String destinatario, String mensaje);
    }

    // ── IMPLEMENTACIÓN 1: Email (marcada como primaria) ───────────────────────
    @Component("emailNotificacion")
    @Primary  // esta es la implementación por defecto si no se especifica cuál
    static class EmailNotificacion implements NotificacionService {
        @Override
        public void enviar(String destinatario, String mensaje) {
            System.out.println("  [EMAIL] → " + destinatario + ": " + mensaje);
        }
    }

    // ── IMPLEMENTACIÓN 2: SMS ─────────────────────────────────────────────────
    @Component("smsNotificacion")
    static class SmsNotificacion implements NotificacionService {
        @Override
        public void enviar(String destinatario, String mensaje) {
            System.out.println("  [SMS]   → " + destinatario + ": " + mensaje);
        }
    }

    // ── SERVICIO: usa NotificacionService (sin saber CUÁL) ───────────────────
    // Inyección por constructor (recomendada): el campo es final
    @Service
    static class PedidoService {

        private final NotificacionService notificacion;

        // Spring inyecta EmailNotificacion porque tiene @Primary
        public PedidoService(NotificacionService notificacion) {
            this.notificacion = notificacion;
        }

        public void procesarPedido(String cliente) {
            System.out.println("  Procesando pedido de: " + cliente);
            notificacion.enviar(cliente, "Tu pedido ha sido procesado correctamente.");
        }
    }

    // ── SERVICIO CON @QUALIFIER: fuerza SMS específicamente ──────────────────
    @Service
    static class AlertaService {

        private final NotificacionService notificacion;

        // @Qualifier sobreescribe @Primary y fuerza SmsNotificacion
        public AlertaService(@Qualifier("smsNotificacion") NotificacionService notificacion) {
            this.notificacion = notificacion;
        }

        public void enviarAlerta(String admin) {
            notificacion.enviar(admin, "⚠️ Alerta de sistema detectada.");
        }
    }

    // ── CONFIGURACIÓN: registra el componente scan ────────────────────────────
    @Configuration
    @ComponentScan(basePackageClasses = _04_Demo_IoC_DI.class)
    static class AppConfig {
        // El @ComponentScan hace que Spring detecte todos los @Component / @Service
        // en este fichero (incluyendo las clases estáticas internas)
    }

    // ── MAIN: arranca el contenedor y recupera los beans ─────────────────────
    public static void main(String[] args) {

        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  DEMO IoC + DI — Spring Context");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println();

        // Crear el contenedor IoC a partir de la clase de configuración
        try (var context = new AnnotationConfigApplicationContext(AppConfig.class)) {

            // ════════════════════════════════════════════════════════════════
            // EJEMPLO 1: PedidoService usa @Primary → EmailNotificacion
            // ════════════════════════════════════════════════════════════════
            System.out.println("EJEMPLO 1: PedidoService (@Primary → EmailNotificacion)");
            System.out.println("─".repeat(60));

            PedidoService pedidos = context.getBean(PedidoService.class);
            pedidos.procesarPedido("Ana García");
            pedidos.procesarPedido("Luis Martínez");
            System.out.println();

            // ════════════════════════════════════════════════════════════════
            // EJEMPLO 2: AlertaService usa @Qualifier → SmsNotificacion
            // ════════════════════════════════════════════════════════════════
            System.out.println("EJEMPLO 2: AlertaService (@Qualifier → SmsNotificacion)");
            System.out.println("─".repeat(60));

            AlertaService alertas = context.getBean(AlertaService.class);
            alertas.enviarAlerta("admin@empresa.com");
            System.out.println();

            // ════════════════════════════════════════════════════════════════
            // EJEMPLO 3: El mismo bean es siempre la misma instancia (SINGLETON)
            // ════════════════════════════════════════════════════════════════
            System.out.println("EJEMPLO 3: Singleton — misma instancia");
            System.out.println("─".repeat(60));

            PedidoService ref1 = context.getBean(PedidoService.class);
            PedidoService ref2 = context.getBean(PedidoService.class);
            System.out.println("ref1 == ref2 → " + (ref1 == ref2));
            System.out.println("(ambas referencias apuntan al MISMO objeto en memoria)");
            System.out.println();

            // ════════════════════════════════════════════════════════════════
            // ¿QUÉ HACE SPRING BOOT CON TODO ESTO?
            // ════════════════════════════════════════════════════════════════
            System.out.println("─".repeat(60));
            System.out.println("En Spring Boot:");
            System.out.println("  → @SpringBootApplication activa @ComponentScan automáticamente");
            System.out.println("  → El contenedor arranca al ejecutar SpringApplication.run()");
            System.out.println("  → No necesitas context.getBean() — Spring inyecta directamente");
            System.out.println("    en los constructores de tus clases @Service / @Controller");
        }
    }
}
