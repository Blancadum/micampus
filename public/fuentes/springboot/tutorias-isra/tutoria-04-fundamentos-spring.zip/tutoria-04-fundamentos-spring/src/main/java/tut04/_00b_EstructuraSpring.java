package tut04;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 0: CÓMO ESTÁ CONSTITUIDO SPRING — EL MAPA DEL FRAMEWORK
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Antes de entrar en el problema del acoplamiento (siguiente clase) conviene
 * situarse: ¿qué es exactamente "Spring" y dónde caen IoC/DI dentro de él?
 *
 *
 * SPRING NO ES UN FRAMEWORK, ES UN ECOSISTEMA
 * ──────────────────────────────────────────────
 * "Spring" es un paraguas de proyectos que comparten filosofía (IoC, menos
 * código de fontanería) pero resuelven problemas distintos:
 *
 *   Spring Framework  → el núcleo: IoC/DI, AOP, acceso a datos, web, test
 *   Spring Boot       → arranque rápido sobre el núcleo (autoconfiguración,
 *                        starters, servidor embebido) — se ve en Tutoría 5
 *   Spring Data       → repositorios de acceso a datos (JPA, Mongo...) — Tut 7/8
 *   Spring Security   → autenticación y autorización — Tutoría 15
 *   Spring Cloud      → microservicios distribuidos (fuera de este curso)
 *
 * Esta tutoría (4) trabaja sobre el NÚCLEO: Spring Framework. Todo lo demás
 * se construye encima de las mismas ideas que vas a ver aquí (IoC/DI).
 *
 *
 * LOS 5 MÓDULOS DEL NÚCLEO (SPRING FRAMEWORK)
 * ──────────────────────────────────────────────
 *
 *   ┌─────────────────────────────────────────────────────────────────────┐
 *   │                         SPRING FRAMEWORK                            │
 *   │                                                                     │
 *   │  ┌─────────────────────────────────────────────────────────────┐    │
 *   │  │   1. CORE CONTAINER  →  ESTA TUTORÍA (4) vive aquí          │    │
 *   │  │   Beans · Core · Context · SpEL                             │    │
 *   │  └─────────────────────────────────────────────────────────────┘    │
 *   │                                                                     │
 *   │  ┌───────────────────┐   ┌───────────────────────────────────────┐  │
 *   │  │ 2. AOP            │   │ 3. DATA ACCESS                        │  │ 
 *   │  │ (Tut 4 avanzado)  │   │ JDBC · ORM · Transacciones (Tut 7/8)  │  │
 *   │  └───────────────────┘   └───────────────────────────────────────┘  │
 *   │                                                                     │
 *   │  ┌───────────────────────────┐   ┌───────────────────────────────┐  │
 *   │  │ 4. WEB MVC (Tut 6)        │   │ 5. TEST (Tut 13/14)           │  │
 *   │  └───────────────────────────┘   └───────────────────────────────┘  │
 *   └─────────────────────────────────────────────────────────────────────┘
 *
 *
 * MÓDULO 1 — CORE CONTAINER (el que estudiamos AHORA)
 * ───────────────────────────────────────────────────────
 * Es el módulo base: sin él, ningún otro módulo funciona. Se subdivide en:
 *
 *   Beans     → creación y gestión de los objetos que Spring administra
 *               (lo que en el resto de esta tutoría llamamos "bean")
 *   Core      → lectura de configuración (anotaciones, antes también XML)
 *   Context   → el ApplicationContext: el "almacén" en memoria donde viven
 *               los beans ya creados y conectados entre sí
 *   SpEL      → Spring Expression Language, para leer/escribir valores en
 *               tiempo de ejecución (p. ej. dentro de @Value("#{...}"))
 *
 * IoC y DI —el tema de esta tutoría— NO son un módulo aparte: son el
 * MECANISMO que implementa Beans + Context. Cuando en _02_IoC_DI se habla
 * del "contenedor IoC", nos referimos exactamente a este módulo.
 *
 *
 * MÓDULOS 2 A 5 — DÓNDE SE VEN EN EL CURSO
 * ───────────────────────────────────────────
 *
 *   AOP (Programación Orientada a Aspectos)
 *     → transacciones, logs y seguridad "transversales" a las clases.
 *     → introducción práctica en tut04/avanzado/_01_AOP_Aspectos.java
 *
 *   Data Access (JDBC, ORM, Transactions)
 *     → cómo Spring habla con la base de datos sin JDBC puro.
 *     → se trabaja a fondo en las Tutorías 7 y 8 (capa de servicio + JPA).
 *
 *   Web MVC
 *     → @RestController, peticiones y respuestas HTTP.
 *     → se trabaja en la Tutoría 6.
 *
 *   Test
 *     → mocks e integración con JUnit.
 *     → se trabaja en las Tutorías 13 y 14.
 *
 *
 * POR QUÉ EMPEZAR POR EL CORE CONTAINER
 * ─────────────────────────────────────────
 * Todos los demás módulos —y Spring Boot entero— dependen de que el
 * contenedor IoC sepa crear beans e inyectar dependencias. Por eso el curso
 * empieza aquí: es la base sobre la que se apoya todo lo que viene después.
 *
 * A partir de la siguiente clase (_01_Introduccion) entramos en el problema
 * concreto que resuelve este módulo.
 */
public class _00b_EstructuraSpring {
    // Referencia conceptual. Sin código ejecutable.
}
