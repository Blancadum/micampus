package tut04.avanzado;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO] AOP — Programación Orientada a Aspectos en Spring
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * ⚠️ Contenido extra — no entra en el temario estándar del curso.
 *
 *
 * ¿QUÉ ES AOP?
 * ────────────
 * AOP = Aspect-Oriented Programming.
 * Es un paradigma que permite separar PREOCUPACIONES TRANSVERSALES
 * (cross-cutting concerns) de la lógica principal.
 *
 * Preocupaciones transversales: cosas que afectan a muchos sitios
 *   → Logging
 *   → Seguridad (verificar permisos)
 *   → Transacciones (@Transactional usa AOP internamente)
 *   → Caché (@Cacheable usa AOP)
 *   → Métricas y auditoría
 *
 *
 * EL PROBLEMA SIN AOP
 * ────────────────────
 * Sin AOP, para loggear cada método del servicio:
 *
 *   public void crearPedido(Pedido p) {
 *       log.info("Inicio crearPedido: {}", p.getId());    // ← repetido en todos
 *       // lógica real...
 *       log.info("Fin crearPedido: {} ms", duracion);    // ← repetido en todos
 *   }
 *
 *   public void cancelarPedido(Long id) {
 *       log.info("Inicio cancelarPedido: {}", id);       // ← repetido
 *       // lógica real...
 *       log.info("Fin cancelarPedido: {} ms", duracion); // ← repetido
 *   }
 *
 *
 * CON AOP: UN ASPECTO LO HACE POR TODOS
 * ───────────────────────────────────────
 *
 *   @Aspect
 *   @Component
 *   public class LoggingAspect {
 *
 *       // Intercept todos los métodos de todos los @Service
 *       @Around("execution(* com.ejemplo.service.*.*(..))")
 *       public Object logTiempoEjecucion(ProceedingJoinPoint pjp) throws Throwable {
 *           long inicio = System.currentTimeMillis();
 *           String metodo = pjp.getSignature().getName();
 *
 *           log.info("Inicio: {}", metodo);
 *           Object resultado = pjp.proceed();  // ejecuta el método real
 *           long duracion = System.currentTimeMillis() - inicio;
 *           log.info("Fin: {} → {} ms", metodo, duracion);
 *
 *           return resultado;
 *       }
 *   }
 *
 *   → Ahora los servicios no tienen ni una línea de logging.
 *   → El aspecto lo aplica a TODOS automáticamente.
 *
 *
 * TERMINOLOGÍA AOP
 * ─────────────────
 *   Aspect (Aspecto):     la clase con la lógica transversal (@Aspect)
 *   Advice (Consejo):     cuándo ejecutar — @Before, @After, @Around, @AfterReturning
 *   Pointcut:             expresión que define A QUÉ métodos aplica
 *   Join Point:           el punto exacto de ejecución (llamada a método)
 *   Weaving:              el proceso de aplicar el aspecto al código
 *
 *
 * AOP EN SPRING BOOT
 * ─────────────────────────────────────────────────
 *   @Transactional   → Spring usa un aspecto para abrir/cerrar transacciones
 *   @Cacheable       → Spring usa un aspecto para consultar/escribir la caché
 *   @Async           → Spring usa un aspecto para ejecutar en hilo separado
 *   @Scheduled       → Spring usa un aspecto para ejecución periódica
 *   Spring Security  → usa filtros y proxies AOP para verificar permisos
 *
 *   Cuando pones @Transactional en un método, Spring crea un PROXY
 *   que envuelve tu bean y ejecuta el código de transacción antes y después.
 */
public class _01_AOP_Aspectos {
    // Contenido avanzado — referencia conceptual.
}
