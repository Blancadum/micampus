package tut10.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 3: PAGINACIÓN Y ORDENACIÓN
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * PROBLEMA QUE RESUELVE
 * ────────────────────────
 *   findAll() (o findByActivoTrue()) trae SIEMPRE todos los registros. Con
 *   6 registros no pasa nada, pero con 6 millones sería una única consulta
 *   gigante, una respuesta HTTP enorme, y un cliente (móvil, web) que no
 *   necesita ni puede mostrar todo eso a la vez.
 *
 *
 * PAGEABLE + PAGEREQUEST — CÓMO SE PIDE UNA PÁGINA
 * ───────────────────────────────────────────────────
 *   Pageable es la interfaz que describe QUÉ página se quiere (número, tamaño,
 *   orden). PageRequest es la implementación concreta que se instancia:
 *
 *     Pageable pageable = PageRequest.of(0, 10, Sort.by(Sort.Direction.ASC, "nombre"));
 *     //                                 ↑  ↑   ↑
 *     //                          página 0  10 por página  ordenado por nombre asc
 *
 *   Cualquier método de un JpaRepository que reciba Pageable como último
 *   parámetro se convierte automáticamente en paginado — incluido un query
 *   method por nombre, como en este proyecto:
 *
 *     Page<Cliente> findByActivoTrue(Pageable pageable);
 *
 *   (Convive con la versión no paginada List<Cliente> findByActivoTrue() ya
 *   vista en el Bloque 1 — Spring Data distingue por la firma del método.)
 *
 *
 * PAGE<T> vs LIST<T> — QUÉ APORTA DE MÁS
 * ───────────────────────────────────────────
 *   Page<T> no es solo "una lista más corta": trae metadatos que el cliente
 *   necesita para construir un paginador:
 *
 *     getContent()        → List<T>, los elementos de ESTA página
 *     getNumber()          → número de página actual (empieza en 0)
 *     getSize()             → tamaño de página pedido
 *     getTotalElements()   → total de registros en TODA la tabla (sin paginar)
 *     getTotalPages()       → total de páginas
 *     isLast()               → true si es la última página
 *
 *   Page<T> además tiene map(): Page<Cliente> → Page<ClienteResponseDTO> sin
 *   perder los metadatos, solo transformando el contenido. Ver ClienteService.findAllPaginado().
 *
 *
 * PagedResponseDTO<T> — ENVOLTORIO GENÉRICO REUTILIZABLE
 * ───────────────────────────────────────────────────────────
 *   No se devuelve Page<T> directamente desde el Controller — es un tipo de
 *   Spring Data, no un DTO propio de la API. Se envuelve en un DTO genérico:
 *
 *     public class PagedResponseDTO<T> {
 *         List<T> content; int pageNumber; int pageSize;
 *         long totalElements; int totalPages; boolean last;
 *     }
 *
 *   Al ser genérico (<T>), sirve para paginar Clientes, o cualquier otra
 *   entidad del proyecto, sin duplicar la clase. Ver dto/PagedResponseDTO.java.
 *
 *
 * PARÁMETROS DE QUERY EN EL ENDPOINT, CON VALORES POR DEFECTO
 * ─────────────────────────────────────────────────────────────
 *   GET /api/v1/clientes?page=0&size=10&sort=nombre,asc
 *
 *   @GetMapping
 *   public PagedResponseDTO<ClienteResponseDTO> findAll(
 *           @RequestParam(defaultValue = "0") int page,
 *           @RequestParam(defaultValue = "10") int size,
 *           @RequestParam(defaultValue = "nombre,asc") String sort) { ... }
 *
 *   Los valores por defecto van en el CONTROLLER (no en el Service): si el
 *   cliente HTTP no manda page/size/sort, la petición sigue siendo válida.
 *
 *
 * LÍMITE DE TAMAÑO MÁXIMO DE PÁGINA
 * ──────────────────────────────────────
 *   Sin límite, un cliente podría pedir ?size=999999 y forzar la misma
 *   consulta gigante que la paginación pretende evitar. Por eso:
 *
 *     Math.min(size, TAMANO_PAGINA_MAXIMO)   // aquí, 100
 *
 *   El size pedido nunca se usa tal cual — siempre se acota antes de construir
 *   el PageRequest. Ver ClienteController.findAll().
 *
 * Ver implementación: repositorio/ClienteRepository.java (findByActivoTrue con Pageable),
 * dto/PagedResponseDTO.java, servicio/ClienteService.java (findAllPaginado),
 * controlador/ClienteController.java (findAll).
 */
public class _03_Paginacion {}
