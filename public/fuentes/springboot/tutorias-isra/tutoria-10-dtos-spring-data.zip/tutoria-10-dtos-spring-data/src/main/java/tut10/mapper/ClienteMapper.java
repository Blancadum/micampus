package tut10.mapper;
import tut10.dto.ClienteRequestDTO;
import tut10.dto.ClienteResponseDTO;
import tut10.dto.EtiquetaResponseDTO;
import tut10.entidad.Cliente;
import tut10.entidad.Etiqueta;
import java.util.List;

/** Mapeo manual Entity ↔ DTO — sin librerías externas. */
public class ClienteMapper {

    public static ClienteResponseDTO toResponseDTO(Cliente c) {
        return new ClienteResponseDTO(c.getId(), c.getNombre(), c.getEmail(),
                c.getFechaAlta(), c.isActivo(),
                // aplanado: solo el nombre del Plan, no el objeto completo — igual que
                // @Mapping(target="continent", source="location.continent") en MapStruct,
                // pero escrito a mano
                c.getPlan() != null ? c.getPlan().getNombre() : null,
                toEtiquetaDTOs(c.getEtiquetas()));
        // passwordHash se omite deliberadamente
    }

    private static List<EtiquetaResponseDTO> toEtiquetaDTOs(List<Etiqueta> etiquetas) {
        return etiquetas.stream()
                .map(e -> new EtiquetaResponseDTO(e.getId(), e.getNombre()))
                .toList();
    }

    public static Cliente toEntity(ClienteRequestDTO dto) {
        Cliente c = new Cliente();
        c.setNombre(dto.getNombre());
        c.setEmail(dto.getEmail());
        // simula hash — en producción usar BCryptPasswordEncoder
        c.setPasswordHash("$2a$10$hash_de_" + dto.getPassword());
        return c;
    }

    private ClienteMapper() {}
}
