package tut10.dto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

/** Lo que el cliente envía al crear/actualizar. Sin id ni fechaAlta ni passwordHash. */
@Data @NoArgsConstructor @AllArgsConstructor
public class ClienteRequestDTO {
    private String nombre;
    private String email;
    private String password;  // texto plano — el servicio lo hashea antes de guardar
    private Long planId;           // opcional — el Service lo resuelve contra PlanRepository
    private List<Long> etiquetaIds; // opcional — el Service los resuelve contra EtiquetaRepository
}
