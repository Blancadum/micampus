package tut10.explicacion;
public class Preguntas {
    public static void main(String[] args) { p1(); p2(); p3(); p4(); p5(); p6(); p7(); }
    static void p1() {
        System.out.println("┌────────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P1                                                               │");
        System.out.println("└────────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Por qué NO se debe exponer la entidad JPA directamente en la API?");
        System.out.println("  a) Puede exponer campos sensibles y acopla la BBDD al contrato HTTP");
        System.out.println("  b) Las entidades JPA son más lentas de serializar");
        System.out.println("  c) Jackson no puede serializar entidades JPA");
        System.out.println("  d) Spring Boot no permite devolver entidades desde @RestController");
        System.out.println();




























































        // System.out.println("  RESPUESTA: a) — campos sensibles + acoplamiento BBDD/API.");
        System.out.println();
    }
    static void p2() {
        System.out.println("┌────────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P2                                                               │");
        System.out.println("└────────────────────────────────────────────────────────────────────┘");
        System.out.println("  Llamas a repo.save(cliente). ¿Cuándo hace INSERT vs UPDATE?");
        System.out.println("  a) Siempre INSERT  b) INSERT si id==null, UPDATE si tiene id");
        System.out.println("  c) Siempre UPDATE  d) Depende de ddl-auto y de si la tabla ya existe previamente");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) id==null → INSERT, id!=null → UPDATE (MERGE).");
        System.out.println();
    }
    static void p3() {
        System.out.println("┌────────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P3                                                               │");
        System.out.println("└────────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Qué SQL genera Spring Data para: findByEmailContainingIgnoreCase?");
        System.out.println("  a) SELECT * WHERE email = ?");
        System.out.println("  b) SELECT * WHERE email IS NOT NULL");
        System.out.println("  c) SELECT * WHERE LOWER(email) LIKE LOWER('%?%')");
        System.out.println("  d) No es un query method válido según las convenciones de Spring Data");
        System.out.println();




























































        // System.out.println("  RESPUESTA: c) Containing=LIKE %x%, IgnoreCase=LOWER().");
        System.out.println();
    }
    static void p4() {
        System.out.println("┌────────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P4                                                               │");
        System.out.println("└────────────────────────────────────────────────────────────────────┘");
        System.out.println("  Tienes @Modifying + @Query UPDATE en el repo pero sin @Transactional.");
        System.out.println("  ¿Qué ocurre?");
        System.out.println("  a) Funciona correctamente  b) El UPDATE se ejecuta pero sin commit");
        System.out.println("  c) Spring añade la transacción automáticamente  d) Lanza TransactionRequiredException en runtime");
        System.out.println();




























































        // System.out.println("  RESPUESTA: d) JPA exige transacción activa para escrituras.");
        System.out.println();
    }
    static void p5() {
        System.out.println("┌────────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P5                                                               │");
        System.out.println("└────────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿En qué capa debe ocurrir la conversión Entity → DTO de respuesta?");
        System.out.println("  a) En el Service  b) En el Repository  c) En el Controller  d) En el Repository, sobrescribiendo save() para que devuelva un DTO");
        System.out.println();




























































        // System.out.println("  RESPUESTA: a) En el Service — el Controller nunca debe tocar la entidad.");
        System.out.println();
    }
    static void p6() {
        System.out.println("┌────────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P6                                                               │");
        System.out.println("└────────────────────────────────────────────────────────────────────┘");
        System.out.println("  ClienteResponseDTO.planNombre es un String, no un objeto Plan. ¿Dónde");
        System.out.println("  se resuelve un ClienteRequestDTO.planId (Long) contra un Plan real?");
        System.out.println("  a) En el ClienteMapper, con un @Autowired PlanRepository");
        System.out.println("  b) En el ClienteService, llamando a planRepo.findById(id)");
        System.out.println("  c) En el ClienteController, antes de llamar al Service");
        System.out.println("  d) Automáticamente, Spring Data lo resuelve por convención de nombre");
        System.out.println();




















        // System.out.println("  RESPUESTA: b) El Mapper no conoce Repositories; la resolución de ids va en el Service.");
        System.out.println();
    }
    static void p7() {
        System.out.println("┌────────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P7                                                               │");
        System.out.println("└────────────────────────────────────────────────────────────────────┘");
        System.out.println("  GET /api/v1/clientes?page=0&size=999. ¿Qué size llega realmente a PageRequest.of()?");
        System.out.println("  a) 999, tal cual lo pide el cliente");
        System.out.println("  b) 100 — el Controller acota el size al máximo permitido");
        System.out.println("  c) Error 400 Bad Request");
        System.out.println("  d) 10 — Spring Data ignora un size fuera de rango y usa el valor por defecto");
        System.out.println();




















        // System.out.println("  RESPUESTA: b) Math.min(size, TAMANO_PAGINA_MAXIMO) en el Controller.");
        System.out.println();
    }
}
