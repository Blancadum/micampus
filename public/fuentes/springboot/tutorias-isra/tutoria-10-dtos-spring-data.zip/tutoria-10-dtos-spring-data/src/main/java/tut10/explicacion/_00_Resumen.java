package tut10.explicacion;

public class _00_Resumen {
    public static void main(String[] args) {
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  TUTORÍA 10 — DTOs + SPRING DATA JPA");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println();
        System.out.println("1. POR QUÉ DTOs");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  El cliente HTTP no debe ver la entidad JPA directamente porque:");
        System.out.println("  → La entidad puede tener campos sensibles (passwordHash)");
        System.out.println("  → Cambiar la tabla de BBDD rompería el contrato de la API");
        System.out.println("  → Las relaciones LAZY causan LazyInitializationException en JSON");
        System.out.println();
        System.out.println("  ClienteRequestDTO  = lo que el cliente ENVÍA (sin id, sin hash)");
        System.out.println("  ClienteResponseDTO = lo que la API DEVUELVE (sin passwordHash)");
        System.out.println("  ClienteMapper      = convierte entre Entity y DTO (en el Service)");
        System.out.println();
        System.out.println("2. JPAREPOSITORY — CRUD AUTOMÁTICO");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  JpaRepository<Cliente, Long> genera: findAll, findById,");
        System.out.println("  save, deleteById, existsById, count... sin escribir código.");
        System.out.println();
        System.out.println("3. QUERY METHODS POR NOMBRE");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  findByEmail(String email)            → SELECT ... WHERE email = ?");
        System.out.println("  findByActivoTrue()                   → SELECT ... WHERE activo = true");
        System.out.println("  findByNombreContainingIgnoreCase(..){ → LIKE %nombre% (case insensitive)");
        System.out.println();
        System.out.println("4. @MODIFYING + @TRANSACTIONAL para UPDATE/DELETE");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  @Query + @Modifying + @Transactional = UPDATE/DELETE personalizado");
        System.out.println("  Sin @Modifying → Spring lanza excepción al intentar un UPDATE");
        System.out.println();
        System.out.println("5. DTOs SOBRE UNA RELACIÓN — APLANADO");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  ClienteResponseDTO.planNombre  ← Cliente.plan.nombre (String, no el objeto Plan)");
        System.out.println("  ClienteResponseDTO.etiquetas   ← List<EtiquetaResponseDTO>, no List<Etiqueta>");
        System.out.println("  ClienteRequestDTO.planId / etiquetaIds → el Service los resuelve contra");
        System.out.println("  PlanRepository / EtiquetaRepository antes de guardar.");
        System.out.println();
        System.out.println("6. PAGINACIÓN Y ORDENACIÓN");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  GET /api/v1/clientes?page=0&size=10&sort=nombre,asc");
        System.out.println("  Pageable/PageRequest.of(...) + Page<T> → PagedResponseDTO<T> genérico");
        System.out.println("  Tamaño de página acotado a un máximo (100) en el Controller");
        System.out.println();
        System.out.println("  [AVANZADO] @Transactional(readOnly=true) método a método — no está en el");
        System.out.println("  vídeo, ver avanzado/_02_Transactional_ReadOnly.java");
        System.out.println();
        System.out.println("  Demo: http://localhost:8090/api/v1/clientes");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
    }
}
