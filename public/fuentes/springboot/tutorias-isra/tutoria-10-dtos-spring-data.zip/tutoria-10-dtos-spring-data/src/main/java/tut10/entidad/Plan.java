package tut10.entidad;
import jakarta.persistence.*;
import lombok.*;

/**
 * Lado "uno" de una relación ManyToOne con Cliente (varios clientes pueden
 * compartir el mismo plan). Unidireccional a propósito: la mecánica de
 * @ManyToOne/@OneToMany bidireccional ya se explicó a fondo en la tutoria-08-09
 * (Categoria/Producto) — aquí el objetivo es solo la capa de DTO sobre la relación.
 */
@Entity @Table(name = "plan")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Plan {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String nombre;
}
