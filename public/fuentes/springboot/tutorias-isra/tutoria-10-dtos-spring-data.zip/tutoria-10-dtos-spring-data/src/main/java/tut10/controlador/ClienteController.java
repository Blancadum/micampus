package tut10.controlador;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tut10.dto.ClienteRequestDTO;
import tut10.dto.ClienteResponseDTO;
import tut10.dto.PagedResponseDTO;
import tut10.servicio.ClienteService;

@RestController
@RequestMapping("/api/v1/clientes")
public class ClienteController {

    private static final int TAMANO_PAGINA_MAXIMO = 100;

    private final ClienteService service;
    public ClienteController(ClienteService service) { this.service = service; }

    // page/size/sort con valores por defecto en el Controller (no en el Service) —
    // sort llega como "campo,direccion", p.ej. "nombre,asc" o "fechaAlta,desc"
    @GetMapping
    public PagedResponseDTO<ClienteResponseDTO> findAll(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "nombre,asc") String sort) {
        String[] campoDireccion = sort.split(",");
        Sort.Direction direccion = campoDireccion.length > 1 && campoDireccion[1].equalsIgnoreCase("desc")
                ? Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, Math.min(size, TAMANO_PAGINA_MAXIMO),
                Sort.by(direccion, campoDireccion[0]));
        return service.findAllPaginado(pageable);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ClienteResponseDTO> findById(@PathVariable Long id) {
        return service.findById(id).map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<ClienteResponseDTO> create(@RequestBody ClienteRequestDTO dto) {
        return ResponseEntity.status(201).body(service.create(dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> desactivar(@PathVariable Long id) {
        return service.desactivar(id)
                ? ResponseEntity.noContent().build()
                : ResponseEntity.notFound().build();
    }
}
