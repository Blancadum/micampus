package tut10.dto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/** DTO anidado dentro de ClienteResponseDTO.etiquetas — nunca se expone la entidad Etiqueta. */
@Data @NoArgsConstructor @AllArgsConstructor
public class EtiquetaResponseDTO {
    private Long id;
    private String nombre;
}
