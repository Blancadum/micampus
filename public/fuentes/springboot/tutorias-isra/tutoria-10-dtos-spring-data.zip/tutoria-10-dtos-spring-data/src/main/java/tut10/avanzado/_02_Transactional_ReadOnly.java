package tut10.avanzado;

/**
 * [AVANZADO] @Transactional(readOnly = true) método a método
 * ═══════════════════════════════════════════════════════════════════════════
 * LA IDEA
 * ───────────
 *   Clasificar cada método del Service según si lee o escribe, y anotarlo:
 *
 *   @Transactional(readOnly = true)
 *   public Optional<ClienteResponseDTO> findById(Long id) { ... }
 *
 *   @Transactional
 *   public ClienteResponseDTO create(ClienteRequestDTO dto) { ... }
 *
 *
 * POR QUÉ AYUDA readOnly = true
 * ──────────────────────────────────
 *   → Hibernate desactiva el "dirty checking" (no comprueba si las entidades
 *     cargadas han cambiado para decidir si hace UPDATE) — algo más rápido.
 *   → Deja claro, con solo leer la firma del método, que ese método nunca
 *     escribe en la BBDD — documentación ejecutable, no un comentario.
 *   → Si por error alguien añade una escritura dentro de un método marcado
 *     readOnly=true, algunos proveedores JPA (no todos) lo detectan en tiempo
 *     de ejecución.
 *
 *
 * DÓNDE VA (CAPA)
 * ─────────────────
 *   Lo habitual es en la capa Service, que es donde se coordinan varias
 *   operaciones. En el Repository solo en consultas propias @Modifying
 *   (UPDATE/DELETE), porque los métodos que Spring Data ya trae (save,
 *   deleteById...) gestionan su propia transacción. Nunca en el Controller
 *   (el Controller no debe conocer detalles de persistencia).
 *
 * 
 * NIVEL DE CLASE vs NIVEL DE MÉTODO
 * ──────────────────────────────────────
 *   @Transactional(readOnly = true) a nivel de CLASE marca todos los métodos
 *   como solo lectura por defecto; los métodos de escritura sobrescriben con
 *   su propio @Transactional (sin readOnly). Es un atajo razonable cuando la
 *   mayoría de los métodos de un Service son de lectura.
 * 
 *
 * ¿QUÉ PASA SI HAY @Transactional EN EL SERVICE Y EN EL REPOSITORY?
 * ──────────────────────────────────────────────────────────────────────
 *   No se crean dos transacciones: manda la del Service, que es la primera en
 *   empezar. Por defecto (propagation = REQUIRED), cuando el método del
 *   Repository se ejecuta y ya hay una transacción abierta, se UNE a ella en
 *   vez de abrir otra. Solo si no hay ninguna activa, abre la suya.
 *
 *     Service.desactivarVarios()  @Transactional   ← abre la transacción
 *        └─ repo.desactivar(1)    @Transactional   ← se une a la anterior
 *        └─ repo.desactivar(2)    @Transactional   ← se une a la anterior
 *
 *   Consecuencias:
 *     → Todo es una única unidad "todo o nada": si falla la segunda llamada,
 *       el rollback deshace también la primera.
 *     → Los atributos de la transacción que ya existe (readOnly, timeout...)
 *       mandan sobre los del método que se une. Si el Service es
 *       readOnly = true y llama a un método @Modifying del Repository, esa
 *       escritura iría dentro de una transacción de solo lectura: puede fallar
 *       o no guardarse, según la BBDD. Los métodos que escriben deben llamarse
 *       desde un @Transactional sin readOnly.
 * 
 */
public class _02_Transactional_ReadOnly {}
