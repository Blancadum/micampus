package tut10.dto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;
import java.util.List;

/** Lo que la API devuelve. Sin passwordHash (campo sensible). */
@Data @NoArgsConstructor @AllArgsConstructor
public class ClienteResponseDTO {
    private Long id;
    private String nombre;
    private String email;
    private LocalDateTime fechaAlta;
    private boolean activo;
    // passwordHash NO aparece aquí — esa es la razón de los DTOs
    private String planNombre;               // aplanado: Cliente.plan.nombre, no el objeto Plan completo
    private List<EtiquetaResponseDTO> etiquetas; // relación ManyToMany como lista de DTOs anidados
}
