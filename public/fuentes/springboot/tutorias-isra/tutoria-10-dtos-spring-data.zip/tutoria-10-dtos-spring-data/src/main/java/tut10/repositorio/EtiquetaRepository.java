package tut10.repositorio;
import org.springframework.data.jpa.repository.JpaRepository;
import tut10.entidad.Etiqueta;

public interface EtiquetaRepository extends JpaRepository<Etiqueta, Long> {
}
