package tut10.avanzado;
/**
 * [AVANZADO] MapStruct — generación de mappers en tiempo de compilación
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * MapStruct es una librería externa que genera automáticamente el mapeo
 * Entity ↔ DTO, como alternativa al mapeo manual que sí tenéis en
 * mapper/ClienteMapper.java. 
 *
 * QUÉ HACE EXACTAMENTE, PASO A PASO
 * ────────────────────────────────────
 *   1. En vez de una CLASE con métodos static (como ClienteMapper.java),
 *      declaras una INTERFAZ — solo la firma, sin cuerpo, sin lógica:
 *
 *        @Mapper(componentModel = "spring")
 *        public interface ClienteMapper {
 *            ClienteResponseDTO toResponseDTO(Cliente cliente);
 *            Cliente toEntity(ClienteRequestDTO dto);
 *        }
 *
 *      Aquí no hay ningún "return new ClienteResponseDTO(...)" — es solo el
 *      contrato: "dado un Cliente, quiero un ClienteResponseDTO".
 *
 *   2. Al ejecutar "mvn compile", un annotation processor de MapStruct (una
 *      pieza que se registra en el pom.xml, similar a como Lombok genera
 *      getters/setters) LEE esa interfaz y ESCRIBE un .java nuevo por ti:
 *
 *        target/generated-sources/annotations/tut10/mapper/ClienteMapperImpl.java
 *
 *      Es un fichero real, que podrías abrir y leer como cualquier otro —
 *      dentro tiene el MISMO tipo de código que escribiríais a mano
 *      (dto.setNombre(cliente.getNombre()), etc.), campo a campo, comparando
 *      los nombres que coinciden entre Cliente y ClienteResponseDTO. Nadie lo
 *      escribió: MapStruct lo dedujo.
 *
 *   3. "componentModel = spring" es la diferencia clave frente a vuestro
 *      ClienteMapper.java actual: hace que ClienteMapperImpl lleve @Component
 *      encima, así que Spring lo registra como un bean normal y se puede
 *      INYECTAR, en vez de llamarlo como métodos static:
 *
 *        @Service
 *        public class ClienteService {
 *            private final ClienteMapper mapper;               // se inyecta
 *            public ClienteService(ClienteMapper mapper) { this.mapper = mapper; }
 *            // uso: mapper.toResponseDTO(cliente)
 *        }
 *
 *      Vuestro ClienteMapper.java actual, al ser static, NO es un bean — se
 *      llama directamente como ClienteMapper.toResponseDTO(c), sin inyección.
 *
 *
 * QUÉ PASA CUANDO LOS NOMBRES NO COINCIDEN — @Mapping
 * ─────────────────────────────────────────────────────
 *   MapStruct solo mapea automáticamente los campos que se llaman IGUAL en
 *   origen y destino. Para el resto (renombrar, o "aplanar" un campo de una
 *   relación — lo mismo que vimos a mano en el Bloque 2 con planNombre) hay
 *   que decírselo con @Mapping:
 *
 *        @Mapping(target = "planNombre", source = "plan.nombre")
 *        ClienteResponseDTO toResponseDTO(Cliente cliente);
 *
 *   MapStruct entiende la navegación con punto (plan.nombre) y genera el
 *   null-check (si plan es null) automáticamente.
 *
 *   ⚠️ El @Mapping se añade ENCIMA del mismo método, no se vuelve a declarar
 *   el método una segunda vez — una interfaz Java no puede tener dos métodos
 *   con la misma firma. Si necesitas varias transformaciones (renombrar Y
 *   aplanar Y lo que sea), todo va en el mismo método, con varias anotaciones
 *   @Mapping seguidas si hace falta.
 *
 *
 * POR QUÉ SE PREFIERE EN PROYECTOS GRANDES
 * ─────────────────────────────────────────────
 *   → No escribes tú el mapeo campo a campo — menos código, menos sitios
 *     donde meter un bug al copiar mal un getter.
 *   → Se genera en COMPILACIÓN, no con reflexión en tiempo de ejecución (a
 *     diferencia de otras librerías como ModelMapper) — es tan rápido como
 *     el código manual, porque en el fondo ES código manual, solo que
 *     escrito por la herramienta.
 *   → Si añades un campo nuevo a la entidad y se te olvida en el DTO,
 *     MapStruct avisa en tiempo de compilación (warning o error, según cómo
 *     lo configures) — el mapeo manual falla en silencio, con el campo
 *     simplemente quedando a null.
 *
 *
 * PROYECCIONES EN SPRING DATA JPA — OTRA TÉCNICA DISTINTA, SIN RELACIÓN CON MAPSTRUCT
 * ═══════════════════════════════════════════════════════════════════════════════════
 *   Esto no transforma datos que ya tienes (como MapStruct o el mapeo
 *   manual) — cambia la propia consulta SQL para traer MENOS columnas desde
 *   el principio. Útil cuando una pantalla de listado solo necesita 2-3
 *   campos y cargar la entidad Cliente completa (con fechaAlta, activo,
 *   passwordHash...) sería desperdiciar ancho de banda y memoria.
 *
 *   ➜ NO HACE FALTA ESCRIBIR NINGÚN MAPEO NI CLASE MAPPER: la interfaz con los
 *     getters ya hace de DTO, y Spring Data empareja cada getter con la
 *     propiedad de la entidad que se llama igual. No hay entidad Cliente
 *     cargada que convertir después: la consulta ya devuelve solo esos datos.
 *
 *   1. Declaras una interfaz solo con los getters que te interesan:
 *
 *        public interface ClienteResumen {
 *            Long getId();
 *            String getNombre();
 *            String getEmail();
 *        }
 *
 *   2. Un método de repositorio que la devuelve en vez de Cliente:
 *
 *        List<ClienteResumen> findSummaryByActivoTrue();
 *
 *      (nombre distinto de findByActivoTrue(), que ya existe en
 *      ClienteRepository.java y devuelve Cliente completo — no puede haber
 *      dos métodos con el mismo nombre y distinto tipo de retorno)
 *
 *   3. Spring Data ve que el tipo de retorno es una interfaz de proyección
 *      (no una entidad) y genera un SQL distinto:
 *
 *        SELECT c.id, c.nombre, c.email FROM cliente c WHERE c.activo = true
 *
 *      — ni siquiera pide password_hash o fecha_alta a la BBDD, no es que
 *      los traiga y los descarte después. En tiempo de ejecución, Spring
 *      Data crea un objeto proxy que implementa ClienteResumen y delega cada
 *      getX() a la columna correspondiente del resultado.
 *
 *
 * ¿PROYECCIÓN O MAPPER? CUÁNDO USAR CADA UNO
 * ──────────────────────────────────────────────
 *   Resuelven problemas distintos y se pueden combinar en el mismo proyecto.
 *
 *   ┌────────────────────────────────┬─────────────────────────────────────┐
 *   │ Situación                      │ Mejor opción                        │
 *   ├────────────────────────────────┼─────────────────────────────────────┤
 *   │ Convertir entidad ↔ DTO en un  │ Mapper (manual o MapStruct)         │
 *   │ CRUD normal                    │                                     │
 *   │ Listado de solo lectura que    │ Proyección                          │
 *   │ necesita pocas columnas        │                                     │
 *   │ Convertir DTO de petición →    │ Mapper (la proyección no sirve en   │
 *   │ entidad (create/update)        │ este sentido)                       │
 *   │ Aplanar, renombrar o calcular  │ Mapper (con proyección habría que   │
 *   │ campos                         │ usar alias, @Value o @Query)        │
 *   └────────────────────────────────┴─────────────────────────────────────┘
 *
 *   VENTAJAS DE LA PROYECCIÓN
 *     → Menos código: solo la interfaz con los getters, sin mapper.
 *     → Menos datos: la consulta pide solo las columnas necesarias.
 *
 *   LÍMITES DE LA PROYECCIÓN
 *     → Solo va en un sentido: BBDD → respuesta. No sirve para convertir un
 *       DTO de petición en entidad (el toEntity de ClienteMapper).
 *     → No transforma datos: los nombres de los getters deben coincidir con
 *       las propiedades de la entidad; para otra cosa hay que usar alias.
 *     → Ata el Repository a la forma de la respuesta: devuelve tipos pensados
 *       para la pantalla, algo que antes hacían el Service y el Mapper.
 *     → Es menos explícita: un proxy en ejecución es más difícil de depurar
 *       que una clase generada que puedes abrir y leer.
 *
 * Ver implementación real (mapeo manual, sin MapStruct ni proyecciones):
 * mapper/ClienteMapper.java, dto/ClienteRequestDTO.java, dto/ClienteResponseDTO.java.
 */
public class _01_MapStruct_Projections {}
