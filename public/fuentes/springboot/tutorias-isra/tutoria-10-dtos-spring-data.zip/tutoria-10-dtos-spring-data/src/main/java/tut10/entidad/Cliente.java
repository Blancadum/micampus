package tut10.entidad;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity @Table(name = "cliente")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Cliente {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String nombre;

    @Column(nullable = false, unique = true)
    private String email;

    // campo sensible — NO debe aparecer en la respuesta JSON
    private String passwordHash;

    // campo interno — no relevante para el cliente
    @Column(name = "fecha_alta")
    private LocalDateTime fechaAlta = LocalDateTime.now();

    private boolean activo = true;

    // ManyToOne opcional — se aplana a "planNombre" (String) en ClienteResponseDTO
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "plan_id")
    private Plan plan;

    // ManyToMany — se aplana a "etiquetas" (List<EtiquetaResponseDTO>) en ClienteResponseDTO
    @ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(
        name = "cliente_etiqueta",
        joinColumns = @JoinColumn(name = "cliente_id"),
        inverseJoinColumns = @JoinColumn(name = "etiqueta_id")
    )
    private List<Etiqueta> etiquetas = new ArrayList<>();
}
