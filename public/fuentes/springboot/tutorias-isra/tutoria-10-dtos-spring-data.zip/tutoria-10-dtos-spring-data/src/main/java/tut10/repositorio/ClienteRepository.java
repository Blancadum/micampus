package tut10.repositorio;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;
import tut10.entidad.Cliente;
import java.util.List;
import java.util.Optional;

public interface ClienteRepository extends JpaRepository<Cliente, Long> {

    // Métodos derivados del nombre — Spring Data genera el SQL
    Optional<Cliente> findByEmail(String email);
    List<Cliente> findByActivoTrue();
    List<Cliente> findByNombreContainingIgnoreCase(String nombre);
    boolean existsByEmail(String email);
    long countByActivoTrue();

    // Mismo método derivado que findByActivoTrue(), pero paginado — Spring Data
    // permite sobrecargar un query method añadiendo Pageable como último parámetro
    Page<Cliente> findByActivoTrue(Pageable pageable);

    // @Query JPQL — desactivar cliente sin eliminarlo (soft delete)
    @Modifying
    @Transactional
    @Query("UPDATE Cliente c SET c.activo = false WHERE c.id = :id")
    int desactivar(Long id);
}
