package tut10.repositorio;
import org.springframework.data.jpa.repository.JpaRepository;
import tut10.entidad.Plan;

public interface PlanRepository extends JpaRepository<Plan, Long> {
}
