package tut10.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 2: DTOs SOBRE UNA RELACIÓN — APLANADO
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * La mecánica de @ManyToOne/@ManyToMany (dueño de la relación, @JoinColumn,
 * @JoinTable, cascade, FetchType) ya se explicó a fondo en la tutoria-08-09
 * (Categoria/Producto/Etiqueta). Aquí el objetivo es distinto: una vez que la
 * entidad YA tiene la relación, ¿cómo se representa en el DTO?
 *
 *
 * EL PROBLEMA: LA ENTIDAD RELACIONADA NO SE EXPONE TAL CUAL
 * ─────────────────────────────────────────────────────────────
 *   Cliente.plan es un objeto Plan completo (id, nombre...). Si ClienteResponseDTO
 *   tuviera un campo `private Plan plan;`, estaríamos exponiendo la entidad JPA
 *   igual que si no hubiéramos usado DTOs — exactamente el problema del Bloque 1,
 *   solo que escondido un nivel más abajo.
 *
 *
 * APLANADO (FLATTENING) — MANYTOONE → CAMPO ESCALAR
 * ────────────────────────────────────────────────────
 *   Aplanar es sacar un dato que está dentro de un objeto anidado y
 *   ponerlo como campo simple en el DTO.
 *
 *   EL PROBLEMA
 *   En la entidad, Cliente tiene una relación @ManyToOne con Plan, que es
 *   un objeto completo:
 *
 *     class Cliente {
 *         Long id;
 *         String nombre;
 *         Plan plan;          // objeto entero: id, nombre, precio, ...
 *     }
 *
 *   Si lo devolviéramos tal cual, el JSON saldría con un objeto dentro de
 *   otro, con datos del plan que el cliente de la API no necesita (y con
 *   riesgo de exponer datos internos o de provocar cargas perezosas de JPA):
 *
 *     { "id": 1, "nombre": "Ana",
 *       "plan": { "id": 3, "nombre": "Premium", "precio": 19.99 } }
 *
 *   LA SOLUCIÓN: APLANAR
 *   ClienteResponseDTO no tiene un campo `plan`, tiene un campo
 *   `planNombre` (String) con solo el dato que interesa:
 *
 *     class ClienteResponseDTO {
 *         Long id;
 *         String nombre;
 *         String planNombre;  // solo el nombre, no el objeto Plan
 *     }
 *
 *     { "id": 1, "nombre": "Ana", "planNombre": "Premium" }
 *
 *   EL MAPEO A MANO (en el Service / Mapper)
 *
 *     c.getPlan() != null ? c.getPlan().getNombre() : null
 *
 *     - Si el cliente tiene plan, se coge el nombre del plan.
 *     - Si no tiene plan (null), se pone null. Sin esta comprobación,
 *       c.getPlan().getNombre() lanzaría NullPointerException para los
 *       clientes sin plan.
 *
 *   ¿UNO, VARIOS O TODOS LOS CAMPOS?
 *   Se puede aplanar un campo, varios (planNombre, planPrecio...) o todos.
 *   Si hacen falta muchos campos del objeto relacionado, suele compensar
 *   un DTO anidado (PlanResponseDTO) en lugar de aplanar. Lo que NO se
 *   debe hacer es anidar la ENTIDAD Plan dentro del DTO: reintroduce el
 *   acoplamiento con la BBDD que el DTO quería evitar.
 *
 *   Ver implementación real: ClienteMapper.toResponseDTO().
 *
 * MANYTOMANY → LISTA DE DTOs ANIDADOS
 * ───────────────────────────────────────
 *   Cliente.etiquetas es List<Etiqueta> (entidades). ClienteResponseDTO.etiquetas
 *   es List<EtiquetaResponseDTO> — cada Etiqueta se convierte a su propio DTO
 *   (no se renombran campos, solo se cambia el tipo de cada elemento de la lista).
 *
 *   Ver implementación real: ClienteMapper.toEtiquetaDTOs() (método privado).
 *
 *
 * EL SENTIDO CONTRARIO: DE ID A ENTIDAD, EN EL SERVICE
 * ─────────────────────────────────────────────────────────
 *   Al crear un Cliente, el cliente HTTP no manda un objeto Plan completo —
 *   manda un id: ClienteRequestDTO.planId (Long). Alguien tiene que ir a la
 *   BBDD, buscar ese Plan por id, y asignarlo a la entidad antes de guardar.
 *
 *   ¿Dónde? En el SERVICE, nunca en el Mapper: el Mapper solo transforma datos
 *   que ya tiene en la mano, no conoce ningún Repository. Ver ClienteService.create():
 *
 *     if (dto.getPlanId() != null) {
 *         Plan plan = planRepo.findById(dto.getPlanId())
 *             .orElseThrow(() -> new IllegalArgumentException(...));
 *         cliente.setPlan(plan);
 *     }
 *
 *   Con una lista de ids (ClienteRequestDTO.etiquetaIds) es igual pero con
 *   findAllById(ids) en vez de findById(id) — y conviene comprobar que el
 *   tamaño de la lista devuelta coincide con el de ids pedidos, para detectar
 *   ids que no existen (ver ClienteService.create()).
 *
 *
 * QUÉ ES @Transactional Y POR QUÉ create() LA USA
 * ─────────────────────────────────────────────────
 *   @Transactional abre una transacción: el método se ejecuta como una
 *   unidad, "todo o nada". Si en mitad del método ocurre una excepción, se
 *   hace rollback automático y la base de datos queda intacta.
 *
 *   create() hace varias operaciones seguidas contra la BBDD:
 *     planRepo.findById()  →  etiquetaRepo.findAllById()  →  repo.save()
 *   Con @Transactional las tres forman una misma transacción: si algo falla
 *   (por ejemplo, un id de etiqueta que no existe), no se guarda nada a medias.
 *
 *   DÓNDE SE PUEDE PONER
 *     - Encima de un método: todo ese método va en una transacción.
 *     - A nivel de clase: todos los métodos de la clase son transaccionales.
 *     - En métodos del Repository (como el @Modifying de arriba) o en el
 *       Service, según lo que necesite la aplicación.
 *
 *   RELACIÓN CON @Modifying
 *     Una consulta @Modifying (UPDATE/DELETE) exige una transacción activa.
 *     Sin @Transactional lanza TransactionRequiredException, porque Spring no
 *     encuentra una transacción donde garantizar la consistencia de los datos.
 *
 *   Detalle de readOnly = true: ver avanzado/_02_Transactional_ReadOnly.java.
 *
 *
 * Ver implementación: entidad/Plan.java, entidad/Etiqueta.java, dto/EtiquetaResponseDTO.java,
 * mapper/ClienteMapper.java, servicio/ClienteService.java.
 */
public class _02_Relaciones_DTOs {}
