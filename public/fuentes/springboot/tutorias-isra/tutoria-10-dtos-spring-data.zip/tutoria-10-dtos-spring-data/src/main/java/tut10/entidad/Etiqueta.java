package tut10.entidad;
import jakarta.persistence.*;
import lombok.*;

/**
 * Lado destino de una relación ManyToMany con Cliente. Unidireccional a
 * propósito, por el mismo motivo que Plan: la mecánica de @ManyToMany +
 * @JoinTable ya se explicó a fondo en la tutoria-08-09 (Producto/Etiqueta).
 */
@Entity @Table(name = "etiqueta")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class Etiqueta {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String nombre;
}
