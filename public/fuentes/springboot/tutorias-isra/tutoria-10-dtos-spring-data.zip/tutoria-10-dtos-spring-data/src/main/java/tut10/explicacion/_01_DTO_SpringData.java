package tut10.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 1: DTO vs ENTIDAD + SPRING DATA JPA
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * DTO — DATA TRANSFER OBJECT
 * ──────────────────────────
 * Un DTO es una clase simple (sin lógica) que define exactamente
 * qué datos se transfieren entre capas o a través de la red.
 *
 *   Entidad (interna, ligada a BBDD):       DTO (contrato de la API):
 *   ┌──────────────────────────┐            ┌─────────────────────────┐
 *   │ @Entity                  │            │ ClienteResponseDTO      │
 *   │ private Long id;         │ ──────────→│ id                      │
 *   │ private String nombre;   │ ──────────→│ nombre                  │
 *   │ private String email;    │ ──────────→│ email                   │
 *   │ private String passHash; │            │ // omitido intencionado │
 *   │ private LocalDateTime    │ ──────────→│ fechaAlta               │
 *   │ private boolean activo;  │ ──────────→│ activo                  │
 *   └──────────────────────────┘            └─────────────────────────┘
 *
 *
 * LA CLASE MAPPER — QUIÉN HACE LA CONVERSIÓN Entity ↔ DTO
 * ───────────────────────────────────────────────────────────
 *   Un Mapper es una clase cuya única responsabilidad es convertir un objeto
 *   en otro: Entidad → DTO de respuesta, y DTO de petición → Entidad.
 *   No tiene lógica de negocio ni conoce la BBDD: solo copia y transforma
 *   datos que ya tiene (aplanar, omitir campos como passwordHash...).
 *
 *   Sin Mapper, esas conversiones acabarían repetidas (y desordenadas) por
 *   todos los Service. Con Mapper, se escriben una vez y se reutilizan.
 *
 *   DÓNDE VA: PAQUETE `mapper`
 *   Es un paquete propio, al mismo nivel que el resto de capas:
 *
 *     tut10/
 *     ├── controlador/   ← recibe HTTP; solo conoce DTOs
 *     ├── servicio/      ← lógica de negocio; USA el Mapper
 *     ├── mapper/        ← ClienteMapper (Entity ↔ DTO)
 *     ├── dto/           ← ClienteRequestDTO, ClienteResponseDTO...
 *     ├── entidad/       ← Cliente, Plan, Etiqueta (@Entity)
 *     └── repositorio/   ← acceso a BBDD
 *
 *   Nombre de la clase: [Entidad]Mapper → ClienteMapper.
 *
 *   QUÉ MÉTODOS TIENE (ver ClienteMapper.java)
 *     toResponseDTO(Cliente c)         → Entidad → DTO de respuesta
 *     toEntity(ClienteRequestDTO dto)  → DTO de petición → Entidad
 *
 *   MANUAL O CON LIBRERÍA
 *   Aquí es una clase normal con métodos estáticos, escrita a mano. Con
 *   MapStruct sería una interfaz @Mapper y la implementación se genera
 *   sola (ver avanzado/_01_MapStruct_Projections.java). El paquete y el
 *   papel dentro de la arquitectura son los mismos.
 *
 *   QUIÉN LLAMA AL MAPPER
 *   ✅ EL SERVICE (correcto):
 *      El Service recibe ClienteRequestDTO, usa el Mapper para crear la
 *      entidad Cliente, llama al repo, y usa el Mapper para devolver
 *      ClienteResponseDTO. El Controller nunca toca la entidad.
 *
 *      Controller ──DTO──▶ Service ──Mapper──▶ Entidad ──▶ Repository
 *      Controller ◀──DTO── Service ◀──Mapper── Entidad ◀── Repository
 *
 *   ❌ EL CONTROLLER (incorrecto):
 *      El Controller accedería a la entidad → acoplamiento HTTP-BBDD.
 *
 *
 * @REPOSITORY — LA CAPA DE ACCESO A DATOS
 * ────────────────────────────────────────
 *   @Repository marca una clase o interfaz como parte de la capa de BBDD:
 *   es la única capa que habla con la base de datos.
 *
 *   @Controller (Presentación) → @Service (lógica) → @Repository (BBDD)
 *
 *   - Registra el componente como bean de Spring (se puede inyectar).
 *   - Traduce las excepciones propias de la BBDD/JPA a las excepciones
 *     genéricas de Spring (DataAccessException).
 *   - En Spring Data JPA, al extender JpaRepository es OPCIONAL: Spring ya
 *     detecta la interfaz como repositorio. Aun así se suele poner para
 *     dejar clara la capa.
 *
 *   @Repository
 *   public interface ClienteRepository extends JpaRepository<Cliente, Long> { }
 *
 *
 * JPAREPOSITORY — MÉTODOS AUTOMÁTICOS
 * ────────────────────────────────────
 *   Extendiendo JpaRepository<T, ID> obtienes GRATIS:
 *   findAll()                → SELECT * FROM tabla
 *   findById(Long id)        → SELECT * WHERE id = ?  → devuelve Optional<T>
 *   save(T entity)           → INSERT si no tiene id, UPDATE si ya tiene
 *   deleteById(Long id)      → DELETE WHERE id = ?
 *   existsById(Long id)      → SELECT COUNT(*) WHERE id = ? → boolean
 *   count()                  → SELECT COUNT(*) FROM tabla
 *
 *
 * QUERY METHODS — CÓMO LOS INTERPRETA SPRING
 * ────────────────────────────────────────────
 *   Spring Data analiza el nombre del método y genera el SQL:
 *
 *   findBy[Campo](valor)             → WHERE campo = valor
 *   findBy[Campo]Containing(texto)   → WHERE campo LIKE '%texto%'
 *   findBy[Campo]IgnoreCase(texto)   → WHERE LOWER(campo) = LOWER(texto)
 *   findBy[Campo]Between(a,b)        → WHERE campo BETWEEN a AND b
 *   findBy[Campo]GreaterThan(n)      → WHERE campo > n
 *   findBy[Campo1]And[Campo2](v1,v2) → WHERE campo1=v1 AND campo2=v2
 *   findBy[Campo]True()              → WHERE campo = true
 *   countBy[Campo](valor)            → SELECT COUNT(*) WHERE campo=valor
 *   existsBy[Campo](valor)           → SELECT COUNT(*) > 0
 *   deleteBy[Campo](valor)           → DELETE WHERE campo=valor
 *
 *
 * @MODIFYING + @TRANSACTIONAL PARA UPDATE/DELETE
 * ────────────────────────────────────────────────
 *   @Modifying                         ← indica que modifica datos (no SELECT)
 *   @Transactional                     ← necesita transacción activa
 *   @Query("UPDATE Cliente c SET c.activo = false WHERE c.id = :id")
 *   int desactivar(@Param("id") Long id);
 *
 *   Sin @Modifying: Spring lanza InvalidDataAccessApiUsageException.
 *   Sin @Transactional: JPA requiere transacción para operaciones de escritura.
 *
 *   El método devuelve int = número de filas afectadas.
 *
 *   ¿POR QUÉ ESTAS ANOTACIONES VAN EN EL REPOSITORY Y NO EN EL SERVICE?
 *     - @Modifying solo puede ir en el Repository: es parte de la consulta
 *       @Query, que se declara ahí. Marca que es un UPDATE/DELETE, no un SELECT.
 *     - @Transactional puede ir en el Repository o en el Service, según lo que
 *       necesite la aplicación. Los métodos que Spring Data ya trae (save,
 *       deleteById...) vienen con su propia transacción, pero los métodos
 *       propios con @Query + @Modifying NO: sin @Transactional lanzan
 *       TransactionRequiredException. Ponerla en el Repository hace que el
 *       método funcione desde cualquier sitio que lo llame.
 *     - Si el Service combina varias operaciones y quieres que formen una sola
 *       transacción (como ClienteService.create()), @Transactional va en el
 *       método del Service.
 *
 *
 * @QUERY TAMBIÉN SIRVE PARA SELECT, NO SOLO PARA UPDATE/DELETE
 * ──────────────────────────────────────────────────────────────
 *   El ejemplo de arriba usa @Query para un UPDATE (por eso lleva @Modifying),
 *   pero @Query + @Param es el mismo mecanismo para cualquier JPQL, incluidas
 *   consultas de lectura con JOIN, parámetros, DISTINCT, agregaciones...
 *   exactamente el JPQL que ya escribisteis a mano con EntityManager en la
 *   demo de entidades y relaciones (tutoria-08-09). La diferencia es solo
 *   dónde vive la query:
 *
 *   // Con EntityManager (tutoria-08-09):
 *   em.createQuery("SELECT p FROM Producto p JOIN p.etiquetas e WHERE e.nombre = :etiqueta", Producto.class)
 *     .setParameter("etiqueta", etiqueta)
 *     .getResultList();
 *
 *   // Con @Query sobre un método de Repository (aquí):
 *   @Query("SELECT p FROM Producto p JOIN p.etiquetas e WHERE e.nombre = :etiqueta")
 *   List<Producto> findByEtiqueta(@Param("etiqueta") String etiqueta);
 *
 *   → Mismo JPQL, mismo :etiqueta con nombre — Spring Data se encarga de
 *     crear el EntityManager, ejecutar la query y mapear el resultado por ti.
 *
 * Ver implementación: tut10/repositorio/ClienteRepository.java + tut10/mapper/ClienteMapper.java
 */
public class _01_DTO_SpringData {}
