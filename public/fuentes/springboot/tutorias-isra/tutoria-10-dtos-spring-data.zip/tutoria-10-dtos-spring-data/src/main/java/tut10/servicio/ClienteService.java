package tut10.servicio;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import tut10.dto.ClienteRequestDTO;
import tut10.dto.ClienteResponseDTO;
import tut10.dto.PagedResponseDTO;
import tut10.entidad.Cliente;
import tut10.entidad.Etiqueta;
import tut10.entidad.Plan;
import tut10.mapper.ClienteMapper;
import tut10.repositorio.ClienteRepository;
import tut10.repositorio.EtiquetaRepository;
import tut10.repositorio.PlanRepository;
import java.util.List;
import java.util.Optional;

@Service @Slf4j
public class ClienteService {

    private final ClienteRepository repo;
    private final PlanRepository planRepo;
    private final EtiquetaRepository etiquetaRepo;

    public ClienteService(ClienteRepository repo, PlanRepository planRepo, EtiquetaRepository etiquetaRepo) {
        this.repo = repo;
        this.planRepo = planRepo;
        this.etiquetaRepo = etiquetaRepo;
    }

    public PagedResponseDTO<ClienteResponseDTO> findAllPaginado(Pageable pageable) {
        return PagedResponseDTO.from(repo.findByActivoTrue(pageable).map(ClienteMapper::toResponseDTO));
    }

    public Optional<ClienteResponseDTO> findById(Long id) {
        return repo.findById(id).map(ClienteMapper::toResponseDTO);
    }

    // @Transactional: resolvemos planId/etiquetaIds contra sus Repository y luego
    // guardamos el Cliente — sin una única transacción, cada llamada a Repository
    // abre y cierra la suya propia, y el Plan/Etiqueta ya guardado llegaría
    // "detached" al save() del Cliente, rompiendo el cascade = {PERSIST, MERGE}.
    @Transactional
    public ClienteResponseDTO create(ClienteRequestDTO dto) {
        if (repo.existsByEmail(dto.getEmail()))
            throw new IllegalArgumentException("Email ya registrado: " + dto.getEmail());

        Cliente cliente = ClienteMapper.toEntity(dto);

        // La resolución de ids contra el Repository va en el Service, no en el Mapper:
        // el Mapper solo transforma datos que ya tiene, no conoce la BBDD.
        if (dto.getPlanId() != null) {
            Plan plan = planRepo.findById(dto.getPlanId())
                    .orElseThrow(() -> new IllegalArgumentException("Plan no encontrado: " + dto.getPlanId()));
            cliente.setPlan(plan);
        }
        if (dto.getEtiquetaIds() != null && !dto.getEtiquetaIds().isEmpty()) {
            List<Etiqueta> etiquetas = etiquetaRepo.findAllById(dto.getEtiquetaIds());
            if (etiquetas.size() != dto.getEtiquetaIds().size())
                throw new IllegalArgumentException("Alguna etiqueta de " + dto.getEtiquetaIds() + " no existe");
            cliente.setEtiquetas(etiquetas);
        }

        Cliente guardado = repo.save(cliente);
        log.info("Cliente creado: id={}", guardado.getId());
        return ClienteMapper.toResponseDTO(guardado);
    }

    public boolean desactivar(Long id) {
        return repo.desactivar(id) > 0;
    }
}
