package tut10;

import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import tut10.entidad.Cliente;
import tut10.entidad.Etiqueta;
import tut10.entidad.Plan;
import tut10.repositorio.ClienteRepository;
import tut10.repositorio.EtiquetaRepository;
import tut10.repositorio.PlanRepository;

import java.util.List;

/**
 * Carga datos de prueba: Planes y Etiquetas (para poder crear Clientes con
 * relaciones ya resueltas) y varios Clientes (para que la paginación tenga
 * más de una página con la que probar).
 */
@Component
public class DataLoader implements CommandLineRunner {

    private final ClienteRepository clienteRepository;
    private final PlanRepository planRepository;
    private final EtiquetaRepository etiquetaRepository;

    public DataLoader(ClienteRepository clienteRepository, PlanRepository planRepository,
                       EtiquetaRepository etiquetaRepository) {
        this.clienteRepository = clienteRepository;
        this.planRepository = planRepository;
        this.etiquetaRepository = etiquetaRepository;
    }

    // @Transactional por el mismo motivo que ClienteService.create(): guardamos
    // Plan/Etiqueta y luego los reasignamos a un Cliente nuevo en la misma llamada.
    @Override
    @Transactional
    public void run(String... args) {
        Plan basico = planRepository.save(new Plan(null, "Básico"));
        Plan premium = planRepository.save(new Plan(null, "Premium"));

        Etiqueta vip = etiquetaRepository.save(new Etiqueta(null, "vip"));
        Etiqueta moroso = etiquetaRepository.save(new Etiqueta(null, "moroso"));
        Etiqueta newsletter = etiquetaRepository.save(new Etiqueta(null, "newsletter"));

        crear("Ana", "ana@test.com", premium, List.of(vip, newsletter));
        crear("Luis", "luis@test.com", basico, List.of(newsletter));
        crear("Marta", "marta@test.com", premium, List.of(vip));
        crear("Carlos", "carlos@test.com", basico, List.of());
        crear("Elena", "elena@test.com", null, List.of(moroso));
        crear("Pablo", "pablo@test.com", basico, List.of(newsletter));
    }

    private void crear(String nombre, String email, Plan plan, List<Etiqueta> etiquetas) {
        Cliente c = new Cliente();
        c.setNombre(nombre);
        c.setEmail(email);
        c.setPasswordHash("$2a$10$hash_de_prueba");
        c.setPlan(plan);
        c.setEtiquetas(etiquetas);
        clienteRepository.save(c);
    }
}
