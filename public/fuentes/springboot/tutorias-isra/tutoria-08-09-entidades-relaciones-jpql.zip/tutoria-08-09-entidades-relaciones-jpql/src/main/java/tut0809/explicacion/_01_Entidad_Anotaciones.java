package tut0809.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 1: QUÉ ES JPA + @ENTITY, @TABLE, @COLUMN, @ID, @GENERATEDVALUE
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * QUÉ ES JPA
 * ──────────────────────────────────
 *   JPA (Java Persistence API): especificación estándar de Java para ORM
 *   (mapear objetos Java a filas de una tabla relacional). JPA NO es una
 *   implementación, es una API — Hibernate es la implementación más usada
 *   (también existen EclipseLink, OpenJPA).
 *
 *   Spring Boot autoconfigura toda la persistencia a partir de
 *   application.properties: no hace falta persistence.xml ni configurar el
 *   EntityManager a mano — sí hay que inyectarlo (@PersistenceContext) y
 *   usarlo tú mismo para guardar, buscar y consultar, que es justo lo que
 *   veréis en este proyecto (ved DataLoader.java y repositorio/
 *   ProductoRepositorioManual.java). Existe una capa por encima, Spring Data
 *   JPA (la interfaz JpaRepository, con repo.save()/repo.findById() ya
 *   hechos y query methods automáticos), que evita escribir este código a
 *   mano — es el contenido de la siguiente tutoria, aquí trabajamos con
 *   EntityManager directamente para entender qué hace esa capa por debajo.
 *
 *
 * REQUISITOS DE UNA ENTIDAD JPA
 * ──────────────────────────────
 *   1. Anotada con @Entity
 *   2. Constructor SIN argumentos (public o protected) — JPA lo necesita
 *   3. Campo @Id con @GeneratedValue
 *   4. No puede ser final ni sus campos (Hibernate los modifica internamente)
 *
 *   // Mínimo válido:
 *   @Entity
 *   public class Producto {
 *       @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
 *       private Long id;
 *
 *       public Producto() {}  // ← obligatorio (Lombok @NoArgsConstructor lo genera igual)
 *   }
 *
 *
 * @TABLE — NOMBRE DE LA TABLA Y RESTRICCIONES
 * ──────────────────────────────────────────
 *   @Entity
 *   @Table(name = "producto")   → tabla se llama "producto" en la BBDD
 *
 *   Sin @Table: Hibernate usa el nombre de la clase (puede ser distinto).
 *   Buena práctica: siempre indicar @Table para evitar sorpresas.
 *
 *   Opciones adicionales de @Table (ved Categoria.java para un caso real):
 *
 *   @Table(
 *       name = "categoria",
 *       uniqueConstraints = @UniqueConstraint(name = "uk_categoria_nombre", columnNames = "nombre")
 *   )
 *
 *   → uniqueConstraints: restricción UNIQUE a nivel de tabla (útil cuando la
 *     restricción involucra varias columnas a la vez, cosa que @Column(unique=true)
 *     no puede expresar por sí solo).
 *   → indexes: índices a nivel de tabla, por ejemplo:
 *       @Table(indexes = @Index(name = "idx_producto_nombre", columnList = "nombre"))
 *
 *
 * @COLUMN — MAPEO DE CAMPOS
 * ──────────────────────────
 *   @Column(name = "titulo", nullable = false, length = 150)
 *   private String titulo;
 *
 *   Atributos útiles:
 *     name       → nombre de la columna en la BBDD (útil si es snake_case)
 *     nullable   → permite null (default: true)
 *     length     → longitud máxima para VARCHAR (default: 255)
 *     unique     → restricción UNIQUE en la columna
 *     updatable  → si false, no se actualiza con UPDATE
 *     insertable → si false, no se incluye en INSERT
 *
 *
 * @ENUMERATED — ENUMS EN ENTIDADES
 * ──────────────────────────────────
 *   public enum EstadoProducto { DISPONIBLE, AGOTADO, DESCATALOGADO }
 *
 *   @Enumerated(EnumType.STRING)   → guarda "DISPONIBLE" en la BBDD
 *   @Enumerated(EnumType.ORDINAL)  → guarda 0, 1, 2... (peligroso)
 *
 *   ⚠️ NUNCA usar ORDINAL: si reordenas el enum, los datos históricos cambian de significado.
 *   SIEMPRE usar STRING.
 *
 *
 * @GENERATEDVALUE — ESTRATEGIAS DE ID
 * ────────────────────────────────────
 *   IDENTITY:  la BBDD genera el id (AUTO_INCREMENT en MySQL, SERIAL en PostgreSQL)
 *              → más eficiente, el id está disponible después del INSERT
 *              → la que usa este curso para casi todas las entidades
 *
 *   SEQUENCE:  usa una secuencia de BBDD (mejor para PostgreSQL/Oracle).
 *              → Ejemplo real en Resena.java:
 *                @Id
 *                @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "resena_seq")
 *                @SequenceGenerator(name = "resena_seq", sequenceName = "seq_resena", allocationSize = 1)
 *                private Long id;
 *
 *   TABLE:     usa una tabla auxiliar que simula una secuencia (portable entre motores,
 *              pero la estrategia más lenta — evitar salvo que el motor no soporte SEQUENCE):
 *                @Id
 *                @GeneratedValue(strategy = GenerationType.TABLE, generator = "producto_gen")
 *                @TableGenerator(name = "producto_gen", table = "id_generator",
 *                                pkColumnName = "gen_name", valueColumnName = "gen_value")
 *                private Long id;
 *
 *   AUTO:      Hibernate elige la estrategia según el proveedor
 *              → puede cambiar entre versiones de Hibernate; no recomendado en producción
 *
 *   Para MySQL/H2 (lo que veréis en el curso): IDENTITY es la mejor opción salvo caso concreto.
 *
 *
 * CICLO DE VIDA DE UNA ENTIDAD
 * ──────────────────────────────
 *   4 estados por los que pasa un objeto entidad respecto al "contexto de persistencia"
 *   (la memoria interna donde Hibernate hace seguimiento de los cambios):
 *
 *   TRANSIENT (nuevo) → new Producto(...): objeto Java normal, Hibernate no lo conoce.
 *   MANAGED (gestionado) → tras em.persist(p) o repo.save(p): Hibernate vigila sus cambios;
 *                           cualquier setter que llames se sincroniza solo al hacer commit.
 *   DETACHED (desconectado) → tras cerrarse la transacción/sesión: el objeto sigue teniendo
 *                              datos, pero Hibernate ya no lo vigila (aquí es donde aparece
 *                              LazyInitializationException si intentas acceder a un LAZY).
 *   REMOVED (eliminado) → tras em.remove(p) o repo.delete(p): se borrará al hacer commit.
 *
 *   Con Spring Data JPA no se ve casi nunca de forma explícita (JpaRepository lo gestiona
 *   por vosotros), pero es la explicación de POR QUÉ existe LazyInitializationException:
 *   ocurre siempre en estado DETACHED.
 *
 *
 * RELACIÓN @MANYTOONE — LA FK EN LA ENTIDAD
 * ──────────────────────────────────────────
 *   Tabla producto tiene columna categoria_id (FK → categoria.id).
 *   En JPA esto se mapea con @ManyToOne en el lado de la FK:
 *
 *   // En Producto (tiene la FK categoria_id):
 *   @ManyToOne(fetch = FetchType.LAZY)
 *   @JoinColumn(name = "categoria_id")
 *   private Categoria categoria;
 *
 *   Regla: el lado que tiene la FK es el "dueño" de la relación.
 *   → Es Producto quien tiene categoria_id, así que @ManyToOne va en Producto.
 *
 *   FetchType.LAZY (recomendado):
 *   → Hibernate carga la Categoria SOLO cuando accedes a producto.getCategoria()
 *   → Más eficiente: no carga la Categoria en cada SELECT de producto
 *
 *   FetchType.EAGER (evitar salvo casos concretos):
 *   → Hibernate siempre carga la Categoria junto con el Producto
 *   → Puede generar N+1 queries si hay listas de productos
 *
 *
 * @ONETOONE + @MAPSID — COMPARTIR CLAVE PRIMARIA
 * ─────────────────────────────────────────────────
 *   Caso: FichaTecnica no tiene sentido sin un Producto, y cada Producto tiene
 *   como mucho una FichaTecnica. En vez de una FK "suelta" con su propio id
 *   autogenerado, FichaTecnica reutiliza el MISMO id que su Producto:
 *
 *   // En FichaTecnica (el lado que "toma prestada" la PK):
 *   @Id
 *   private Long id;                 // NO @GeneratedValue: el id lo pone @MapsId
 *
 *   @OneToOne(fetch = FetchType.LAZY)
 *   @MapsId
 *   @JoinColumn(name = "id")
 *   private Producto producto;
 *
 *   // En Producto (lado inverso, dueño conceptual):
 *   @OneToOne(mappedBy = "producto", cascade = CascadeType.ALL, orphanRemoval = true)
 *   private FichaTecnica fichaTecnica;
 *
 *   → Ventaja: la tabla ficha_tecnica no necesita su propia secuencia de ids,
 *     y el JOIN entre ambas tablas es directo por clave primaria (más rápido).
 *   → Por eso FichaTecnica se persiste DESPUÉS de que Producto ya tenga id
 *     (ved DataLoader.java): @MapsId necesita que el id del "dueño" ya exista.
 *
 *   Ver implementación completa: entidad/Producto.java, entidad/FichaTecnica.java,
 *   entidad/Categoria.java, entidad/Resena.java.
 */
public class _01_Entidad_Anotaciones {
    // Ver implementación: tut0809/entidad/*.java
}
