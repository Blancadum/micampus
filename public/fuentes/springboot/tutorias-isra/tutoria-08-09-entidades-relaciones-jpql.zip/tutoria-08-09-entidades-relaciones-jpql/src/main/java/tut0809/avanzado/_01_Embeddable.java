package tut0809.avanzado;
/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO] @Embeddable y @EmbeddedId — Tipos embebidos y PK compuesta
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * @EMBEDDABLE — tipo de valor reutilizable en varias entidades
 * ─────────────────────────────────────────────────────────────
 *   @Embeddable
 *   public class Direccion {
 *       private String calle;
 *       private String ciudad;
 *       private String codigoPostal;
 *   }
 *
 *   @Entity
 *   public class Proveedor {
 *       @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
 *
 *       @Embedded  // los campos de Direccion se mapean como columnas de proveedor
 *       private Direccion direccion;
 *   }
 *
 *   → No crea una tabla separada. Los campos de Direccion van dentro de la tabla Proveedor.
 *   → Útil para agrupar campos relacionados sin crear una relación.
 *
 *
 * @EMBEDDEDID — clave primaria compuesta
 * ──────────────────────────────────────
 *   @Embeddable
 *   public class ProductoEtiquetaId implements Serializable {
 *       private Long productoId;
 *       private Long etiquetaId;
 *   }
 *
 *   @Entity @Table(name = "producto_etiqueta_detalle")
 *   public class ProductoEtiquetaDetalle {
 *       @EmbeddedId
 *       private ProductoEtiquetaId id;
 *       // otros campos de la tabla intermedia (ej: fechaAsignacion)
 *   }
 *
 *   → Útil cuando la PK es compuesta (ej: tabla de relación ManyToMany con datos extra).
 *   → La clase @Embeddable debe implementar Serializable.
 *   → En este proyecto, producto_etiqueta (la tabla intermedia real, en Producto.java)
 *     NO usa @EmbeddedId porque no tiene columnas extra — un @JoinTable normal basta.
 *     Si necesitara guardar, por ejemplo, quién asignó la etiqueta y cuándo, ahí sí
 *     compensaría convertirla en una entidad propia con @EmbeddedId, o más sencillo
 *     todavía: una clave sustituta (id autogenerado normal) con un @UniqueConstraint
 *     sobre (producto_id, etiqueta_id) — ver Notas específicas más abajo.
 *
 *
 * CUANDO USAR EMBEDDABLE vs ENTIDAD SEPARADA
 * ────────────────────────────────────────────
 *   Embeddable: el concepto no tiene identidad propia (Direccion, Coordenadas, Rango)
 *   Entidad:    el concepto tiene identidad propia y puede existir de forma independiente
 *
 *
 * @EMBEDDEDID EN LA PRÁCTICA: ¿MEJOR CLAVE COMPUESTA O CLAVE SUSTITUTA?
 * ──────────────────────────────────────────────────────────────────────
 *   Aunque @EmbeddedId es la forma "académicamente correcta" de una clave
 *   compuesta, en proyectos Spring Boot actuales suele preferirse una clave
 *   sustituta (id autogenerado normal) incluso en tablas de relación con datos
 *   extra, y forzar la unicidad del par con @UniqueConstraint:
 *
 *   @Entity
 *   @Table(name = "producto_etiqueta_detalle",
 *          uniqueConstraints = @UniqueConstraint(columnNames = {"producto_id", "etiqueta_id"}))
 *   public class ProductoEtiquetaDetalle {
 *       @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
 *       private Long id;
 *
 *       @ManyToOne @JoinColumn(name = "producto_id") private Producto producto;
 *       @ManyToOne @JoinColumn(name = "etiqueta_id") private Etiqueta etiqueta;
 *       private LocalDate fechaAsignacion;
 *   }
 *
 *   Por qué se prefiere esto: los repositorios de Spring Data quedan simples
 *   (JpaRepository<ProductoEtiquetaDetalle, Long> en vez de necesitar la clase
 *   ProductoEtiquetaId completa para cualquier consulta), y se evita implementar
 *   equals()/hashCode() a mano en la clave compuesta (un fallo típico y sutil
 *   con Hibernate si no se hace bien).
 */
public class _01_Embeddable {}
