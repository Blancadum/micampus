package tut0809;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import tut0809.entidad.*;
import tut0809.entidad.Producto.EstadoProducto;

import java.util.List;

/**
 * Carga datos de prueba al arrancar la app, usando EntityManager (persist) directamente.
 *
 * Implementa CommandLineRunner como @Component (en vez de un @Bean que devuelve un
 * lambda) para que @Transactional en run() funcione de verdad: Spring invoca run()
 * a través del proxy transaccional del propio bean. Con "@Bean @Transactional" sobre
 * un método que solo CREA y devuelve un lambda, la anotación no envuelve la ejecución
 * posterior del lambda — es un error clásico que provoca
 * "TransactionRequiredException: No EntityManager with actual transaction available".
 */
@Component
public class DataLoader implements CommandLineRunner {

    @PersistenceContext
    private EntityManager em;

    @Override
    @Transactional
    public void run(String... args) {
        Categoria electronica = new Categoria(null, "Electrónica", null);
        Categoria hogar = new Categoria(null, "Hogar", null);
        em.persist(electronica);
        em.persist(hogar);

        Etiqueta oferta = new Etiqueta(null, "oferta", null);
        Etiqueta nuevo = new Etiqueta(null, "nuevo", null);
        em.persist(oferta);
        em.persist(nuevo);

        Producto p1 = new Producto(null, "Teclado mecánico", 79.99, EstadoProducto.DISPONIBLE,
                electronica, null, null, null);
        p1.setEtiquetas(List.of(oferta, nuevo));

        Producto p2 = new Producto(null, "Cafetera", 59.99, EstadoProducto.DISPONIBLE,
                hogar, null, null, null);
        p2.setEtiquetas(List.of(oferta));

        Producto p3 = new Producto(null, "Monitor 27\"", 349.00, EstadoProducto.AGOTADO,
                electronica, null, null, null);

        em.persist(p1);
        em.persist(p2);
        em.persist(p3);

        // @OneToOne con @MapsId: se crea DESPUÉS de que Producto ya tenga id
        FichaTecnica ficha1 = new FichaTecnica(p1, 0.9, "44x14x4 cm", 24);
        em.persist(ficha1);

        // @OneToMany con orphanRemoval: reseñas asociadas a un producto
        Resena r1 = new Resena(null, "Ana", "Muy buena relación calidad-precio.", 5, p1);
        Resena r2 = new Resena(null, "Luis", "Se calienta un poco.", 3, p1);
        em.persist(r1);
        em.persist(r2);
    }
}
