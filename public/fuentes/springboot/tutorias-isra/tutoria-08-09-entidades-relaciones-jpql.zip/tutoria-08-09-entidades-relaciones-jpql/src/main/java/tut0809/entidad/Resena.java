package tut0809.entidad;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

/**
 * Usa GenerationType.SEQUENCE en vez de IDENTITY, para tener un ejemplo real
 * en el proyecto (el resto de entidades usa IDENTITY, la estrategia recomendada
 * para MySQL/H2). H2 sí soporta secuencias, así que esta entidad arranca igual.
 */
@Entity
@Table(name = "resena")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@ToString(exclude = "producto")
public class Resena {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "resena_seq")
    @SequenceGenerator(name = "resena_seq", sequenceName = "seq_resena", allocationSize = 1)
    private Long id;

    @Column(nullable = false, length = 80)
    private String autor;

    @Column(nullable = false, length = 500)
    private String comentario;

    @Column(nullable = false)
    private Integer puntuacion;

    // @ManyToOne: Resena tiene la FK producto_id — es quien no puede existir sin su Producto
    // @JsonIgnore: sin esto, Producto -> resenas -> cada Resena -> producto -> resenas... bucle infinito
    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "producto_id", nullable = false)
    private Producto producto;
}
