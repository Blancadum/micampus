package tut0809.avanzado;
/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO] @Filter — filtrado automático a nivel de entidad (soft delete)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * @HIBERNATE FILTER — filtrado a nivel de entidad
 * ─────────────────────────────────────────────────
 *   Permite añadir condiciones de filtro que se aplican automáticamente
 *   a todas las queries de esa entidad cuando el filtro está activo.
 *
 *   Ejemplo: soft delete (borrado lógico) — en vez de un DELETE real, se marca
 *   la fila como inactiva y se queda para siempre en la tabla:
 *
 *   @Entity
 *   @FilterDef(name = "activoFilter", parameters = @ParamDef(name = "activo", type = Boolean.class))
 *   @Filter(name = "activoFilter", condition = "activo = :activo")
 *   public class Producto {
 *       private boolean activo = true;
 *   }
 *
 *   public void delete(Long id) {
 *       Producto p = repo.findById(id).orElseThrow();   // repo = un JpaRepository de Spring Data
 *       p.setActivo(false);
 *       repo.save(p);           // UPDATE, no DELETE
 *   }
 *
 *   Al activar el filtro: findAll() solo devuelve productos activos, sin que
 *   ninguna query tenga que escribir "WHERE activo = true" explícitamente.
 *
 *   → Las anotaciones solo DEFINEN el filtro, no lo activan. Sin activarlo, findAll()
 *     devuelve todos los productos igual que si el filtro no existiera.
 *   → Se activa por sesión, normalmente una vez por request (interceptor, aspecto o
 *     al inicio del método @Transactional), no en cada query:
 *        Session session = entityManager.unwrap(Session.class);
 *        session.enableFilter("activoFilter").setParameter("activo", true);
 *   → Mientras la sesión dure, toda query sobre Producto queda filtrada sin tocarla.
 *
 *   Alternativa más moderna (Hibernate 6.4+, sin @Filter/@FilterDef manual):
 *
 *   @Entity
 *   @SoftDelete(columnName = "activo", strategy = SoftDeleteType.ACTIVE)
 *   public class Producto { ... }
 *
 *   Con @SoftDelete, repo.deleteById(id) ya hace el UPDATE por debajo en vez
 *   del DELETE, y las queries excluyen los inactivos automáticamente — sin
 *   escribir el setActivo(false) a mano ni activar ningún filtro.
 *
 *
 * ¿ES UNA CLASE, O SOLO ANOTACIONES?
 * ─────────────────────────────────────
 *   @FilterDef/@Filter son puramente declarativos — no hay ninguna clase "Filter"
 *   que se implemente ni se instancie. Es distinto de:
 *     - jakarta.servlet.Filter / Spring Security: clases que interceptan peticiones HTTP,
 *       no tiene nada que ver con esto (mismo nombre, concepto totalmente distinto).
 *     - org.springframework.data.jpa.domain.Specification<T>: sí es un enfoque basado
 *       en clases/lambdas para construir consultas dinámicas, consulta a consulta,
 *       en vez de un filtro global como @Filter.
 *   Históricamente existía también una forma XML (ficheros .hbm.xml, anteriores a las
 *   anotaciones), pero es el estilo Hibernate pre-JPA de hace más de 15 años y no
 *   tiene sentido usarlo en un proyecto Spring Boot actual.
 */
public class _02_Hibernate_Filter {}
