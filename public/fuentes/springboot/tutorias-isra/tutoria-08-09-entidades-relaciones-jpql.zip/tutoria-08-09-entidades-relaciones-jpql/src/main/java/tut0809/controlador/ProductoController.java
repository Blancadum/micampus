package tut0809.controlador;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tut0809.entidad.Producto;
import tut0809.repositorio.ProductoRepositorioManual;

import java.util.List;

@RestController
@RequestMapping("/api/v1/productos")
public class ProductoController {

    private final ProductoRepositorioManual repo;

    public ProductoController(ProductoRepositorioManual repo) { this.repo = repo; }

    @GetMapping
    public List<Producto> findAll() { return repo.buscarTodos(); }

    @GetMapping("/{id}")
    public ResponseEntity<Producto> findById(@PathVariable Long id) {
        return repo.buscarPorId(id).map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/buscar")
    public List<Producto> buscar(@RequestParam String texto) {
        return repo.buscarPorTexto(texto);
    }

    @PostMapping
    public ResponseEntity<Producto> create(@RequestBody Producto producto) {
        return ResponseEntity.status(201).body(repo.guardar(producto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!repo.existePorId(id)) return ResponseEntity.notFound().build();
        repo.borrarPorId(id);
        return ResponseEntity.noContent().build();
    }
}
