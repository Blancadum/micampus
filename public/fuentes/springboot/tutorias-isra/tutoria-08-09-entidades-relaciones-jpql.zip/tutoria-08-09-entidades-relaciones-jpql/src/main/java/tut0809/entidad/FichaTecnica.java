package tut0809.entidad;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

/**
 * Relación @OneToOne compartiendo clave primaria con Producto (@MapsId):
 * FichaTecnica.id NO se autogenera, es el mismo valor que Producto.id.
 */
@Entity
@Table(name = "ficha_tecnica")
@Getter @Setter @NoArgsConstructor
@ToString(exclude = "producto")
public class FichaTecnica {

    @Id
    private Long id;

    // @JsonIgnore: sin esto, Producto -> fichaTecnica -> producto -> fichaTecnica... bucle infinito
    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    @MapsId
    @JoinColumn(name = "id")
    private Producto producto;

    private Double pesoKg;
    private String dimensiones;
    private Integer garantiaMeses;

    public FichaTecnica(Producto producto, Double pesoKg, String dimensiones, Integer garantiaMeses) {
        this.producto = producto;
        this.pesoKg = pesoKg;
        this.dimensiones = dimensiones;
        this.garantiaMeses = garantiaMeses;
    }
}
