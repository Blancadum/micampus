package tut0809.entidad;
import jakarta.persistence.*;
import lombok.*;
import java.util.ArrayList;
import java.util.List;

/** Dueño de las relaciones @ManyToOne y @ManyToMany — tiene las FKs (categoria_id + tabla intermedia). */
@Entity
@Table(name = "producto")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@ToString(exclude = {"categoria", "etiquetas", "fichaTecnica", "resenas"})
public class Producto {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 150)
    private String nombre;

    private Double precio;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EstadoProducto estado;

    // @ManyToOne: Producto tiene la FK categoria_id
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "categoria_id")
    private Categoria categoria;

    // @ManyToMany: Producto es dueño — tiene @JoinTable
    @ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinTable(
        name = "producto_etiqueta",
        joinColumns = @JoinColumn(name = "producto_id"),
        inverseJoinColumns = @JoinColumn(name = "etiqueta_id")
    )
    private List<Etiqueta> etiquetas = new ArrayList<>();

    // @OneToOne bidireccional: FichaTecnica es quien tiene @MapsId (comparte PK con Producto)
    @OneToOne(mappedBy = "producto", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private FichaTecnica fichaTecnica;

    // @OneToMany con orphanRemoval: una reseña no puede existir sin su producto
    @OneToMany(mappedBy = "producto", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Resena> resenas = new ArrayList<>();

    public enum EstadoProducto { DISPONIBLE, AGOTADO, DESCATALOGADO }
}
