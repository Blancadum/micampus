package tut0809.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 2: RELACIONES (@MANYTOONE/@ONETOMANY, @MANYTOMANY), CASCADA, LAZY/EAGER
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * DUEÑO DE LA RELACIÓN
 * ───────────────────────
 *   Producto.java tiene las dos relaciones y las dos FKs.
 *   Categoria.java tiene mappedBy="categoria" → Categoria NO tiene la FK, no es la dueña.
 *
 *   // En Categoria (lado "uno", sin FK):
 *   @OneToMany(mappedBy = "categoria", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
 *   private List<Producto> productos = new ArrayList<>();
 *
 *   Regla: el lado que tiene la FK (@ManyToOne) es siempre el dueño de la relación.
 *   El lado con mappedBy es el "inverso" — solo existe para navegar en Java,
 *   no añade ninguna columna nueva en su propia tabla.
 *
 *   "Dueño" no tiene nada que ver con LEER — la lectura funciona igual desde
 *   cualquiera de los dos lados (producto.getCategoria() o
 *   categoria.getProductos(), ambos cargan bien). Es sobre ESCRIBIR: Hibernate
 *   solo mira el lado dueño para decidir qué valor poner en la columna FK al
 *   guardar. El lado inverso lo ignora por completo:
 *
 *   // ✅ Funciona — tocas el lado dueño (tiene @JoinColumn)
 *   producto.setCategoria(nuevaCategoria);
 *   em.merge(producto);
 *   // → UPDATE producto SET categoria_id = ? WHERE id = ?
 *
 *   // ❌ NO hace nada en la BBDD — solo tocas el lado inverso
 *   categoria.getProductos().add(producto);
 *   em.merge(categoria);
 *   // → Ningún UPDATE sobre producto.categoria_id: Categoria.productos
 *   //   (mappedBy="categoria") no tiene autoridad para escribir nada, es
 *   //   solo una lista que Hibernate rellena leyendo
 *   //   "SELECT * FROM producto WHERE categoria_id = ?".
 *
 *   Es el error más típico con relaciones bidireccionales: parece natural en
 *   Java "meter el Producto en la lista de la Categoria", pero si no tocas
 *   también producto.setCategoria(...), ese cambio nunca llega a la BBDD.
 *
 *
 * @MANYTOMANY — TABLA INTERMEDIA
 * ─────────────────────────────────
 *   Producto <-> Etiqueta: un producto puede tener varias etiquetas, y una
 *   etiqueta puede estar en varios productos. Hibernate necesita una tercera
 *   tabla (producto_etiqueta) con las dos FKs.
 *
 *   // En Producto (dueño — tiene @JoinTable):
 *   @ManyToMany(fetch = FetchType.LAZY, cascade = {CascadeType.PERSIST, CascadeType.MERGE})
 *   @JoinTable(
 *       name = "producto_etiqueta",
 *       joinColumns = @JoinColumn(name = "producto_id"),
 *       inverseJoinColumns = @JoinColumn(name = "etiqueta_id")
 *   )
 *   private List<Etiqueta> etiquetas = new ArrayList<>();
 *
 *   // En Etiqueta (lado inverso, con mappedBy):
 *   @ManyToMany(mappedBy = "etiquetas", fetch = FetchType.LAZY)
 *   private List<Producto> productos = new ArrayList<>();
 *
 *   ⚠️ CascadeType.REMOVE/ALL en un @ManyToMany es peligroso: borrar un Producto
 *   borraría también sus Etiquetas de la BBDD, aunque otros productos las usen.
 *   Por eso aquí solo se usa PERSIST y MERGE, nunca REMOVE.
 *
 *
 * OPERACIONES EN CASCADA (CascadeType)
 * ───────────────────────────────────────
 *   Decide qué operaciones sobre el "padre" se propagan automáticamente a los "hijos".
 *
 *     PERSIST → al guardar el padre, se guardan los hijos nuevos.
 *     MERGE   → al actualizar el padre, se actualizan los hijos.
 *     REMOVE  → al borrar el padre, se borran los hijos.
 *     REFRESH → al recargar el padre desde BBDD, se recargan los hijos.
 *     ALL     → las cuatro anteriores juntas.
 *
 *   Ejemplo real — Producto → Resena (una reseña no tiene sentido sin su producto):
 *
 *   // En Producto:
 *   @OneToMany(mappedBy = "producto", cascade = CascadeType.ALL, orphanRemoval = true)
 *   private List<Resena> resenas = new ArrayList<>();
 *
 *   Con cascade=ALL: producto.getResenas().add(nuevaResena); em.merge(producto);
 *   guarda también la reseña nueva, sin necesidad de un em.persist(nuevaResena) aparte.
 *
 *
 * ORPHANREMOVAL — ELIMINAR HIJOS HUÉRFANOS AUTOMÁTICAMENTE
 * ────────────────────────────────────────────────────────────
 *   producto.getResenas().remove(resena);  // al hacer commit: DELETE FROM resena WHERE id=?
 *
 *   → orphanRemoval=true: al quitar un hijo de la colección, Hibernate lo elimina de la BBDD,
 *     aunque no hayas llamado a ningún delete explícitamente.
 *   → Solo tiene sentido cuando los hijos no pueden existir sin el padre (como Resena).
 *   → NO usar en @ManyToMany (cada lado puede tener varios "padres" — por eso Producto/Etiqueta
 *     no lo lleva).
 *
 *
 * CUIDADO CON LA RECURSIVIDAD INFINITA EN toString()
 * ──────────────────────────────────────────────────────
 *   Si Producto.toString() incluye categoria, y Categoria.toString() incluye su
 *   lista de productos, cada producto imprime su categoría, que imprime sus
 *   productos, que imprimen su categoría... → StackOverflowError.
 *
 *   Por eso en este proyecto todas las entidades usan:
 *     @ToString(exclude = {"categoria", "etiquetas", ...})
 *
 *
 * LA MISMA RECURSIVIDAD, PERO AL DEVOLVER JSON (@JsonIgnore)
 * ────────────────────────────────────────────────────────────────
 *   El mismo problema de toString() ocurre al serializar a JSON en el Controller:
 *   Producto -> categoria -> productos -> cada Producto -> categoria -> ... bucle
 *   infinito, pero esta vez lanza StackOverflowError al hacer la petición HTTP,
 *   no al hacer un println. Por eso en este proyecto el lado "inverso" de cada
 *   relación bidireccional (Categoria.productos, Etiqueta.productos,
 *   Resena.producto, FichaTecnica.producto) lleva @JsonIgnore además de estar
 *   excluido del toString().
 *
 *   → @JsonIgnore es un parche razonable para un proyecto de ejemplo como este,
 *     pero NO es la solución recomendada en un proyecto real: esto es
 *     devolver la entidad JPA directamente en la respuesta HTTP, con el mismo
 *     problema de fondo que ya explica LazyInitializationException más abajo.
 *     La solución de verdad son los DTOs: el DTO decide exactamente qué campos 
 *     exponer, así que el bucle de serialización ni siquiera puede ocurrir.
 *   Lombok genera el toString() sin esos campos relacionados, cortando el bucle.
 *
 *
 * LAZY vs EAGER — CUÁNDO SE CARGA LA RELACIÓN
 * ────────────────────────────────────────────────
 *   LAZY (recomendado siempre que se pueda): Hibernate NO trae la relación hasta
 *   que accedes a ella con un getter.
 *
 *   EAGER: Hibernate la trae siempre, en el mismo SELECT o con uno adicional
 *   inmediato — aunque no la vayas a usar.
 *
 *
 * EL PROBLEMA N+1
 * ──────────────────
 *   Tienes 100 productos, cada uno con @ManyToOne Categoria LAZY.
 *   Iteras sobre todos y llamas a producto.getCategoria().getNombre().
 *
 *   → 1 SELECT para traer los 100 productos
 *   → 100 SELECT adicionales, uno por cada .getCategoria() (Hibernate no sabe
 *     de antemano que vas a acceder a todas, así que hace una consulta por cada una)
 *   → Total: 101 queries, en vez de 1 o 2 optimizadas.
 *
 *   Se soluciona con JOIN FETCH en la query (ved Bloque 3, JPQL) o con DTOs
 *   que traigan de antemano justo los campos que hacen falta.
 *
 *
 * LAZYINITIALIZATIONEXCEPTION — EL ERROR MÁS FRECUENTE CON JPA
 * ──────────────────────────────────────────────────────────────
 *   El error: "failed to lazily initialize a collection ... no Session"
 *
 *   Ocurre cuando intentas acceder a un campo LAZY fuera de una transacción
 *   (la entidad ya está en estado DETACHED, ved Bloque 1 — ciclo de vida):
 *   - El método del Service no tiene @Transactional
 *   - El Controller intenta acceder a la relación LAZY después de que el Service la devolvió
 *
 *   SOLUCIONES:
 *   1. @Transactional en el método del Service que accede al campo LAZY.
 *   2. Usar DTOs: convertir Entity → DTO dentro de la transacción del Service
 *      (el DTO no tiene campos LAZY; solo los datos que necesitas).
 *   3. JOIN FETCH en la query para cargar todo de una vez.
 *
 *   La solución recomendada: DTOs (evita exponer entidades fuera del Service).
 *
 *   Ver implementación completa: entidad/Producto.java, entidad/Categoria.java,
 *   entidad/Etiqueta.java, entidad/Resena.java, entidad/FichaTecnica.java.
 */
public class _02_Relaciones_Cascada {
    // Ver implementación: tut0809/entidad/*.java
}
