package tut0809.repositorio;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import tut0809.entidad.Producto;

import java.util.List;
import java.util.Optional;

@Repository
public class ProductoRepositorioManual {

    @PersistenceContext
    private EntityManager em;

    // -- CRUD básico ----------------------------------------------------------

    public List<Producto> buscarTodos() {
        return em.createQuery("SELECT p FROM Producto p", Producto.class).getResultList();
    }

    public Optional<Producto> buscarPorId(Long id) {
        return Optional.ofNullable(em.find(Producto.class, id));
    }

    // @Transactional: persist()/remove() exigen una transacción activa, a
    // diferencia de una simple lectura con find() — ver la explicación del
    // ciclo de vida de la entidad en explicacion/_01_Entidad_Anotaciones.java.
    @Transactional
    public Producto guardar(Producto producto) {
        if (producto.getId() == null) {
            em.persist(producto);
            return producto;
        }
        return em.merge(producto);
    }

    public boolean existePorId(Long id) {
        return em.find(Producto.class, id) != null;
    }

    @Transactional
    public void borrarPorId(Long id) {
        Producto producto = em.find(Producto.class, id);
        if (producto != null) {
            em.remove(producto);
        }
    }

    // -- Consultas JPQL (Bloque 3) ----------------------------------------------

    public List<Producto> buscarPorTexto(String texto) {
        TypedQuery<Producto> query = em.createQuery(
                "SELECT p FROM Producto p WHERE LOWER(p.nombre) LIKE LOWER(CONCAT('%', :texto, '%'))",
                Producto.class);
        query.setParameter("texto", texto);
        return query.getResultList();
    }

    public List<Producto> findByEtiqueta(String etiqueta) {
        TypedQuery<Producto> query = em.createQuery(
                "SELECT p FROM Producto p JOIN p.etiquetas e WHERE e.nombre = :etiqueta",
                Producto.class);
        query.setParameter("etiqueta", etiqueta);
        return query.getResultList();
    }

    public long countByEstado(Producto.EstadoProducto estado) {
        TypedQuery<Long> query = em.createQuery(
                "SELECT COUNT(p) FROM Producto p WHERE p.estado = :estado", Long.class);
        query.setParameter("estado", estado);
        return query.getSingleResult();
    }

    public Double precioMedioPorCategoria(Long categoriaId) {
        TypedQuery<Double> query = em.createQuery(
                "SELECT AVG(p.precio) FROM Producto p WHERE p.categoria.id = :categoriaId", Double.class);
        query.setParameter("categoriaId", categoriaId);
        return query.getSingleResult();
    }

    public List<String> categoriasConProductoEnEstado(Producto.EstadoProducto estado) {
        TypedQuery<String> query = em.createQuery(
                "SELECT DISTINCT p.categoria.nombre FROM Producto p WHERE p.estado = :estado", String.class);
        query.setParameter("estado", estado);
        return query.getResultList();
    }
}
