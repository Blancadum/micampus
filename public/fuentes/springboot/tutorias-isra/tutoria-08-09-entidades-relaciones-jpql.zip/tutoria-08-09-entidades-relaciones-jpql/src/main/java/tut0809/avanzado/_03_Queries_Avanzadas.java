package tut0809.avanzado;
/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO] Filtros opcionales combinables + consultas nativas con GROUP BY
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * FILTROS OPCIONALES COMBINABLES EN UN ÚNICO ENDPOINT
 * ────────────────────────────────────────────────────────
 *   Problema: un cliente de la API quiere poder filtrar productos por estado,
 *   por categoría, por ambos a la vez, o por ninguno — con un solo endpoint,
 *   no uno distinto por cada combinación posible.
 *
 *   @Query("SELECT p FROM Producto p WHERE " +
 *          "(:estado IS NULL OR p.estado = :estado) AND " +
 *          "(:categoriaId IS NULL OR p.categoria.id = :categoriaId)")
 *   List<Producto> findByFiltros(@Param("estado") Producto.EstadoProducto estado,
 *                                 @Param("categoriaId") Long categoriaId);
 *
 *   // En el Controller, ambos parámetros opcionales:
 *   @GetMapping
 *   public List<Producto> buscar(@RequestParam(required = false) Producto.EstadoProducto estado,
 *                                 @RequestParam(required = false) Long categoriaId) {
 *       return repo.findByFiltros(estado, categoriaId);
 *   }
 *
 *   → "(:estado IS NULL OR p.estado = :estado)": si el cliente no manda ese
 *     parámetro (llega null), la condición se evalúa siempre a verdadero y no
 *     filtra por ese campo; si lo manda, filtra con normalidad.
 *   → Ventaja frente a escribir tres @Query por separado (solo por estado, solo
 *     por categoría, por ambos a la vez): un único método cubre todas las
 *     combinaciones, sin multiplicar consultas casi idénticas.
 *   → Desventaja: el plan de ejecución SQL es algo menos óptimo que una query
 *     específica por caso, porque la BBDD tiene que evaluar la condición OR.
 *     Para tablas pequeñas/medianas no es un problema real.
 *
 *
 * CONSULTAS NATIVAS CON GROUP BY (INFORME AGRUPADO)
 * ────────────────────────────────────────────────────
 *   El Bloque 3 ya enseñó COUNT y AVG con JPQL normal, pero sin GROUP BY — es
 *   decir, "cuántos productos hay con ESTE estado concreto" (un número). Si lo
 *   que hace falta es un informe con el desglose de TODOS los estados a la vez
 *   en una sola llamada, hace falta GROUP BY:
 *
 *   @Query(value = "SELECT estado, COUNT(*) FROM producto GROUP BY estado", nativeQuery = true)
 *   List<Object[]> contarPorEstado();
 *
 *   → nativeQuery = true: aquí "producto" y "estado" SÍ son el nombre real de
 *     la tabla y la columna SQL, no la entidad/campo Java (al contrario que en
 *     todo el resto de este proyecto, que usa JPQL).
 *   → El resultado es una lista de arrays: cada Object[] es una fila, con
 *     posición 0 = estado, posición 1 = conteo. Hay que castear a mano:
 *
 *   Map<String, Long> resultado = new LinkedHashMap<>();
 *   for (Object[] fila : repo.contarPorEstado()) {
 *       resultado.put((String) fila[0], (Long) fila[1]);
 *   }
 *
 *   → Esta transformación de Object[] a un formato legible debe hacerse en el
 *     Service, nunca en el Controller — el Controller no debe conocer el
 *     formato "en bruto" que devuelve la BBDD.
 *   → Usar nativeQuery solo cuando JPQL no baste (como aquí, para GROUP BY con
 *     varias filas de resultado): si una query puede escribirse en JPQL, se
 *     escribe en JPQL — es portable entre motores de BBDD, esto no.
 *   → Con parámetros en una query nativa, seguid usando @Param igual que en
 *     JPQL — nunca concatenar valores directamente en el String de la query
 *     (eso es una inyección SQL, el mismo problema que con JDBC puro).
 */
public class _03_Queries_Avanzadas {}
