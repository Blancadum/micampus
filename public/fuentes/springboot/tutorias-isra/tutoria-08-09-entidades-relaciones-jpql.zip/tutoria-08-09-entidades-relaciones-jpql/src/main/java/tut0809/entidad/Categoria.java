package tut0809.entidad;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import java.util.ArrayList;
import java.util.List;

/** Dueño del lado "uno" — tiene mappedBy porque NO tiene la FK. */
@Entity
@Table(name = "categoria", uniqueConstraints = @UniqueConstraint(name = "uk_categoria_nombre", columnNames = "nombre"))
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@ToString(exclude = "productos")  // evitar bucle en toString con relación bidireccional
public class Categoria {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 80)
    private String nombre;

    // @OneToMany: un lado sin FK — mappedBy apunta al campo de Producto que tiene la FK
    // @JsonIgnore: sin esto, serializar un Producto -> su Categoria -> su lista de
    // Productos -> la Categoria de cada uno... entra en bucle infinito (StackOverflowError).
    @JsonIgnore
    @OneToMany(mappedBy = "categoria", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Producto> productos = new ArrayList<>();
}
