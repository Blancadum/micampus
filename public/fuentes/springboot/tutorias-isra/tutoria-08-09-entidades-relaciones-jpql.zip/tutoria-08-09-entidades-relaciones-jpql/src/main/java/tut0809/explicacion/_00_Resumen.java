package tut0809.explicacion;

public class _00_Resumen {
    public static void main(String[] args) {
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  TUTORÍA 8-9 — MODELADO DE ENTIDADES + RELACIONES + JPQL");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println();
        System.out.println("1. ANOTACIONES DE ENTIDAD");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  @Entity              → esta clase mapea a una tabla de BBDD");
        System.out.println("  @Table(name=..)      → nombre de la tabla, uniqueConstraints, indexes");
        System.out.println("  @Id                  → clave primaria");
        System.out.println("  @GeneratedValue       → Spring/Hibernate genera el id automáticamente");
        System.out.println("  @Column              → personaliza la columna (nombre, longitud, nullable)");
        System.out.println("  @Enumerated          → mapea enum a String o a INT");
        System.out.println();
        System.out.println("2. ESTRATEGIAS DE GENERACIÓN DE ID");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  IDENTITY  → autoincrement de la BBDD (MySQL, H2)  ← la que usa este curso");
        System.out.println("  SEQUENCE  → secuencia de BBDD (PostgreSQL, Oracle) — ejemplo real en Resena");
        System.out.println("  TABLE     → tabla auxiliar que simula una secuencia (evitar, es la más lenta)");
        System.out.println("  AUTO      → Hibernate elige según el driver (no recomendado en producción)");
        System.out.println();
        System.out.println("3. RELACIONES");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  @ManyToOne/@OneToMany → Producto (FK) / Categoria (mappedBy)");
        System.out.println("  @ManyToMany            → Producto <-> Etiqueta, con @JoinTable");
        System.out.println("  @OneToOne + @MapsId    → Producto <-> FichaTecnica (misma PK)");
        System.out.println("  FetchType.LAZY          → se carga solo cuando se accede, evita N+1 masivo");
        System.out.println();
        System.out.println("4. JPQL");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  Opera sobre ENTIDADES (Producto, nombre), no sobre TABLAS (producto, nombre)");
        System.out.println("  Se ejecuta con EntityManager.createQuery(jpql, Tipo.class), con parámetros");
        System.out.println("  nombrados (setParameter), no posicionales");
        System.out.println();
        System.out.println("  Demo: http://localhost:8098/api/v1/productos");
        System.out.println("  H2 Console: http://localhost:8098/h2-console (JDBC URL: jdbc:h2:mem:tiendadb)");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
    }
}
