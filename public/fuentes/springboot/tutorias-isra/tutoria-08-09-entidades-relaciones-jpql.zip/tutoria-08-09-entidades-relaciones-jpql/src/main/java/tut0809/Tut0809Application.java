package tut0809;
import com.fasterxml.jackson.datatype.hibernate6.Hibernate6Module;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
@SpringBootApplication
public class Tut0809Application {
    public static void main(String[] args) { SpringApplication.run(Tut0809Application.class, args); }

    // Spring Boot registra automáticamente cualquier bean Module en el ObjectMapper.
    // Sin esto, Jackson intenta serializar el proxy de Hibernate de una relación LAZY
    // (p.ej. Producto.categoria) en vez de la entidad real, y falla con
    // InvalidDefinitionException sobre "hibernateLazyInitializer".
    // FORCE_LAZY_LOADING: con spring.jpa.open-in-view=true (por defecto) la sesión sigue
    // abierta durante la serialización, así que forzar la carga aquí es seguro y evita
    // que las relaciones LAZY salgan como null en el JSON de este proyecto de ejemplo.
    @Bean
    public Hibernate6Module hibernate6Module() {
        Hibernate6Module module = new Hibernate6Module();
        module.enable(Hibernate6Module.Feature.FORCE_LAZY_LOADING);
        return module;
    }
}
