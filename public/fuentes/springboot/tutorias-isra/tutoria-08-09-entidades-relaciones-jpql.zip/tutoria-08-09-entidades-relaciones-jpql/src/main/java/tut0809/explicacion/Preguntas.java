package tut0809.explicacion;

public class Preguntas {
    public static void main(String[] args) {
        p1(); p2(); p3(); p4(); p5(); p6(); p7(); p8(); p9(); p10();
    }

    static void p1() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P1                                                               │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  Tu clase tiene @Entity pero Hibernate lanza error al arrancar.");
        System.out.println("  ¿Cuál es la causa más probable?");
        System.out.println("  a) Falta la anotación @Table  b) Falta @Column en todos los campos");
        System.out.println("  c) Falta el constructor sin argumentos  d) El nombre de la clase es incorrecto");
        System.out.println();




























        // System.out.println("  RESPUESTA: c) Constructor sin argumentos — JPA lo exige obligatoriamente.");
        System.out.println();
    }

    static void p2() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P2                                                               │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  Tienes: enum EstadoProducto { DISPONIBLE, AGOTADO, DESCATALOGADO }");
        System.out.println("  ¿Qué problema tiene @Enumerated(EnumType.ORDINAL)?");
        System.out.println("  a) Es más lento que STRING al tener que mapear índices numéricos");
        System.out.println("  b) No funciona con H2");
        System.out.println("  c) No hay diferencia práctica");
        System.out.println("  d) Guarda 0,1,2: si reordenas el enum los datos históricos cambian");
        System.out.println();




























        // System.out.println("  RESPUESTA: d) ORDINAL guarda posición: reordenar el enum rompe datos históricos.");
        System.out.println();
    }

    static void p3() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P3                                                               │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  Tabla 'producto' tiene columna 'categoria_id'.");
        System.out.println("  Categoria.java tiene @OneToMany(mappedBy=\"categoria\").");
        System.out.println("  ¿Qué indica mappedBy=\"categoria\" y quién es el dueño de la relación?");
        System.out.println("  a) Categoria es el dueño, mappedBy solo indica el nombre de columna");
        System.out.println("  b) El campo 'categoria' en Producto tiene la FK — Producto es el dueño");
        System.out.println("  c) Es el nombre del join column que Hibernate genera automáticamente");
        System.out.println("  d) mappedBy da igual quién sea el dueño, ambos lados mandan por igual");
        System.out.println();




























        // System.out.println("  RESPUESTA: b) mappedBy apunta al campo del otro lado que tiene la FK — ese es el dueño.");
        System.out.println();
    }

    static void p4() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P4                                                               │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  Tienes 100 productos, cada uno con @ManyToOne Categoria LAZY.");
        System.out.println("  Iteras sobre todos y llamas a getCategoria().getNombre().");
        System.out.println("  ¿Cuántas queries SQL ejecuta Hibernate?");
        System.out.println("  a) 1  b) 101  c) 2  d) 200");
        System.out.println();




























        // System.out.println("  RESPUESTA: b) 101 — 1 SELECT productos + 100 SELECT categoria WHERE id=?");
        System.out.println();
    }

    static void p5() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P5                                                               │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  Tienes @ManyToMany entre Producto y Etiqueta.");
        System.out.println("  ¿Qué CascadeType es peligroso usar en esta relación?");
        System.out.println("  a) REMOVE / ALL  b) PERSIST  c) MERGE  d) REFRESH");
        System.out.println();




























        // System.out.println("  RESPUESTA: a) REMOVE/ALL: eliminaría Etiquetas usadas por otros Productos.");
        System.out.println();
    }

    static void p6() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P6                                                               │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Cuál es la diferencia clave entre JPQL y SQL?");
        System.out.println("  a) JPQL es más rápido que SQL");
        System.out.println("  b) SQL es más portable entre distintas BBDD");
        System.out.println("  c) JPQL opera sobre entidades Java; SQL sobre tablas de BBDD");
        System.out.println("  d) JPQL no soporta JOIN entre distintas entidades relacionadas");
        System.out.println();




























        // System.out.println("  RESPUESTA: c) JPQL usa nombres de entidad/campo Java, no tabla/columna BBDD.");
        System.out.println();
    }

    static void p7() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P7                                                               │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Qué hace @JoinTable en una relación @ManyToMany?");
        System.out.println("  a) Crea una columna en la tabla del dueño");
        System.out.println("  b) Agrega índices a la relación para acelerar las consultas");
        System.out.println("  c) Define el FetchType de la relación");
        System.out.println("  d) Define la tabla intermedia y sus columnas FK");
        System.out.println();




























        // System.out.println("  RESPUESTA: d) @JoinTable define la tabla intermedia (nombre + columnas FK).");
        System.out.println();
    }

    static void p8() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P8                                                               │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Qué hace spring.jpa.hibernate.ddl-auto=create-drop?");
        System.out.println("  a) Solo crea tablas, nunca las elimina");
        System.out.println("  b) Valida que las tablas coinciden con las entidades pero no las modifica");
        System.out.println("  c) Crea tablas al arrancar y las elimina al parar la app");
        System.out.println("  d) Genera un script SQL pero no lo ejecuta");
        System.out.println();




























        // System.out.println("  RESPUESTA: c) create-drop: ideal para desarrollo/tests, NUNCA en producción.");
        System.out.println();
    }

    static void p9() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P9                                                               │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  FichaTecnica tiene @Id private Long id; (sin @GeneratedValue) y");
        System.out.println("  @OneToOne @MapsId @JoinColumn(name=\"id\") private Producto producto;");
        System.out.println("  ¿Qué diferencia hay con un @OneToOne normal (cada uno con su propio id)?");
        System.out.println("  a) Ninguna, son exactamente iguales");
        System.out.println("  b) FichaTecnica comparte el mismo valor de id que su Producto");
        System.out.println("  c) @MapsId solo funciona en relaciones @ManyToMany");
        System.out.println("  d) @MapsId elimina la necesidad de que exista @JoinColumn");
        System.out.println();




























        // System.out.println("  RESPUESTA: b) @MapsId: la PK de FichaTecnica ES la PK del Producto asociado.");
        System.out.println();
    }

    static void p10() {
        System.out.println("┌──────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P10                                                              │");
        System.out.println("└──────────────────────────────────────────────────────────────────┘");
        System.out.println("  Producto → Resena tiene cascade=ALL pero orphanRemoval=false.");
        System.out.println("  Haces producto.getResenas().remove(resena) y guardas el producto.");
        System.out.println("  ¿Qué pasa con esa reseña en la tabla resena?");
        System.out.println("  a) Se borra igual, cascade=ALL ya incluye ese caso");
        System.out.println("  b) Sigue existiendo en BBDD con su producto_id, aunque ya no esté en la lista Java");
        System.out.println("  c) Lanza una excepción al guardar");
        System.out.println("  d) Su producto_id pasa a NULL automáticamente");
        System.out.println();




























        // System.out.println("  RESPUESTA: b) cascade=REMOVE solo actúa al borrar el PADRE; para 'huérfanos'");
        // System.out.println("  al quitarlos de la colección hace falta orphanRemoval=true.");
        System.out.println();
    }
}
