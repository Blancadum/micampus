package tut0809.entidad;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import java.util.ArrayList;
import java.util.List;

@Entity @Table(name = "etiqueta")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@ToString(exclude = "productos")
public class Etiqueta {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String nombre;

    // Lado inverso de la relación ManyToMany — @JsonIgnore por el mismo motivo que en Categoria
    @JsonIgnore
    @ManyToMany(mappedBy = "etiquetas", fetch = FetchType.LAZY)
    private List<Producto> productos = new ArrayList<>();
}
