package tut0809.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 3: JPQL — CONSULTAS SOBRE ENTIDADES, NO SOBRE TABLAS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * QUÉ ES JPQL Y EN QUÉ SE DIFERENCIA DE SQL
 * ──────────────────────────────────────────────
 *   JPQL (Java Persistence Query Language) es un lenguaje de consulta que
 *   opera sobre ENTIDADES y sus CAMPOS Java, no sobre tablas y columnas SQL:
 *
 *     JPQL: SELECT p FROM Producto p WHERE p.nombre LIKE '%teclado%'
 *     SQL:  SELECT * FROM producto WHERE nombre LIKE '%teclado%'
 *
 *   → "Producto" y "p.nombre" son el nombre de la clase Java y del atributo,
 *     no el nombre de la tabla ni de la columna (aunque en este proyecto
 *     coincidan, no tiene por qué ser así).
 *   → JPQL es independiente del motor de BBDD; SQL nativo no lo es.
 *
 *
 * ENTITYMANAGER — CÓMO SE EJECUTA UNA JPQL A MANO
 * ────────────────────────────────────────────────────
 *   El EntityManager es la pieza central de JPA: gestiona el ciclo de vida de
 *   las entidades (ved Bloque 1) y también es quien ejecuta JPQL. Se inyecta
 *   con @PersistenceContext, se le pasa la query como String y el tipo de
 *   resultado esperado:
 *
 *   @PersistenceContext
 *   private EntityManager em;
 *
 *   public long contarProductos() {
 *       TypedQuery<Long> query = em.createQuery("SELECT COUNT(p) FROM Producto p", Long.class);
 *       return query.getSingleResult();
 *   }
 *
 *   → createQuery(jpql, TipoResultado.class) devuelve un TypedQuery — con el
 *     tipo ya fijado, sin necesidad de castear el resultado.
 *   → getSingleResult() cuando esperas exactamente un resultado (un número,
 *     una entidad por id...); getResultList() cuando esperas una lista.
 *
 *
 * PARÁMETROS: NOMBRADOS (RECOMENDADO) FRENTE A POSICIONALES
 * ──────────────────────────────────────────────────────────────
 *   Nombrados — :texto en la query + setParameter("texto", valor) — más
 *   legibles, no dependen del orden:
 *
 *   TypedQuery<Producto> query = em.createQuery(
 *       "SELECT p FROM Producto p WHERE LOWER(p.nombre) LIKE LOWER(CONCAT('%', :texto, '%'))",
 *       Producto.class);
 *   query.setParameter("texto", texto);
 *
 *   Posicionales — ?1, ?2... + setParameter(1, valor) — evitar: si cambias el
 *   orden de los setParameter sin darte cuenta, la query sigue compilando
 *   pero hace algo distinto a lo que querías:
 *
 *   TypedQuery<Producto> query = em.createQuery(
 *       "SELECT p FROM Producto p WHERE p.precio BETWEEN ?1 AND ?2", Producto.class);
 *   query.setParameter(1, precioMin);
 *   query.setParameter(2, precioMax);
 *
 *   → Funciona — pero si alguien reordena estas dos líneas sin querer
 *     (setParameter(2, precioMax) antes que setParameter(1, precioMin)),
 *     o si más adelante se añade un ?3 al principio de la query y no se
 *     renumeran ?1/?2, el código sigue compilando perfectamente y la
 *     aplicación arranca sin error — simplemente devuelve productos con
 *     el rango de precio invertido o equivocado, un bug silencioso mucho
 *     más difícil de detectar que uno que no compila. Con :precioMin/
 *     :precioMax nombrados, ese error de reordenación es imposible: el
 *     nombre deja claro qué valor va en qué hueco, sin importar el orden
 *     de las líneas setParameter.
 *
 *
 * JOIN ENTRE ENTIDADES RELACIONADAS
 * ─────────────────────────────────────
 *   em.createQuery("SELECT p FROM Producto p JOIN p.etiquetas e WHERE e.nombre = :etiqueta", Producto.class);
 *
 *   → "p.etiquetas" navega la relación @ManyToMany ya mapeada en la entidad;
 *     no hace falta escribir el JOIN de tablas a mano (producto_etiqueta...).
 *
 *
 * DISTINCT
 * ──────────
 *   em.createQuery("SELECT DISTINCT p.categoria.nombre FROM Producto p WHERE p.estado = :estado", String.class);
 *
 *   → Sin DISTINCT, si dos productos AGOTADOS son de la misma categoría, el
 *     nombre de esa categoría saldría repetido en el resultado.
 *
 *
 * AGREGACIONES: COUNT, AVG (SIN GROUP BY)
 * ────────────────────────────────────────────
 *   JPQL soporta funciones de agregación exactamente igual que SQL:
 *
 *   em.createQuery("SELECT COUNT(p) FROM Producto p WHERE p.estado = :estado", Long.class);
 *   em.createQuery("SELECT AVG(p.precio) FROM Producto p WHERE p.categoria.id = :categoriaId", Double.class);
 *
 *   → El tipo pasado a createQuery coincide con lo que devuelve la agregación:
 *     COUNT es un entero (Long), AVG un decimal (Double).
 *   → GROUP BY (varias filas agrupadas a la vez, un conteo por cada valor
 *     distinto) es otra herramienta más específica que se trabaja en el
 *     apéndice avanzado, cuando ya dominéis lo de aquí.
 *
 *
 * PROYECCIÓN A DTO DENTRO DE LA PROPIA CONSULTA (constructor expression)
 * ───────────────────────────────────────────────────────────────────────────
 *   JPQL permite construir directamente un DTO en el SELECT, sin traer la
 *   entidad completa:
 *
 *   em.createQuery(
 *       "SELECT new com.ejemplo.dto.ProductoResumenDTO(p.id, p.nombre, p.precio) " +
 *       "FROM Producto p WHERE p.categoria.id = :categoriaId", ProductoResumenDTO.class);
 *
 *   → El DTO necesita un constructor con exactamente esos parámetros, en ese orden.
 *   → Ventaja: menos datos viajan de la BBDD a Java (solo los 3 campos, no la
 *     entidad completa con todas sus relaciones).
 *
 *
 * SUBCONSULTAS (SOLO EN WHERE)
 * ────────────────────────────────
 *   em.createQuery(
 *       "SELECT p FROM Producto p WHERE p.precio > (SELECT AVG(p2.precio) FROM Producto p2)",
 *       Producto.class);
 *
 *   → Productos cuyo precio supera el precio medio de TODOS los productos.
 *
 *
 * Ver implementación completa (las cinco consultas de este bloque, ya
 * ejecutables): repositorio/ProductoRepositorioManual.java.
 * Para el patrón de filtros opcionales y las consultas nativas con GROUP BY,
 * ved avanzado/_03_Queries_Avanzadas.java.
 */
public class _03_JPQL {
    // Ver implementación: tut0809/repositorio/ProductoRepositorioManual.java
}
