package tut06.avanzado;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO] HATEOAS y versionado de APIs
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * HATEOAS (Hypermedia As The Engine Of Application State)
 * ────────────────────────────────────────────────────────
 * Nivel 3 de madurez de APIs REST (Modelo Richardson).
 *
 * El modelo de Richardson mide qué tan "REST" es una API:
 *
 *   | Nivel | Qué tiene                                                          |
 *   |-------|--------------------------------------------------------------------|
 *   |   0   | Un solo endpoint para todo, tipo RPC                               |
 *   |   1   | Recursos separados (/productos, /clientes)                         |
 *   |   2   | Verbos HTTP y códigos de estado correctos (GET, POST, 404...).     |
 *   |       | → Aquí está casi todo el mundo                                     |
 *   |   3   | HATEOAS: las respuestas incluyen enlaces                           |
 *
 * Las respuestas incluyen LINKS a acciones relacionadas:
 *
 *   {
 *     "id": 1, "nombre": "Teclado", "precio": 79.99,
 *     "_links": {
 *       "self":   { "href": "/api/v1/productos/1" },
 *       "update": { "href": "/api/v1/productos/1", "method": "PUT" },
 *       "delete": { "href": "/api/v1/productos/1", "method": "DELETE" },
 *       "all":    { "href": "/api/v1/productos" }
 *     }
 *   }
 *
 *   Qué significa cada enlace:
 *
 *   | Enlace | Significado                              |
 *   |--------|------------------------------------------|
 *   | self   | La URL de este mismo recurso             |
 *   | update | Cómo modificarlo: PUT a esa URL          |
 *   | delete | Cómo borrarlo: DELETE a esa URL          |
 *   | all    | Cómo volver al listado de productos      |
 *
 *   En resumen: HATEOAS significa que la API no solo devuelve datos,
 *   sino que además incluye enlaces que indican qué acciones se pueden
 *   realizar después. El cliente no tiene que "adivinar" rutas ni estar
 *   totalmente acoplado a la estructura de la API: la propia respuesta le
 *   guía. Es una idea muy RESTful, aunque en proyectos reales solo se
 *   implementa en APIs más avanzadas o muy extensibles.
 *
 *   El cliente descubre las operaciones disponibles sin documentación externa.
 *   Spring HATEOAS: spring-boot-starter-hateoas
 *
 *
 * ESTRATEGIAS DE VERSIONADO DE APIs
 * ────────────────────────────────────
 *   1. URL versioning (la más común):
 *      /api/v1/productos  → /api/v2/productos
 *
 *   2. Header versioning:
 *      Accept: application/vnd.empresa.v2+json
 *
 *   3. Query parameter:
 *      /api/productos?version=2
 *
 *   4. Media type (Content Negotiation):
 *      Content-Type: application/vnd.empresa-v2+json
 *
 *   → URL versioning es la más legible y la más usada en proyectos reales.
 *   → Nunca cambies una API pública sin versionar — rompes los clientes existentes.
 *
 *
 * OPENAPI 3 — DOCUMENTACIÓN FORMAL
 * ──────────────────────────────────
 * Las APIs REST deben documentarse con OpenAPI 3 (Swagger).
 * Se verá en Tutoría 12. Con springdoc-openapi:
 *   → http://localhost:8086/swagger-ui.html
 *   → http://localhost:8086/v3/api-docs (JSON de la especificación)
 */
public class _01_HATEOAS_Versionado {
}
