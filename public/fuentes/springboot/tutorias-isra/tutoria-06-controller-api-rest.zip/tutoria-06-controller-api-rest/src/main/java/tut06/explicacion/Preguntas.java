package tut06.explicacion;

public class Preguntas {
    public static void main(String[] args) {
        pregunta1(); pregunta2(); pregunta3(); pregunta4(); pregunta5();
    }

    static void pregunta1() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P1                                                             │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println("  GET /api/v1/productos/42       → ¿qué anotación recibe el 42?");
        System.out.println("  GET /api/v1/productos?min=20   → ¿qué anotación recibe el 20?");
        System.out.println();
        System.out.println("  a) @PathVariable para /42, @RequestParam para ?min=20");
        System.out.println("  b) Ambos @PathVariable, ya que ambos identifican el mismo recurso");
        System.out.println("  c) Ambos @RequestParam");
        System.out.println("  d) @RequestBody para ambos");
        System.out.println();




























































        // System.out.println("  RESPUESTA: a) @PathVariable para segmentos del path, @RequestParam para query string.");
        System.out.println();
    }

    static void pregunta2() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P2                                                             │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println("  Un POST /api/v1/productos crea un producto correctamente.");
        System.out.println("  ¿Qué código HTTP debe devolver?");
        System.out.println();
        System.out.println("  a) 200 OK    b) 201 Created    c) 204 No Content    d) 202 Accepted");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) 201 Created — estándar REST para creación exitosa.");
        System.out.println();
    }

    static void pregunta3() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P3                                                             │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println("  Un DELETE /api/v1/productos/5 elimina el producto. ¿Código correcto?");
        System.out.println();
        System.out.println("  a) 200 OK    b) 201 Created    c) 204 No Content    d) 404 Not Found");
        System.out.println();




























































        // System.out.println("  RESPUESTA: c) 204 No Content — éxito sin cuerpo de respuesta.");
        System.out.println();
    }

    static void pregunta4() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P4                                                             │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Cuál es la diferencia técnica entre @RestController y @Controller?");
        System.out.println();
        System.out.println("  a) @RestController solo funciona en Spring Boot, no en Spring MVC");
        System.out.println("  b) @Controller devuelve JSON; @RestController devuelve HTML");
        System.out.println("  c) No hay diferencia técnica, solo semántica");
        System.out.println("  d) @RestController = @Controller + @ResponseBody en todos los métodos");
        System.out.println();




























































        // System.out.println("  RESPUESTA: d) @RestController incluye @ResponseBody automáticamente.");
        System.out.println();
    }

    static void pregunta5() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ P5                                                             │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Cuál de estas URLs sigue las convenciones REST?");
        System.out.println();
        System.out.println("  a) GET /api/v1/productos");
        System.out.println("  b) GET /api/v1/obtenerProductos");
        System.out.println("  c) POST /api/v1/crearProducto");
        System.out.println("  d) GET /api/v1/Productos");
        System.out.println();




























































        // System.out.println("  RESPUESTA: a) Plural, minúsculas, sustantivo, sin verbo en la URL.");
        System.out.println();
    }
}
