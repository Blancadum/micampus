package tut06.explicacion;

public class _00_Resumen {
    public static void main(String[] args) {
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  TUTORÍA 6 — CONTROLADOR + API REST + RESPONSEENTITY");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println();
        System.out.println("1. @RestController");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  = @Controller + @ResponseBody");
        System.out.println("  Cada método devuelve datos (JSON) directamente, no una vista HTML.");
        System.out.println();
        System.out.println("2. ANOTACIONES DE MAPEO HTTP");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  @GetMapping(\"/{id}\")     → GET   /productos/{id}  → leer");
        System.out.println("  @PostMapping             → POST  /productos        → crear");
        System.out.println("  @PutMapping(\"/{id}\")     → PUT   /productos/{id}  → actualizar");
        System.out.println("  @DeleteMapping(\"/{id}\")  → DELETE/productos/{id}  → borrar");
        System.out.println("  @PatchMapping(\"/{id}\")   → PATCH /productos/{id}  → parcial");
        System.out.println();
        System.out.println("3. PARÁMETROS DE ENTRADA");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  @PathVariable  → /productos/{id}  → el id del path");
        System.out.println("  @RequestParam  → /productos?min=50 → parámetro de query");
        System.out.println("  @RequestBody   → body JSON de la petición → objeto Java");
        System.out.println();
        System.out.println("4. ResponseEntity<T>");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  ResponseEntity.ok(body)              → 200 + body");
        System.out.println("  ResponseEntity.status(201).body(...) → 201 + body");
        System.out.println("  ResponseEntity.notFound().build()    → 404 sin body");
        System.out.println("  ResponseEntity.noContent().build()   → 204 sin body");
        System.out.println();
        System.out.println("  App corriendo en: http://localhost:8086/api/v1/productos");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
    }
}
