package tut06.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 1: @RestController, MAPPINGS Y PARÁMETROS
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * @RESTCONTROLLER vs @CONTROLLER
 * ────────────────────────────────
 *   @Controller         → devuelve el NOMBRE de una vista (HTML)
 *   @RestController     → devuelve DATOS (JSON/XML) directamente
 *   @RestController ≡ @Controller + @ResponseBody en todos los métodos
 *
 *   En APIs REST siempre @RestController.
 *
 *
 * @REQUESTMAPPING — BASE URL DE LA CLASE
 * ────────────────────────────────────────
 *   @RestController
 *   @RequestMapping("/api/v1/productos")  ← prefijo para todos los endpoints
 *   public class ProductoController { ... }
 *
 *   → Cada método añade su path encima del de la clase.
 *   → Sin @RequestMapping en la clase, los métodos tienen rutas absolutas.
 *
 *
 * ANOTACIONES DE MÉTODO
 * ──────────────────────
 *   @GetMapping("/ruta")    ≡ @RequestMapping(path="/ruta", method=GET)
 *   @PostMapping("/ruta")   ≡ @RequestMapping(path="/ruta", method=POST)
 *   @PutMapping("/{id}")    ≡ @RequestMapping(path="/{id}", method=PUT)
 *   @DeleteMapping("/{id}") ≡ @RequestMapping(path="/{id}", method=DELETE)
 *   @PatchMapping("/{id}")  ≡ @RequestMapping(path="/{id}", method=PATCH)
 *
 *
 * @PATHVARIABLE — VARIABLE EN LA URL
 * ────────────────────────────────────
 *   @GetMapping("/{id}")
 *   public ResponseEntity<Producto> findById(@PathVariable Long id) { ... }
 *
 *   Petición: GET /api/v1/productos/42
 *   → id = 42L automáticamente
 *
 *   Nombre del parámetro debe coincidir con el nombre en {}: {id} → Long id
 *   Si no coinciden: @PathVariable("id") Long productoId
 *
 *
 * @REQUESTPARAM — PARÁMETRO DE QUERY
 * ─────────────────────────────────────
 *   @GetMapping
 *   public ResponseEntity<List<Producto>> findAll(
 *           @RequestParam(required = false) Double min,
 *           @RequestParam(defaultValue = "0") int pagina) { ... }
 *
 *   Petición: GET /api/v1/productos?min=50&pagina=2
 *   → min = 50.0, pagina = 2
 *
 *   required = false → el parámetro es opcional (valor null si no viene)
 *   defaultValue     → valor si no se incluye el parámetro
 *
 *
 * @REQUESTBODY — CUERPO JSON → OBJETO JAVA
 * ──────────────────────────────────────────
 *   @PostMapping
 *   public ResponseEntity<Producto> create(@RequestBody Producto producto) { ... }
 *
 *   Petición POST con body:
 *   { "nombre": "Teclado", "precio": 79.99, "stock": 15 }
 *   → Jackson deserializa el JSON → objeto Producto
 *
 *   ⚠️ Si el JSON no tiene el formato correcto → 400 Bad Request automático.
 *
 *
 * CONVENCIONES REST — URLs DE RECURSOS
 * ──────────────────────────────────────
 *   ✅ Plural y en minúsculas:    /api/v1/productos
 *   ✅ Sustantivos, no verbos:    /api/v1/productos  (no /api/v1/getProductos)
 *   ✅ El verbo lo da el método:  GET /productos  POST /productos  DELETE /productos/5
 *   ✅ Versión en la URL:         /api/v1/  (permite evolucionarla sin romper clientes)
 *   ❌ Verbos en la URL:          /api/v1/crearProducto
 *   ❌ Mayúsculas:                /api/v1/Productos
 */
public class _01_RestController_Mappings {
    // Ver demo en tut06/controlador/ProductoController.java
}
