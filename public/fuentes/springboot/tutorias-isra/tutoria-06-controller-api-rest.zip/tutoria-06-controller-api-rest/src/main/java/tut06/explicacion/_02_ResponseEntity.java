package tut06.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 2: ResponseEntity — Control total sobre la respuesta HTTP
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * DEVOLVER OBJETO DIRECTAMENTE vs ResponseEntity
 * ────────────────────────────────────────────────
 *   // Sin ResponseEntity — siempre 200 aunque no haya datos
 *   @GetMapping("/{id}")
 *   public Producto findById(@PathVariable Long id) {
 *       return service.findById(id);  // ¿qué pasa si es null?
 *   }
 *
 *   // Con ResponseEntity, forma básica — service.findById devuelve el
 *   // objeto directamente (o null), y aquí se decide el código a mano:
 *   @GetMapping("/{id}")
 *   public ResponseEntity<Producto> findById(@PathVariable Long id) {
 *       Producto producto = service.findById(id);
 *       if (producto != null) {
 *           return ResponseEntity.ok(producto);       // 200 si existe
 *       }
 *       return ResponseEntity.notFound().build();     // 404 si no
 *   }
 *
 *   // Con ResponseEntity + Optional<T> — service.findById devuelve
 *   // Optional<Producto> en lugar de Producto (o null):
 *   @GetMapping("/{id}")
 *   public ResponseEntity<Producto> findById(@PathVariable Long id) {
 *       return service.findById(id)
 *               .map(ResponseEntity::ok)               // 200 si existe
 *               .orElse(ResponseEntity.notFound().build()); // 404 si no
 *   }
 *
 *   → Esta segunda versión es EL MISMO patrón "200 si existe / 404 si no",
 *     pero apoyado en Optional<T> en vez de en una comprobación de null.
 *     El detalle de qué es Optional, sus métodos (map, orElse, orElseThrow...)
 *     y la versión con lambdas se explica en la parte avanzada:
 *     ver avanzado/_03_Optional_En_Controladores.java.
 *
 *
 * MÉTODOS DE RESPONSEENTITY
 * ──────────────────────────
 *   ResponseEntity.ok(body)                     → 200 + cuerpo
 *   ResponseEntity.created(uri).body(body)      → 201 + cuerpo + Location header
 *   ResponseEntity.noContent().build()          → 204 sin cuerpo
 *   ResponseEntity.notFound().build()           → 404 sin cuerpo
 *   ResponseEntity.badRequest().body(error)     → 400 + mensaje de error
 *   ResponseEntity.status(HttpStatus.X).body(b) → cualquier código + cuerpo
 *
 *
 * CUÁNDO USAR CADA CÓDIGO EN EL CRUD
 * ────────────────────────────────────
 *
 *   ┌───────────┬──────────────────┬──────────────────────────────────────┐
 *   │ Operación │  Código exitoso  │  Código si falla                     │
 *   ├───────────┼──────────────────┼──────────────────────────────────────┤
 *   │  GET all  │  200 OK          │  200 + lista vacía (no 404)          │
 *   │  GET /{id}│  200 OK          │  404 Not Found                       │
 *   │  POST     │  201 Created     │  400 Bad Request (datos incorrectos) │
 *   │  PUT /{id}│  200 OK          │  404 Not Found                       │
 *   │  DELETE   │  204 No Content  │  404 Not Found                       │
 *   └───────────┴──────────────────┴──────────────────────────────────────┘
 *
 *
 * BUENA PRÁCTICA: 201 + HEADER LOCATION
 * ───────────────────────────────────────
 * Al crear un recurso con POST, la convención REST indica incluir
 * el header Location con la URL del nuevo recurso:
 *
 *   @PostMapping
 *   public ResponseEntity<Producto> create(@RequestBody Producto producto,
 *                                           UriComponentsBuilder ucb) {
 *       Producto creado = service.create(producto);
 *       URI location = ucb.path("/api/v1/productos/{id}")
 *               .buildAndExpand(creado.getId()).toUri();
 *       return ResponseEntity.created(location).body(creado);
 *   }
 *
 *   → El cliente sabe dónde encontrar el nuevo recurso sin hacer otra petición.
 *   → Algunos equipos prefieren devolver solo 201 + body sin Location. Ambos son válidos.
 *
 *
 * ¿POR QUÉ NO DEVOLVER NULO EN LUGAR DE 404?
 * ─────────────────────────────────────────────
 * Si devuelves null con Spring Boot y @RestController:
 *   → Spring devuelve 200 OK con body vacío (o 204 dependiendo de la versión)
 *   → El cliente no sabe si el recurso no existe o si tiene datos vacíos
 *
 * El 404 comunica inequívocamente: "este recurso no existe".
 * Los clientes (frontend, otras APIs) pueden reaccionar a 404 de forma específica.
 */
public class _02_ResponseEntity {
    // Ver demo: ProductoController.java — cada método muestra el uso correcto.
}
