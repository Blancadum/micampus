package tut06.avanzado;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO] Optional<T> en Servicios y Controladores
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * QUÉ ES
 * ───────
 *   Optional<T> es una clase contenedora ("envoltorio") que puede contener
 *   un valor de tipo T o estar vacía. Se usa como tipo de retorno para
 *   evitar devolver null directamente y obligar a quien llama a considerar
 *   el caso de "no encontrado".
 *
 *   public Optional<Producto> findById(Long id) { ... }
 *
 *   El método NO devuelve un Producto: devuelve una caja que puede contener
 *   un Producto o no contener nada. Por eso, para acceder al valor, hace
 *   falta usar los métodos propios de Optional (no los de Producto).
 *
 *
 * PATRÓN TÍPICO EN UN CONTROLLER
 * ───────────────────────────────
 *   @GetMapping("/{id}")
 *   public ResponseEntity<Producto> findById(@PathVariable Long id) {
 *       return service.findById(id)
 *               .map(ResponseEntity::ok)                    // 200 si existe
 *               .orElse(ResponseEntity.notFound().build());  // 404 si no
 *   }
 *
 *   - service.findById(id)      → devuelve Optional<Producto>.
 *   - .map(ResponseEntity::ok)  → si hay valor, lo transforma en ResponseEntity.ok(valor).
 *                                  ResponseEntity::ok es una referencia a método,
 *                                  forma abreviada de la lambda: p -> ResponseEntity.ok(p).
 *   - .orElse(...)              → si NO hay valor, devuelve el ResponseEntity alternativo
 *                                  (no es una lambda, recibe un valor ya construido).
 *
 *   Para que esto compile, el método del servicio debe declararse devolviendo
 *   Optional<Producto>, no Producto ni null:
 *
 *   public Optional<Producto> findById(Long id) { ... }
 *
 *   Si findById devolviera Producto (o null), no existirían los métodos
 *   map/orElse y el encadenado anterior no compilaría.
 *
 *
 * OTROS MÉTODOS ÚTILES DE Optional<T>
 * ─────────────────────────────────────
 *   isPresent() / isEmpty()      → comprueban si hay valor, sin extraerlo.
 *   get()                        → devuelve el valor; lanza excepción si está vacío
 *                                    (evitar usarlo sin comprobar antes con isPresent()).
 *   orElseGet(Supplier)          → como orElse, pero el valor alternativo se calcula
 *                                    de forma perezosa, solo si hace falta.
 *   orElseThrow(Supplier)        → lanza una excepción si no hay valor
 *                                    (muy usado para devolver un 404 con excepción propia):
 *
 *   return service.findById(id)
 *           .map(ResponseEntity::ok)
 *           .orElseThrow(() -> new ResourceNotFoundException("Producto no encontrado"));
 *
 *   ifPresent(Consumer)          → ejecuta una acción solo si hay valor.
 *   ifPresentOrElse(Consumer, Runnable) → acción si hay valor, o acción alternativa si no.
 *   filter(Predicate)            → devuelve el mismo Optional si cumple la condición,
 *                                    o uno vacío si no.
 *   flatMap(Function)            → como map, pero cuando la función ya devuelve un
 *                                    Optional (evita anidar Optional<Optional<T>>).
 *
 *
 * VENTAJAS
 * ─────────
 *   - Hace explícito en la firma del método que el valor puede no existir
 *     (el propio tipo "documenta" el caso ausente).
 *   - Evita NullPointerException por olvidar comprobar null.
 *   - Permite encadenar transformaciones (map, filter) sin comprobaciones
 *     manuales repetidas.
 *   - Encaja de forma natural con ResponseEntity para mapear "existe/no existe"
 *     a "200/404" en un controller REST.
 *
 *
 * INCONVENIENTES / MALOS USOS FRECUENTES
 * ────────────────────────────────────────
 *   - NO se debe usar como tipo de atributo de una clase ni como parámetro
 *     de un método: Optional se diseñó como tipo de RETORNO, no como campo
 *     ni como argumento.
 *   - Llamar a get() sin comprobar antes isPresent()/isEmpty() reintroduce
 *     el mismo problema que se quería evitar (excepción en tiempo de ejecución).
 *   - Anidar Optional dentro de listas o de otro Optional complica la lectura
 *     (para eso existe flatMap).
 *   - Para alumnado que empieza, el uso de map/orElse con referencias a método
 *     puede resultar menos legible que un if/else explícito: no pasa nada por
 *     usar la versión "tradicional" mientras se interioriza el patrón.
 *
 *
 * USO MÍNIMO DE LAMBDAS (para quien no se siente cómodo todavía)
 * ──────────────────────────────────────────────────────────────
 *   No es obligatorio encadenar map/orElse. Es perfectamente válido:
 *
 *   Optional<Producto> resultado = service.findById(id);
 *   if (resultado.isPresent()) {
 *       return ResponseEntity.ok(resultado.get());
 *   }
 *   return ResponseEntity.notFound().build();
 *
 *   → Se sigue usando Optional (y sus ventajas frente a null), pero sin
 *     lambdas ni referencias a método. Se puede introducir map/orElse más
 *     adelante, cuando el manejo de Optional ya resulte natural.
 */
public class _03_Optional_En_Controladores {
}
