package tut06.avanzado;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO] Filter vs HandlerInterceptor vs AOP (aspectos)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * TRES FORMAS DE "INTERCEPTAR" EJECUCIÓN
 * ───────────────────────────────────────────
 *
 *   Petición HTTP
 *      │
 *      ▼
 *   [ Filter ]              ← Servlet: ve HttpServletRequest/Response en bruto
 *      │
 *      ▼
 *   DispatcherServlet
 *      │
 *      ▼
 *   [ HandlerInterceptor ]  ← Spring MVC: conoce el Controller/método (handler)
 *      │
 *      ▼
 *   Controller
 *      │
 *      ▼
 *   [ Aspecto (AOP) ]       ← Proxy sobre CUALQUIER bean: Controller, Service, Repository...
 *      │
 *      ▼
 *   Service / Repository
 *
 *
 *   Filter (jakarta.servlet.Filter / OncePerRequestFilter):
 *     → Nivel Servlet, ANTES de que la petición llegue a Spring MVC.
 *     → No sabe qué método/controller va a atender la petición.
 *     → Ideal para: seguridad (ver Tutoría 15, JwtAuthFilter), CORS, compresión,
 *       cabeceras, correlation-id en los logs.
 *
 *   HandlerInterceptor (org.springframework.web.servlet.HandlerInterceptor):
 *     → Nivel Spring MVC, DESPUÉS de que el DispatcherServlet resuelve
 *       qué Controller/método va a manejar la petición.
 *     → Sí conoce el "handler" (el método del Controller que se va a ejecutar).
 *     → Ideal para: logging con contexto de negocio, medir tiempos por endpoint,
 *       comprobaciones que dependen de anotaciones del método.
 *
 *   AOP (@Aspect):
 *     → Nivel llamada a MÉTODOS Java de beans de Spring (mediante proxies).
 *     → NO necesita HTTP: funciona igual si el Service lo llama un @Scheduled
 *       o un consumidor de Kafka.
 *     → Ve argumentos, valor devuelto y excepciones del método.
 *     → Ideal para: auditoría, transacciones, caché, reintentos, métricas de Services.
 *       (@Transactional, @Cacheable, @Async y @PreAuthorize son aspectos.)
 *
 *
 * EJEMPLO DE FILTER (el más usado en Spring Boot): correlation-id + tiempo
 * ───────────────────────────────────────────────────────────────────────────
 *   Añade un identificador único a cada petición, lo pone en el log (MDC) y
 *   lo devuelve en una cabecera. Así se puede seguir una petición entera
 *   por los logs. Basta con anotarlo como @Component: Spring Boot lo registra
 *   solo para todas las URLs ("/*").
 *
 *   @Component
 *   @Order(Ordered.HIGHEST_PRECEDENCE)   // que se ejecute el primero
 *   public class RequestIdFilter extends OncePerRequestFilter {
 *
 *       private static final Logger log = LoggerFactory.getLogger(RequestIdFilter.class);
 *
 *       @Override
 *       protected void doFilterInternal(HttpServletRequest req,
 *                                       HttpServletResponse res,
 *                                       FilterChain chain)
 *               throws ServletException, IOException {
 *
 *           // Reutiliza el id si ya viene del cliente/gateway, si no lo genera
 *           String requestId = Optional.ofNullable(req.getHeader("X-Request-Id"))
 *                                      .orElse(UUID.randomUUID().toString());
 *
 *           MDC.put("requestId", requestId);           // disponible en el patrón de log
 *           res.setHeader("X-Request-Id", requestId);  // el cliente también lo ve
 *
 *           long t0 = System.nanoTime();
 *           try {
 *               chain.doFilter(req, res);              // ← continúa hacia el Controller
 *           } finally {
 *               long ms = (System.nanoTime() - t0) / 1_000_000;
 *               log.info("{} {} -> {} ({} ms)",
 *                        req.getMethod(), req.getRequestURI(), res.getStatus(), ms);
 *               MDC.clear();                           // evita fugas entre hilos
 *           }
 *       }
 *   }
 *
 *   Notas del ejemplo:
 *     • OncePerRequestFilter garantiza UNA sola ejecución por petición (un
 *       Filter normal puede ejecutarse más de una vez en forwards internos).
 *     • Sin llamar a chain.doFilter(...) la petición se corta aquí (así
 *       rechaza peticiones un filtro de seguridad).
 *     • Para verlo en el log: logging.pattern.level=%5p [%X{requestId}]
 *
 *   Si necesitas limitar URLs u orden sin @Component, se registra a mano:
 *
 *   @Bean
 *   public FilterRegistrationBean<RequestIdFilter> requestIdFilter() {
 *       FilterRegistrationBean<RequestIdFilter> reg =
 *               new FilterRegistrationBean<>(new RequestIdFilter());
 *       reg.addUrlPatterns("/api/*");
 *       reg.setOrder(1);
 *       return reg;
 *   }
 *   (En ese caso NO anotes la clase con @Component, o se registrará dos veces.)
 *
 *
 * ¿POR QUÉ SIRVE EL FILTRO DE EJEMPLO (RequestIdFilter)?
 * ───────────────────────────────────────────────────────────
 *   Imagina que tu app recibe 100 peticiones a la vez y en el log ves esto:
 *
 *       Creando usuario
 *       Error al guardar
 *       Creando usuario
 *       Usuario creado
 *
 *   No sabes qué error pertenece a qué petición. Con el filtro, cada línea
 *   lleva el id de su petición:
 *
 *       [a1b2] Creando usuario
 *       [a1b2] Error al guardar      ← ahora sabes que este error es de la petición a1b2
 *       [c3d4] Creando usuario
 *       [c3d4] Usuario creado
 *
 *
 * CICLO DE VIDA DE UN HandlerInterceptor
 * ───────────────────────────────────────
 *   preHandle()       → antes de ejecutar el método del Controller.
 *                        Si devuelve false, la petición NO continúa.
 *   postHandle()      → después de ejecutar el Controller, antes de la respuesta.
 *   afterCompletion() → tras enviar la respuesta (limpieza, logging final).
 *
 *   public class LoggingInterceptor implements HandlerInterceptor {
 *       @Override
 *       public boolean preHandle(HttpServletRequest req, HttpServletResponse res, Object handler) {
 *           System.out.println("Entrando a: " + req.getRequestURI());
 *           return true;  // continúa la cadena
 *       }
 *   }
 *
 *   Registro (en una clase @Configuration que implemente WebMvcConfigurer):
 *
 *   @Override
 *   public void addInterceptors(InterceptorRegistry registry) {
 *       registry.addInterceptor(new LoggingInterceptor())
 *               .addPathPatterns("/api/**");
 *   }
 *
 *
 * EJEMPLO DE ASPECTO (AOP): medir cualquier método de los Services
 * ───────────────────────────────────────────────────────────────────
 *   Requiere spring-boot-starter-aop. Sin el starter el @Aspect compila
 *   pero NO se ejecuta, y no da ningún error.
 *
 *   @Aspect
 *   @Component
 *   public class TiempoAspect {
 *       @Around("execution(* tut06..service..*(..))")
 *       public Object medir(ProceedingJoinPoint pjp) throws Throwable {
 *           long t0 = System.nanoTime();
 *           try {
 *               return pjp.proceed();                  // ejecuta el método real
 *           } finally {
 *               System.out.println(pjp.getSignature() + " tardó "
 *                       + (System.nanoTime() - t0) / 1_000_000 + " ms");
 *           }
 *       }
 *   }
 *
 *   Limitaciones: solo beans de Spring, y una llamada interna (this.metodo()
 *   dentro de la misma clase) NO pasa por el proxy, así que el aspecto no salta.
 *
 *
 * TABLA COMPARATIVA RÁPIDA
 * ──────────────────────────
 *   | Aspecto              | Filter                  | HandlerInterceptor       | AOP (@Aspect)                 |
 *   |----------------------|-------------------------|--------------------------|-------------------------------|
 *   | Capa                 | Servlet (fuera de Spring)| Spring MVC              | Contenedor Spring (proxies)   |
 *   | Intercepta           | Peticiones HTTP         | Peticiones a un handler  | Llamadas a métodos de beans   |
 *   | Necesita HTTP        | Sí                      | Sí                       | No                            |
 *   | Conoce el Controller | No                      | Sí                       | Sí, si intercepta ese bean    |
 *   | Ve args/retorno      | No                      | Limitado                 | Sí (ProceedingJoinPoint)      |
 *   | Selección            | Patrón de URL           | Patrón de URL            | Pointcut (paquete, anotación) |
 *   | Uso típico           | Seguridad, CORS, ids    | Logging/métricas por URL | Auditoría, caché, transacción |
 *   | En el curso          | Tutoría 15 (JwtAuthFilter)| Solo concepto avanzado | Solo concepto avanzado        |
 *
 *   → En el día a día, la seguridad casi siempre se hace con Filter (como en
 *     Tutoría 15). HandlerInterceptor se reserva para necesidades específicas
 *     de MVC que no dependen de autenticación. AOP para lógica transversal de
 *     negocio que no tiene por qué venir de HTTP.
 *
 *
 * SPRING vs SPRING BOOT: ¿QUÉ CAMBIA?
 * ──────────────────────────────────────
 *   Los tres mecanismos existen en Spring "a secas". Boot NO añade funcionalidad
 *   nueva: cambia cómo se REGISTRAN y ACTIVAN (autoconfiguración).
 *
 *   | Mecanismo   | Spring (sin Boot)                        | Spring Boot                                  |
 *   |-------------|------------------------------------------|----------------------------------------------|
 *   | Filter      | web.xml o WebApplicationInitializer;     | Un @Component que sea Filter se registra solo|
 *   |             | DelegatingFilterProxy para Security      | en "/*"; FilterRegistrationBean para ajustar |
 *   |             | Tomcat externo (WAR)                     | Tomcat embebido (JAR)                        |
 *   | Interceptor | @EnableWebMvc o <mvc:annotation-driven/> | MVC autoconfigurado; se registra igual con   |
 *   |             | + WebMvcConfigurer o <mvc:interceptors>  | WebMvcConfigurer                             |
 *   | AOP         | spring-aop + aspectjweaver a mano y      | spring-boot-starter-aop; se activa solo      |
 *   |             | @EnableAspectJAutoProxy                  | (AopAutoConfiguration)                       |
 *   |             | Proxy JDK si hay interfaz, si no CGLIB   | CGLIB siempre (proxy-target-class=true)      |
 *
 *   Errores frecuentes en Spring Boot:
 *     • @EnableWebMvc en Boot DESACTIVA la autoconfiguración de MVC (Jackson,
 *       recursos estáticos...). Casi nunca hace falta.
 *     • Un Filter @Component + FilterRegistrationBean del mismo filtro = se
 *       ejecuta dos veces.
 *     • Un Filter @Component se aplica a "/*" aunque no lo quieras en toda la app.
 */
public class _02_Interceptor_vs_Filter_vs_Aop {
}
