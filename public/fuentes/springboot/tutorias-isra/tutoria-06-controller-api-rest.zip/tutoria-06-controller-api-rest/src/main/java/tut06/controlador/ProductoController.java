package tut06.controlador;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tut06.modelo.Producto;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Demo: CRUD completo con ResponseEntity y códigos HTTP correctos.
 * Arranca con Tut06Application → http://localhost:8086/api/v1/productos
 *
 * Probar con Postman:
 *   GET    /api/v1/productos        → 200 + lista
 *   GET    /api/v1/productos/1      → 200 + producto / 404
 *   GET    /api/v1/productos?min=20 → 200 + filtrados por precio mínimo
 *   POST   /api/v1/productos        → 201 + producto creado
 *   PUT    /api/v1/productos/1      → 200 + actualizado / 404
 *   DELETE /api/v1/productos/1      → 204 / 404
 */
@RestController
@RequestMapping("/api/v1/productos")
public class ProductoController {

    private final List<Producto> productos = new ArrayList<>(List.of(
            new Producto(1L, "Teclado mecánico", 79.99, 15),
            new Producto(2L, "Monitor 27\"", 349.00, 8),
            new Producto(3L, "Ratón inalámbrico", 19.99, 30)
    ));
    private final AtomicLong secuencia = new AtomicLong(4);

    // GET /api/v1/productos  → 200 + lista completa
    // GET /api/v1/productos?min=50  → 200 + filtro por precio mínimo (@RequestParam opcional)
    @GetMapping
    public ResponseEntity<List<Producto>> findAll(
            @RequestParam(required = false) Double min) {
        if (min != null) {
            List<Producto> filtrados = new ArrayList<>();
            for (Producto p : productos) {
                if (p.getPrecio() >= min) {
                    filtrados.add(p);
                }
            }
            return ResponseEntity.ok(filtrados);
        }
        return ResponseEntity.ok(productos);
    }

    // GET /api/v1/productos/{id}  → 200 / 404
    @GetMapping("/{id}")
    public ResponseEntity<Producto> findById(@PathVariable Long id) {
        for (Producto p : productos) {
            if (p.getId().equals(id)) {
                return ResponseEntity.ok(p);
            }
        }
        return ResponseEntity.notFound().build();
    }

    // POST /api/v1/productos  → 201 Created
    @PostMapping
    public ResponseEntity<Producto> create(@RequestBody Producto producto) {
        producto.setId(secuencia.getAndIncrement());
        productos.add(producto);
        return ResponseEntity.status(HttpStatus.CREATED).body(producto);
    }

    // PUT /api/v1/productos/{id}  → 200 / 404
    @PutMapping("/{id}")
    public ResponseEntity<Producto> update(@PathVariable Long id,
                                            @RequestBody Producto datos) {
        for (Producto p : productos) {
            if (p.getId().equals(id)) {
                p.setNombre(datos.getNombre());
                p.setPrecio(datos.getPrecio());
                p.setStock(datos.getStock());
                return ResponseEntity.ok(p);
            }
        }
        return ResponseEntity.notFound().build();
    }

    // DELETE /api/v1/productos/{id}  → 204 No Content / 404
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).getId().equals(id)) {
                productos.remove(i);
                return ResponseEntity.noContent().build();
            }
        }
        return ResponseEntity.notFound().build();
    }
}
