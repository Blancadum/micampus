package tut01;


 // TEST DE 7 PREGUNTAS — TUTORÍA 1: ARQUITECTURA WEB + HTTP

public class Preguntas {

    public static void main(String[] args) {
        pregunta1();
    //    pregunta2();
    //    pregunta3();
    //    pregunta4();
    //    pregunta5();
    //    pregunta6();
    //    pregunta7();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta1() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 1                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  Un cliente llama a POST /api/v1/libros y el libro se crea.");
        System.out.println("  ¿Qué código HTTP debe devolver el servidor?");
        System.out.println();
        System.out.println("  a) 200 OK");
        System.out.println("  b) 201 Created");
        System.out.println("  c) 204 No Content");
        System.out.println("  d) 202 Accepted");
        System.out.println();












































        // System.out.println("  ─────────────────────────────────────────────────────────────────");
        // System.out.println("  RESPUESTA: b) 201 Created");
        // System.out.println("  → POST que crea un recurso → 201.");
        // System.out.println("    200 es para GET/PUT que devuelven el recurso.");
        // System.out.println("    204 es para DELETE (éxito sin cuerpo).");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta2() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 2                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  Necesitas actualizar SOLO el precio de un libro (id=5).");
        System.out.println("  ¿Qué verbo HTTP es el más adecuado?");
        System.out.println();
        System.out.println("  a) PUT  /api/v1/libros/5");
        System.out.println("  b) POST /api/v1/libros/5");
        System.out.println("  c) PATCH /api/v1/libros/5");
        System.out.println("  d) GET  /api/v1/libros/5");
        System.out.println();








































        // System.out.println("  ─────────────────────────────────────────────────────────────────");
        // System.out.println("  RESPUESTA: c) PATCH");
        // System.out.println("  → PATCH = actualización PARCIAL (solo los campos que cambian).");
        // System.out.println("    PUT = actualización COMPLETA (reemplaza todo el recurso).");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta3() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 3                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  Un usuario autenticado intenta borrar un libro que no es suyo.");
        System.out.println("  El servidor le deniega el acceso. ¿Qué código devuelve?");
        System.out.println();
        System.out.println("  a) 401 Unauthorized");
        System.out.println("  b) 403 Forbidden");
        System.out.println("  c) 404 Not Found");
        System.out.println("  d) 400 Bad Request");
        System.out.println();













































        // System.out.println("  ─────────────────────────────────────────────────────────────────");
        // System.out.println("  RESPUESTA: b) 403 Forbidden");
        // System.out.println("  → El usuario SÍ está autenticado (sabemos quién es → no es 401)");
        // System.out.println("    pero NO tiene permiso para esa operación concreta → 403.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta4() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 4                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  ¿Cuál de estas afirmaciones viola la regla de dependencias?");
        System.out.println();
        System.out.println("  a) La capa Presentación llama a la capa Negocio");
        System.out.println("  b) La capa Negocio llama a la capa Datos");
        System.out.println("  c) La capa Datos llama a la capa Negocio");
        System.out.println("  d) La capa Presentación llama directamente a la capa Datos");
        System.out.println();




















































        // System.out.println("  ─────────────────────────────────────────────────────────────────");
        // System.out.println("  RESPUESTA: c) y d) — ambas violan la regla.");
        // System.out.println("  → Las dependencias solo van hacia abajo (Pres → Neg → Datos).");
        // System.out.println("    c) Datos llamando a Negocio = dependencia hacia arriba ❌");
        // System.out.println("    d) Presentación saltándose Negocio = se salta la capa ❌");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta5() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 5                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  En una SPA (Single-Page Application), ¿qué devuelve el");
        System.out.println("  servidor de Spring Boot en cada petición?");
        System.out.println();
        System.out.println("  a) Una página HTML completa");
        System.out.println("  b) Solo los datos en formato JSON");
        System.out.println("  c) Un archivo .jsp renderizado");
        System.out.println("  d) Un fragmento de HTML");
        System.out.println();















































        // System.out.println("  ─────────────────────────────────────────────────────────────────");
        // System.out.println("  RESPUESTA: b) Solo datos en JSON");
        // System.out.println("  → En SPA, el cliente (React/Angular) gestiona la presentación.");
        // System.out.println("    Spring Boot solo expone una API que devuelve JSON.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta6() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 6                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  HTTP es un protocolo 'stateless'. ¿Qué consecuencia tiene esto");
        System.out.println("  para una API REST con autenticación?");
        System.out.println();
        System.out.println("  a) El servidor guarda la sesión del usuario en memoria");
        System.out.println("  b) El cliente debe enviar el token en CADA petición");
        System.out.println("  c) Solo se necesita autenticarse en la primera petición");
        System.out.println("  d) El servidor recuerda automáticamente al usuario entre peticiones");
        System.out.println();


















































        // System.out.println("  ─────────────────────────────────────────────────────────────────");
        // System.out.println("  RESPUESTA: b) El cliente envía el token en cada petición");
        // System.out.println("  → Stateless = el servidor no recuerda nada entre peticiones.");
        // System.out.println("    Por eso los headers Authorization: Bearer <token> van en CADA request.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta7() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 7                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  ¿Cuál es la diferencia fundamental entre HTTP y HTTPS?");
        System.out.println();
        System.out.println("  a) HTTPS es más rápido que HTTP");
        System.out.println("  b) HTTPS cifra el tráfico con TLS; HTTP envía texto plano");
        System.out.println("  c) HTTPS solo funciona con navegadores modernos");
        System.out.println("  d) HTTPS no necesita certificado digital");
        System.out.println();





















































        
        // System.out.println("  ─────────────────────────────────────────────────────────────────");
        // System.out.println("  RESPUESTA: b) HTTPS cifra con TLS");
        // System.out.println("  → HTTP = texto plano visible en la red.");
        // System.out.println("    HTTPS = HTTP + capa TLS que cifra todo el tráfico.");
        // System.out.println("    Sí requiere certificado digital (opción d es incorrecta).");
        System.out.println();
    }
}
