package tut01.demo;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * DEMO: servidor HTTP mínimo para ver peticiones reales en el DevTools
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * No forma parte del temario ni de los ejercicios — es solo una ayuda visual
 * para la explicación de _02_ProtocoloHTTP.java: sirve una página con un
 * botón por cada código de estado; al pulsarlo hace un fetch() real contra
 * este mismo servidor, que responde con ESE código mockeado directamente
 * (sin lógica real detrás). La idea es abrir el DevTools del navegador
 * (F12 → pestaña Network), pulsar los botones y ver la petición/respuesta
 * real: verbo, URL, status, headers y body.
 *
 * Usa solo el HttpServer incluido en el JDK (com.sun.net.httpserver) — el
 * proyecto de esta tutoría todavía no tiene Spring, así que no añade
 * ninguna dependencia nueva al pom.xml.
 *
 * Cómo arrancarlo: ejecutar el main() de esta clase y abrir
 * http://localhost:8000 en el navegador.
 */
public class ServidorMockHTTP {

    private static final int PUERTO = 8000;

    // code -> (texto de la razón, body de ejemplo). 204 no lleva body (por spec HTTP).
    private static final Map<Integer, String[]> RESPUESTAS = Map.ofEntries(
            Map.entry(200, new String[]{"OK", "{\"mensaje\":\"Petición correcta\",\"libro\":{\"id\":42,\"titulo\":\"Clean Code\"}}"}),
            Map.entry(201, new String[]{"Created", "{\"mensaje\":\"Recurso creado\",\"id\":42}"}),
            Map.entry(204, new String[]{"No Content", null}),
            Map.entry(400, new String[]{"Bad Request", "{\"error\":\"El campo 'titulo' es obligatorio\"}"}),
            Map.entry(401, new String[]{"Unauthorized", "{\"error\":\"Falta el header Authorization\"}"}),
            Map.entry(403, new String[]{"Forbidden", "{\"error\":\"No tienes permisos para este recurso\"}"}),
            Map.entry(404, new String[]{"Not Found", "{\"error\":\"No existe el libro con id 999\"}"}),
            Map.entry(409, new String[]{"Conflict", "{\"error\":\"Ya existe un libro con ese ISBN\"}"}),
            Map.entry(422, new String[]{"Unprocessable Entity", "{\"error\":\"El precio no puede ser negativo\"}"}),
            Map.entry(500, new String[]{"Internal Server Error", "{\"error\":\"Excepción no controlada en el servidor\"}"})
    );

    public static void main(String[] args) throws IOException {
        HttpServer servidor = HttpServer.create(new InetSocketAddress(PUERTO), 0);

        servidor.createContext("/", ServidorMockHTTP::servirPagina);
        servidor.createContext("/api/v1/demo/", ServidorMockHTTP::servirRespuestaMockeada);

        servidor.start();
        System.out.println("Servidor demo arrancado en http://localhost:" + PUERTO);
        System.out.println("Abre el navegador, pulsa F12 -> pestaña Network, y luego pulsa los botones.");
    }

    private static void servirPagina(HttpExchange exchange) throws IOException {
        responder(exchange, 200, "text/html; charset=utf-8", PAGINA_HTML.getBytes(StandardCharsets.UTF_8));
    }

    private static void servirRespuestaMockeada(HttpExchange exchange) throws IOException {
        String path = exchange.getRequestURI().getPath(); // /api/v1/demo/201
        String codigoTexto = path.substring(path.lastIndexOf('/') + 1);

        int codigo;
        try {
            codigo = Integer.parseInt(codigoTexto);
        } catch (NumberFormatException e) {
            responder(exchange, 400, "application/json", "{\"error\":\"Código no reconocido\"}".getBytes(StandardCharsets.UTF_8));
            return;
        }

        String[] respuesta = RESPUESTAS.get(codigo);
        if (respuesta == null) {
            responder(exchange, 404, "application/json", "{\"error\":\"No hay mock para ese código\"}".getBytes(StandardCharsets.UTF_8));
            return;
        }

        if (codigo == 201) {
            exchange.getResponseHeaders().add("Location", "/api/v1/libros/42");
        }

        String body = respuesta[1];
        byte[] bytes = body == null ? new byte[0] : body.getBytes(StandardCharsets.UTF_8);
        responder(exchange, codigo, "application/json", bytes);
    }

    private static void responder(HttpExchange exchange, int status, String contentType, byte[] body) throws IOException {
        exchange.getResponseHeaders().add("Content-Type", contentType);
        exchange.sendResponseHeaders(status, body.length == 0 ? -1 : body.length);
        if (body.length > 0) {
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(body);
            }
        } else {
            exchange.close();
        }
    }

    private static final String PAGINA_HTML = """
            <!DOCTYPE html>
            <html lang="es">
            <head>
                <meta charset="UTF-8">
                <title>Demo códigos de estado HTTP</title>
                <style>
                    body { font-family: system-ui, sans-serif; max-width: 640px; margin: 40px auto; padding: 0 16px; }
                    h1 { font-size: 1.3rem; }
                    p.ayuda { color: #555; }
                    .botones { display: grid; grid-template-columns: repeat(auto-fill, minmax(90px, 1fr)); gap: 8px; margin: 20px 0; }
                    button { padding: 10px; border: 1px solid #ccc; border-radius: 6px; background: #f5f5f5; cursor: pointer; font-size: 1rem; }
                    button:hover { background: #e8e8e8; }
                    button.exito { border-color: #2e7d32; }
                    button.error-cliente { border-color: #e65100; }
                    button.error-servidor { border-color: #c62828; }
                    #resultado { white-space: pre-wrap; background: #1e1e1e; color: #d4d4d4; padding: 12px; border-radius: 6px; min-height: 60px; font-family: monospace; font-size: 0.85rem; }
                </style>
            </head>
            <body>
                <h1>Demo: códigos de estado HTTP</h1>
                <p class="ayuda">Abre el DevTools del navegador (F12) &rarr; pestaña <b>Network</b>. Pulsa un botón y mira la petición real: verbo, status, headers y body.</p>
                <div class="botones">
                    <button class="exito" onclick="probar(200)">200 OK</button>
                    <button class="exito" onclick="probar(201)">201 Created</button>
                    <button class="exito" onclick="probar(204)">204 No Content</button>
                    <button class="error-cliente" onclick="probar(400)">400 Bad Request</button>
                    <button class="error-cliente" onclick="probar(401)">401 Unauthorized</button>
                    <button class="error-cliente" onclick="probar(403)">403 Forbidden</button>
                    <button class="error-cliente" onclick="probar(404)">404 Not Found</button>
                    <button class="error-cliente" onclick="probar(409)">409 Conflict</button>
                    <button class="error-cliente" onclick="probar(422)">422 Unprocessable</button>
                    <button class="error-servidor" onclick="probar(500)">500 Server Error</button>
                </div>
                <div id="resultado">Pulsa un botón para ver la respuesta aquí...</div>

                <script>
                    async function probar(codigo) {
                        const resultado = document.getElementById('resultado');
                        resultado.textContent = 'Enviando petición a /api/v1/demo/' + codigo + ' ...';
                        try {
                            const respuesta = await fetch('/api/v1/demo/' + codigo);
                            const texto = await respuesta.text();
                            const headers = [...respuesta.headers.entries()]
                                .map(([k, v]) => k + ': ' + v).join('\\n');
                            resultado.textContent =
                                'GET /api/v1/demo/' + codigo + '\\n' +
                                'Status: ' + respuesta.status + ' ' + respuesta.statusText + '\\n\\n' +
                                'Headers:\\n' + headers + '\\n\\n' +
                                'Body:\\n' + (texto || '(vacío)');
                        } catch (e) {
                            resultado.textContent = 'Error de red: ' + e;
                        }
                    }
                </script>
            </body>
            </html>
            """;
}
