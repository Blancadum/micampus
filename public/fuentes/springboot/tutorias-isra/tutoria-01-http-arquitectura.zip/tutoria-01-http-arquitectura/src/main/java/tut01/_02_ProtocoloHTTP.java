package tut01;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 2: PROTOCOLO HTTP
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *
 * ¿QUÉ ES HTTP?
 * ─────────────
 * HTTP = HyperText Transfer Protocol
 *
 * Es el PROTOCOLO de comunicación entre cliente y servidor en la web.
 * Define el formato exacto de los mensajes que se envían por la red.
 *
 * Es STATELESS (sin estado): cada petición es independiente.
 * El servidor no recuerda peticiones anteriores. Si necesitas mantener
 * estado (sesión de usuario), debes gestionarlo tú (tokens, cookies...).
 *
 *
 * ESTRUCTURA DE UNA PETICIÓN (REQUEST)
 * ────────────────────────────────────
 *
 *   ┌─────────────────────────────────────────────────────────┐
 *   │  Línea de petición:  POST /api/v1/libros HTTP/1.1       │  ← verbo + ruta + versión
 *   ├─────────────────────────────────────────────────────────┤
 *   │  Headers:            Host: localhost:8080               │  ← metadatos
 *   │                      Content-Type: application/json     │
 *   │                      Authorization: Bearer eyJ...       │
 *   ├─────────────────────────────────────────────────────────┤
 *   │  Body (opcional):    { "titulo": "Clean Code",          │  ← datos enviados
 *   │                        "autor": "Robert C. Martin" }    │
 *   └─────────────────────────────────────────────────────────┘
 *
 *
 * ESTRUCTURA DE UNA RESPUESTA (RESPONSE)
 * ───────────────────────────────────────
 *
 *   ┌─────────────────────────────────────────────────────────┐
 *   │  Línea de estado:    HTTP/1.1 201 Created               │  ← versión + código + texto
 *   ├─────────────────────────────────────────────────────────┤
 *   │  Headers:            Content-Type: application/json     │  ← metadatos de la respuesta
 *   │                      Location: /api/v1/libros/42        │
 *   ├─────────────────────────────────────────────────────────┤
 *   │  Body:               { "id": 42,                        │  ← datos devueltos
 *   │                        "titulo": "Clean Code" }         │
 *   └─────────────────────────────────────────────────────────┘
 *
 *
 * LOS 5 VERBOS HTTP Y SU USO EN APIs REST
 * ─────────────────────────────────────────
 *
 *   ┌─────────┬───────────────────────────┬──────────────────────────────────┐
 *   │  Verbo  │  Acción                   │  Ejemplo en API de libros        │
 *   ├─────────┼───────────────────────────┼──────────────────────────────────┤
 *   │  GET    │  Leer / Consultar         │  GET /api/v1/libros              │
 *   │         │  No modifica datos        │  GET /api/v1/libros/42           │
 *   ├─────────┼───────────────────────────┼──────────────────────────────────┤
 *   │  POST   │  Crear nuevo recurso      │  POST /api/v1/libros             │
 *   │         │  Envía datos en el body   │  Body: { titulo, autor... }      │
 *   ├─────────┼───────────────────────────┼──────────────────────────────────┤
 *   │  PUT    │  Actualizar COMPLETO      │  PUT /api/v1/libros/42           │
 *   │         │  Reemplaza el recurso     │  Body: todos los campos          │
 *   ├─────────┼───────────────────────────┼──────────────────────────────────┤
 *   │  PATCH  │  Actualizar PARCIAL       │  PATCH /api/v1/libros/42         │
 *   │         │  Solo los campos que cambian│ Body: { precio: 19.99 }        │
 *   ├─────────┼───────────────────────────┼──────────────────────────────────┤
 *   │  DELETE │  Eliminar                 │  DELETE /api/v1/libros/42        │
 *   │         │  Sin body habitualmente   │                                  │
 *   └─────────┴───────────────────────────┴──────────────────────────────────┘
 *
 *
 * CÓDIGOS DE ESTADO HTTP — LOS QUE MÁS USARÁS
 * ─────────────────────────────────────────────
 *
 *   FAMILIA 2xx — ÉXITO
 *   ────────────────────
 *   200 OK             → La petición tuvo éxito. Respuesta con datos.
 *                         Usado en: GET (encontrado), PUT, PATCH
 *   201 Created        → Recurso creado con éxito.
 *                         Usado en: POST exitoso
 *                         Convención: incluir header "Location" con la URL del nuevo recurso
 *   204 No Content     → Éxito pero sin cuerpo de respuesta.
 *                         Usado en: DELETE exitoso
 *
 *   FAMILIA 4xx — ERROR DEL CLIENTE
 *   ─────────────────────────────────
 *   400 Bad Request    → La petición tiene datos incorrectos (validación fallida)
 *   401 Unauthorized   → No estás autenticado (sin token o token inválido)
 *   403 Forbidden      → Estás autenticado pero no tienes permiso
 *   404 Not Found      → El recurso no existe (id no encontrado)
 *   409 Conflict       → El recurso ya existe (ej: email duplicado)
 *   422 Unprocessable  → Datos bien formados pero semánticamente incorrectos
 *
 *   FAMILIA 5xx — ERROR DEL SERVIDOR
 *   ──────────────────────────────────
 *   500 Internal Server Error → Algo falló en el servidor (excepción no controlada)
 *
 *
 * DIFERENCIA 401 vs 403 — CONFUSIÓN FRECUENTE
 * ─────────────────────────────────────────────
 *
 *   401 Unauthorized:  "No sé quién eres" → falta autenticación
 *                      Acción del cliente: hacer login, obtener token
 *
 *   403 Forbidden:     "Sé quién eres, pero no puedes" → falta autorización
 *                      Acción del cliente: ninguna (no tiene permisos)
 *
 *
 * VERSIONADO DE LA URL — ¿POR QUÉ /api/v1/?
 * ────────────────────────────────────────────
 * Todos los endpoints del curso usan el prefijo /api/v1/.
 * La "v1" es la VERSIÓN de la API.
 *
 * ¿Para qué sirve?
 * Si en el futuro cambia el formato de respuesta o el comportamiento de un
 * endpoint, se crea /api/v2/ con los cambios nuevos, mientras /api/v1/
 * sigue funcionando igual para los clientes que ya lo usan (app móvil,
 * frontend, otra API).
 *
 * Sin versión: cualquier cambio rompe inmediatamente todos los clientes.
 * Con versión: coexisten v1 y v2 hasta que todos los clientes migran.
 *
 *   GET /api/v1/libros  → comportamiento original, sigue funcionando
 *   GET /api/v2/libros  → nueva versión con cambios, adoptada gradualmente
 *
 * ⚠️ Aunque tu proyecto no tenga múltiples versiones, usar /v1/ desde el
 *    principio es una buena práctica profesional.
 *
 *
 * HEADERS MÁS COMUNES EN APIs REST
 * ──────────────────────────────────
 *
 *   Content-Type: application/json  → el body está en formato JSON
 *   Accept: application/json        → el cliente quiere recibir JSON
 *   Authorization: Bearer <token>   → token JWT para autenticación
 *   Location: /api/v1/libros/42     → URL del recurso recién creado (201)
 *
 *
 * HTTP ES STATELESS — CONSECUENCIAS PRÁCTICAS
 * ─────────────────────────────────────────────
 * El servidor no recuerda quién eres entre peticiones.
 * Cada petición lleva TODA la información necesaria.
 *
 * → Por eso en cada request se envía el token JWT en el header Authorization.
 * → Por eso no hay "sesión de servidor" en APIs REST modernas.
 * → Por eso es fácil escalar: cualquier instancia del servidor puede
 *   atender cualquier petición sin necesitar acceso a una sesión compartida.
 */
public class _02_ProtocoloHTTP {
    // Esta clase es de referencia conceptual — no contiene código ejecutable.
}
