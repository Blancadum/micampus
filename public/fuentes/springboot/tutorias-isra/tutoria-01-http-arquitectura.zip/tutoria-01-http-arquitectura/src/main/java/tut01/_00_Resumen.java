package tut01;

/**
 * Ejecuta esta clase para ver el mapa conceptual de la Tutoría 1.
 */
public class _00_Resumen {

    public static void main(String[] args) {

        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  TUTORÍA 1 — ARQUITECTURA WEB + PROTOCOLO HTTP");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // 1. LAS TRES CAPAS
        // ════════════════════════════════════════════════════════════════════
        System.out.println("1. LAS TRES CAPAS (regla de oro: las dependencias bajan, nunca suben)");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  Presentación  →  lo que ve el usuario (HTML, React, Angular)");
        System.out.println("  Negocio       →  la lógica (reglas, cálculos, validaciones)");
        System.out.println("  Datos         →  acceso a la BBDD (JPA, JDBC, repositorios)");
        System.out.println();
        System.out.println("  ┌─────────────────┐");
        System.out.println("  │  Presentación   │  ← solo depende de Negocio");
        System.out.println("  └────────┬────────┘");
        System.out.println("           ↓");
        System.out.println("  ┌────────┴────────┐");
        System.out.println("  │    Negocio      │  ← solo depende de Datos");
        System.out.println("  └────────┬────────┘");
        System.out.println("           ↓");
        System.out.println("  ┌────────┴────────┐");
        System.out.println("  │      Datos      │  ← no depende de nadie");
        System.out.println("  └─────────────────┘");
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // 2. MPA VS SPA
        // ════════════════════════════════════════════════════════════════════
        System.out.println("2. MPA VS SPA");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  MPA (Multi-Page Application - antiguo): servidor devuelve HTML completo en cada petición");
        System.out.println("  SPA (Single Page Application - actual) : servidor devuelve solo datos (JSON)");
        System.out.println("                 el cliente (React/Angular) pinta la pantalla");
        System.out.println();
        System.out.println("  Spring Boot = lado servidor = API que devuelve JSON");
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // 3. HTTP EN 5 LÍNEAS
        // ════════════════════════════════════════════════════════════════════
        System.out.println("3. HTTP EN 5 LÍNEAS");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  GET    → leer     → 200 OK");
        System.out.println("  POST   → crear    → 201 Created");
        System.out.println("  PUT    → actualizar completo → 200 OK");
        System.out.println("  PATCH  → actualizar parcial  → 200 OK");
        System.out.println("  DELETE → borrar   → 204 No Content");
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // 4. CÓDIGOS DE ESTADO CLAVE
        // ════════════════════════════════════════════════════════════════════
        System.out.println("4. CÓDIGOS DE ESTADO CLAVE");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  2xx → Éxito         200 OK | 201 Created | 204 No Content");
        System.out.println("  4xx → Error cliente  400 Bad Request | 401 No autenticado");
        System.out.println("                       403 No autorizado | 404 No encontrado");
        System.out.println("  5xx → Error servidor 500 Internal Server Error");
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // 5. HTTPS
        // ════════════════════════════════════════════════════════════════════
        System.out.println("5. HTTPS");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  HTTP  = texto plano → cualquiera en la red puede leerlo");
        System.out.println("  HTTPS = HTTP + TLS  → tráfico cifrado entre cliente y servidor");
        System.out.println("  Puerto por defecto: 443 (HTTP usa 80)");
        System.out.println();

        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  Ver detalles en _01_ArquitecturaWeb, _02_ProtocoloHTTP, _03_HTTPS");
        System.out.println("  Preguntas tipo test → Preguntas.java");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
    }
}
