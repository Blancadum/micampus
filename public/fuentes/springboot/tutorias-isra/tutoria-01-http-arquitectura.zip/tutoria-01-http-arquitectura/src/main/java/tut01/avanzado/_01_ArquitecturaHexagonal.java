package tut01.avanzado;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO] ARQUITECTURA HEXAGONAL (Puertos y Adaptadores)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * ⚠️ Este contenido va MÁS ALLÁ del temario estándar del curso.
 *    Se incluye para alumnos que quieran profundizar.
 *    NO entra en las tutorías ni en los ejercicios obligatorios.
 *
 *
 * ¿QUÉ ES LA ARQUITECTURA HEXAGONAL?
 * ────────────────────────────────────
 * Propuesta por Alistair Cockburn en 2005.
 * También llamada "Ports and Adapters" (Puertos y Adaptadores).
 *
 * La idea central: el DOMINIO (lógica de negocio) vive en el CENTRO
 * y no depende de NADA externo — ni de la BBDD, ni del HTTP, ni del framework.
 *
 *
 * DIAGRAMA HEXAGONAL
 * ──────────────────
 *
 *        Adaptadores primarios (entrada)
 *         REST  │  CLI  │  Tests
 *               ↓    ↓    ↓
 *        ┌──────────────────────┐
 *        │   Puerto de entrada  │  (interfaz que define lo que puede hacer el dominio)
 *        ├──────────────────────┤
 *        │                      │
 *        │      DOMINIO         │  ← aquí está la lógica de negocio PURA
 *        │   (Lógica pura,      │     Sin Spring, sin JPA, sin HTTP
 *        │    sin frameworks)   │     Solo Java puro + reglas del negocio
 *        │                      │
 *        ├──────────────────────┤
 *        │   Puerto de salida   │  (interfaz que define lo que necesita el dominio)
 *        └──────────────────────┘
 *               ↑    ↑    ↑
 *        Adaptadores secundarios (salida)
 *         JPA   │  Email │  API externa
 *
 *
 * DIFERENCIA CON CAPAS TRADICIONALES
 * ─────────────────────────────────────
 *
 *   Capas tradicionales:
 *     Presentación → Negocio → Datos
 *     El Negocio CONOCE cómo se accede a la BBDD (usa JPA directamente)
 *
 *   Hexagonal:
 *     El Dominio NO conoce JPA. Solo conoce una interfaz (puerto):
 *       interface LibroRepository {
 *           Libro findById(Long id);
 *           void save(Libro libro);
 *       }
 *     La implementación JPA es un adaptador que implementa esa interfaz.
 *
 *
 * VENTAJA CLAVE
 * ─────────────
 * Puedes testear el dominio puro sin arrancar Spring, sin BBDD.
 * Solo necesitas un mock del repositorio.
 *
 * También puedes cambiar la BBDD (de MySQL a MongoDB, por ejemplo)
 * sin tocar ninguna línea de lógica de negocio.
 *
 *
 * RELACIÓN CON LO QUE VERÁS EN EL CURSO
 * ───────────────────────────────────────
 * El curso enseña la arquitectura de 3 capas con Spring Boot.
 * Esto es correcto y es lo que se usa en la mayoría de proyectos.
 *
 * La hexagonal es una evolución:
 *   - En proyectos medianos/grandes donde el dominio es complejo
 *   - Cuando el equipo valora los tests del dominio puro
 *   - Como preparación para Domain-Driven Design (DDD)
 *
 * Empieza con 3 capas → cuando las domines, la hexagonal es natural.
 *
 *
 * OTROS NOMBRES QUE VERÁS
 * ──────────────────────────
 *   Clean Architecture (Robert C. Martin) — misma idea, diferente nombre
 *   Onion Architecture — igual
 *   Domain-Driven Design (DDD) — conjunto de patrones que usan hexagonal
 *
 * Son todos el mismo principio: el dominio en el centro, sin depender de nada.
 */
public class _01_ArquitecturaHexagonal {
    // Contenido avanzado — referencia conceptual.
}
