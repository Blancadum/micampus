package tut01;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 3: HTTPS — HTTP SEGURO
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *
 * ¿QUÉ ES HTTPS?
 * ──────────────
 * HTTPS = HTTP + TLS (Transport Layer Security)
 *
 * Es exactamente HTTP, pero el tráfico viaja CIFRADO entre el cliente
 * y el servidor. Nadie en la red puede leer (ni modificar) los mensajes.
 *
 *
 * EL PROBLEMA QUE RESUELVE
 * ────────────────────────
 * Imagina una cafetería con WiFi público:
 *
 *   Con HTTP:
 *   ┌──────────┐  texto plano visible  ┌────────────────┐  texto plano  ┌──────────┐
 *   │  Tu      │ ──────────────────────│  Router WiFi   │─────────────→ │ Servidor │
 *   │  móvil   │                       │  (cualquiera   │               │          │
 *   └──────────┘                       │  puede leer)   │               └──────────┘
 *                                      └────────────────┘
 *   ← el dueño del router ve tu contraseña, tu token, tus datos
 *
 *   Con HTTPS:
 *   ┌──────────┐  datos cifrados  ┌────────────────┐  datos cifrados  ┌──────────┐
 *   │  Tu      │ ─────────────────│  Router WiFi   │─────────────────→│ Servidor │
 *   │  móvil   │                  │  (ve basura    │                  │          │
 *   └──────────┘                  │  ilegible)     │                  └──────────┘
 *                                 └────────────────┘
 *   ← nadie en la red puede leer nada útil
 *
 *
 * CÓMO FUNCIONA TLS (SIMPLIFICADO)
 * ─────────────────────────────────
 *
 *   1. HANDSHAKE (apretón de manos):
 *      → El servidor envía su CERTIFICADO DIGITAL
 *        (contiene: identidad del servidor + su clave pública)
 *      → El cliente verifica que el certificado es legítimo
 *        (firmado por una Autoridad Certificadora de confianza)
 *
 *   2. INTERCAMBIO DE CLAVE:
 *      → Cliente y servidor negocian una CLAVE SIMÉTRICA de sesión
 *      → Usando la clave pública del servidor para proteger el intercambio
 *
 *   3. CIFRADO:
 *      → A partir de ese momento, todo el tráfico HTTP va cifrado
 *        con la clave de sesión (simétrica → muy rápida)
 *
 *
 * CERTIFICADOS DIGITALES
 * ───────────────────────
 * El certificado digital es el "DNI" del servidor.
 * Responde a: ¿cómo sé que el servidor que me responde es
 * realmente "api.mibanco.com" y no un impostor?
 *
 *   ┌─────────────────────────────────────────────────────┐
 *   │  Certificado de api.mibanco.com                     │
 *   │  Titular: MiBanco, S.A.                             │
 *   │  Clave pública: 3082 0348 2...                      │
 *   │  Válido hasta: 2026-12-31                           │
 *   │  Firmado por: DigiCert Global Root CA               │
 *   └─────────────────────────────────────────────────────┘
 *
 * Los navegadores y sistemas operativos tienen pre-instalada una lista
 * de Autoridades Certificadoras (CA) de confianza.
 * Si el certificado está firmado por una CA de confianza → candado verde.
 *
 *
 * PUERTOS POR DEFECTO
 * ────────────────────
 *   HTTP  → puerto 80  (ej: http://example.com → http://example.com:80)
 *   HTTPS → puerto 443 (ej: https://example.com → https://example.com:443)
 *
 *
 * ¿POR QUÉ IMPORTA EN SPRING BOOT?
 * ──────────────────────────────────
 * En desarrollo local usamos HTTP (localhost:8080) — es conveniente y seguro
 * porque el tráfico no sale de tu máquina.
 *
 * En producción (deploy real) SIEMPRE HTTPS:
 *   - Los usuarios envían tokens JWT y datos personales
 *   - Si usas HTTP en producción, cualquiera en la red puede robar tokens
 *   - Los navegadores modernos marcan HTTP como "No seguro"
 *   - Google penaliza en SEO los sitios sin HTTPS
 *
 * Configurar HTTPS en Spring Boot:
 *   → En producción: el reverse proxy (Nginx, Traefik) gestiona el TLS
 *   → El servidor Spring Boot recibe HTTP internamente (dentro del datacenter)
 *   → El certificado está en el proxy, no en Spring Boot directamente
 *
 *
 * RESUMEN: HTTP VS HTTPS
 * ───────────────────────
 *   ┌──────────────┬────────────────────────────────────────────┐
 *   │  HTTP        │  HTTPS                                     │
 *   ├──────────────┼────────────────────────────────────────────┤
 *   │  Texto plano │  Tráfico cifrado con TLS                   │
 *   │  Puerto 80   │  Puerto 443                                │
 *   │  Desarrollo  │  Producción (obligatorio)                  │
 *   │  Rápido conf.│  Requiere certificado digital              │
 *   └──────────────┴────────────────────────────────────────────┘
 */
public class _03_HTTPS {
    // Esta clase es de referencia conceptual — no contiene código ejecutable.
}
