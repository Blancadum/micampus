package tut01;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 1: ARQUITECTURA DE APLICACIONES WEB
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *
 * ¿QUÉ ES UNA ARQUITECTURA?
 * ─────────────────────────
 * La arquitectura define cómo se ORGANIZAN los componentes de un sistema,
 * cómo se RELACIONAN entre sí y qué REGLAS deben seguir.
 *
 * No es lo mismo que diseño de clases ni que código limpio.
 * Se trabaja en tres niveles de abstracción:
 *
 *   Nivel 1 — Código:        calidad de cada método, cohesión, nombres
 *   Nivel 2 — Diseño:        qué clases existen y cómo se relacionan
 *   Nivel 3 — Arquitectura:  paquetes, artefactos y sus relaciones
 *
 *
 * ARQUITECTURA DE 3 CAPAS
 * ───────────────────────
 * Es el modelo más extendido en aplicaciones empresariales Java.
 * Divide la aplicación en tres capas con responsabilidades claras:
 *
 *   ┌──────────────────────────────────────────┐
 *   │            PRESENTACIÓN                  │
 *   │  Lo que ve el usuario. HTML, CSS, JS.    │
 *   │  En SPA: React, Angular, Vue.            │
 *   │  En Spring Boot: @RestController         │
 *   └─────────────────┬────────────────────────┘
 *                     │ depende de ↓
 *   ┌─────────────────▼────────────────────────┐
 *   │             NEGOCIO                      │
 *   │  Lógica de negocio: reglas, cálculos,    │
 *   │  validaciones, transformaciones.         │
 *   │  En Spring Boot: @Service                │
 *   └─────────────────┬────────────────────────┘
 *                     │ depende de ↓
 *   ┌─────────────────▼────────────────────────┐
 *   │               DATOS                      │
 *   │  Acceso a la base de datos.              │
 *   │  En Spring Boot: @Repository / JPA       │
 *   └──────────────────────────────────────────┘
 *
 *
 * REGLA DE ORO: LAS DEPENDENCIAS SOLO BAJAN
 * ──────────────────────────────────────────
 *   ✅ Presentación puede llamar a Negocio
 *   ✅ Negocio puede llamar a Datos
 *   ❌ Datos NO puede llamar a Negocio
 *   ❌ Negocio NO puede llamar a Presentación
 *
 * ¿Por qué? Alta cohesión, bajo acoplamiento.
 * Si la capa de Datos llama a la de Negocio, cualquier cambio en
 * la lógica rompe el acceso a datos → mantenimiento imposible.
 *
 *
 * MPA (MULTI-PAGE APPLICATION) — EL MODELO ANTIGUO
 * ─────────────────────────────────────────────────
 *
 *   [Navegador] ──── petición HTTP ────→ [Servidor]
 *                                           │
 *                                      genera HTML
 *                                           │
 *   [Navegador] ←─── HTML completo ─────────┘
 *
 * Problema: el servidor mantiene la SESIÓN de cada cliente.
 * → escalar es muy costoso (hay que replicar la sesión)
 * → cada petición recibe una página entera (mucho ancho de banda)
 * → los móviles no encajan: un móvil quiere datos, no HTML
 *
 *
 * SPA (SINGLE-PAGE APPLICATION) — EL MODELO ACTUAL
 * ─────────────────────────────────────────────────
 *
 *   [Navegador: React/Angular ejecuta la Presentación]
 *          │               ↑
 *     petición JSON    datos JSON
 *          │               │
 *         [Servidor: API REST]
 *               │
 *             [BBDD]
 *
 * Ventajas:
 * → Servidor sin estado (stateless) → fácil de replicar y escalar
 * → Intercambio mínimo de datos (JSON pequeño, no HTML)
 * → Un solo backend sirve a web, móvil, IoT, tests automatizados
 *
 * Spring Boot es el SERVIDOR en este modelo: solo expone JSON.
 *
 *
 * MONOLITO VS MICROSERVICIOS
 * ──────────────────────────
 *
 *   MONOLITO:
 *   ┌─────────────────────────────────┐
 *   │  Presentación + Negocio + Datos │  ← todo en un artefacto (.jar/.war)
 *   └─────────────────────────────────┘
 *
 *   Ventajas: simple de desarrollar y desplegar inicialmente
 *   Inconvenientes: escala mal, un fallo puede tumbar todo
 *
 *   MICROSERVICIOS:
 *   ┌──────────┐  ┌──────────┐  ┌──────────┐
 *   │ Servicio │  │ Servicio │  │ Servicio │  ← cada uno en su propio proceso
 *   │ Usuarios │  │ Pedidos  │  │ Pagos    │
 *   └──────────┘  └──────────┘  └──────────┘
 *
 *   Ventajas: escala de forma independiente, fallo aislado
 *   Inconvenientes: complejidad operacional, red entre servicios
 *
 *   → El curso de Spring Boot enseña a construir MONOLITOS bien estructurados.
 *     Los microservicios vienen después: son monolitos bien hechos multiplicados.
 *
 *
 * ¿POR QUÉ IMPORTA ESTO ANTES DE VER SPRING BOOT?
 * ─────────────────────────────────────────────────
 * Spring Boot implementa esta arquitectura con anotaciones:
 *
 *   @RestController  →  Capa Presentación (HTTP in/out)
 *   @Service         →  Capa Negocio (lógica)
 *   @Repository      →  Capa Datos (BBDD)
 *
 * Cuando llegues al módulo 2 del curso, ya sabrás POR QUÉ
 * existen estas tres anotaciones y qué responsabilidad tiene cada una.
 */
public class _01_ArquitecturaWeb {
    // Esta clase es de referencia conceptual — no contiene código ejecutable.
}
