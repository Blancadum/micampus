package tut12.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * TEST DE AUTOEVALUACIÓN — TUTORÍA 12 (LOGS, PERFILES Y OPENAPI)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Descomenta las llamadas en el main para poner a prueba tus conocimientos.
 */
public class Preguntas {

    public static void main(String[] args) {
        pregunta1();
        // pregunta2();
        // pregunta3();
        // pregunta4();
        // pregunta5();
        // pregunta6();
        // pregunta7();
        // pregunta8();
    }

    static void pregunta1() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 1: SISTEMA DE LOGS                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Por qué en una aplicación empresarial se prohíbe System.out.println?");
        System.out.println();
        System.out.println("  a) Porque solo funciona en Windows y falla en Linux.");
        System.out.println("  b) Porque no permite clasificar por niveles ni apagarlo en producción.");
        System.out.println("  c) Porque destruye el objeto antes de imprimirlo.");
        System.out.println("  d) Porque solo admite cadenas de texto cortas.");
        System.out.println();
        // RESPUESTA: b)
        // System.out.println("  RESPUESTA CORRECTA: b)");
        // System.out.println("  System.out.println es sincrónico, lento, y no permite configurar");
        // System.out.println("  umbrales de gravedad ni redirigir a ficheros con rotación.");
    }

    static void pregunta2() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 2: ANOTACIÓN @Slf4j                                    │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Qué hace exactamente la anotación @Slf4j de Lombok?");
        System.out.println();
        System.out.println("  a) Conecta la app a una base de datos de logs.");
        System.out.println("  b) Crea automáticamente una variable estática 'log' de SLF4J.");
        System.out.println("  c) Convierte todos los System.out.println en logs.");
        System.out.println("  d) Habilita Swagger UI.");
        System.out.println();
        // RESPUESTA: b)
    }

    static void pregunta3() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 3: JERARQUÍA DE NIVELES                                │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println("  Si en application.yml configuras: logging.level.root: INFO");
        System.out.println("  ¿Qué mensajes se imprimirán?");
        System.out.println();
        System.out.println("  a) Solo los de nivel INFO.");
        System.out.println("  b) INFO, WARN y ERROR.");
        System.out.println("  c) TRACE, DEBUG e INFO.");
        System.out.println("  d) Todos los niveles.");
        System.out.println();
        // RESPUESTA: b)
        // Se muestran el nivel configurado y todos los que sean más graves que él.
    }

    static void pregunta4() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 4: SINTAXIS RECOMENDADA EN SLF4J                       │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Cuál es la forma más eficiente de registrar variables en el log?");
        System.out.println();
        System.out.println("  a) log.info(\"Usuario: \" + id);");
        System.out.println("  b) log.info(\"Usuario: %s\", id);");
        System.out.println("  c) log.info(\"Usuario: {}\", id);");
        System.out.println("  d) log.info(String.format(\"Usuario: %s\", id));");
        System.out.println();
        // RESPUESTA: c)
        // Los placeholders {} evitan la concatenación de String si el log está desactivado.
    }

    static void pregunta5() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 5: PERFILES DE CONFIGURACIÓN                           │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Qué archivo sobreescribe application.yml si se activa el perfil 'prod'?");
        System.out.println();
        System.out.println("  a) application-prod.yml");
        System.out.println("  b) application.prod.properties");
        System.out.println("  c) prod.yml");
        System.out.println("  d) spring-prod.yml");
        System.out.println();
        // RESPUESTA: a)
    }

    static void pregunta6() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 6: ANOTACIÓN @Profile                                  │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Para qué sirve anotar una clase con @Profile(\"dev\")?");
        System.out.println();
        System.out.println("  a) Para que solo se compile en desarrollo.");
        System.out.println("  b) Para que Spring solo cree esa instancia (Bean) si el perfil activo es 'dev'.");
        System.out.println("  c) Para desactivar los logs de esa clase.");
        System.out.println("  d) Para permitir llamadas sin contraseña.");
        System.out.println();
        // RESPUESTA: b)
    }

    static void pregunta7() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 7: RUTA POR DEFECTO DE SWAGGER UI                      │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println("  Con springdoc-openapi, ¿cuál es la URL por defecto para ver la interfaz gráfica?");
        System.out.println();
        System.out.println("  a) http://localhost:8080/docs");
        System.out.println("  b) http://localhost:8080/swagger-ui/index.html (o /swagger-ui.html)");
        System.out.println("  c) http://localhost:8080/api-docs.html");
        System.out.println("  d) http://localhost:8080/swagger");
        System.out.println();
        // RESPUESTA: b)
    }

    static void pregunta8() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 8: DOCUMENTACIÓN EN CONTROLADORES Y DTOs               │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println("  ¿Qué anotación de OpenAPI 3 se coloca sobre un campo de un DTO?");
        System.out.println();
        System.out.println("  a) @ApiModelProperty");
        System.out.println("  b) @Operation");
        System.out.println("  c) @Schema");
        System.out.println("  d) @Tag");
        System.out.println();
        // RESPUESTA: c)
        // @Schema es la anotación estándar de OpenAPI 3 para campos y clases modelo/DTO.
    }
}
