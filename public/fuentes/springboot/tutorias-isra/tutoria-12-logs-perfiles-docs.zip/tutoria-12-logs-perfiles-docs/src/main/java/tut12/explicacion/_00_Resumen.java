package tut12.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * TUTORÍA 12: LOGS, PERFILES DE CONFIGURACIÓN Y DOCUMENTACIÓN OPENAPI
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Ejecuta este main para ver el mapa conceptual completo de la tutoría.
 */
public class _00_Resumen {

    public static void main(String[] args) {
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  TUTORÍA 12 — LOGS, PERFILES Y DOCUMENTACIÓN OPENAPI");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println();

        // 1. LOMBOK & @Slf4j
        System.out.println("1. LOMBOK & @Slf4j (EL VAGO INTELIGENTE)");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  Lombok ahorra código repetitivo (boilerplate) en tiempo de compilación:");
        System.out.println("  • @Getter / @Setter       → Crea métodos get y set.");
        System.out.println("  • @NoArgsConstructor      → Constructor vacío (obligatorio para frameworks).");
        System.out.println("  • @AllArgsConstructor     → Constructor con todos los campos.");
        System.out.println("  • @Builder                → Patrón constructor fluido.");
        System.out.println("  • @Slf4j                  → Inyecta automáticamente el Logger 'log'.");
        System.out.println();

        // 2. LOGS (SLF4J + LOGBACK)
        System.out.println("2. LOGGING PROFESIONAL (ADIÓS SYSTEM.OUT.PRINTLN)");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  ¿Por qué System.out.println está PROHIBIDO en producción?");
        System.out.println("  ❌ No tiene marcas de tiempo ni hilo de ejecución.");
        System.out.println("  ❌ Bloquea el flujo del hilo (es sincrónico y lento).");
        System.out.println("  ❌ No se puede apagar ni filtrar por gravedad.");
        System.out.println();
        System.out.println("  Jerarquía de niveles (de menos grave a más grave):");
        System.out.println("    TRACE < DEBUG < INFO < WARN < ERROR");
        System.out.println("  Regla de formato con {} en vez de concatenar (+):");
        System.out.println("    log.info(\"Usuario {} logueado con éxito\", id);  // ¡Rápido y limpio!");
        System.out.println();

        // 3. PERFILES DE ENTORNO (PROFILES)
        System.out.println("3. PERFILES DE SPRING (PROFILES)");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  Permiten cambiar de configuración según el entorno sin tocar Java:");
        System.out.println("  • application-dev.yml   → Desarrollo local (logs DEBUG, H2, puerto 8080).");
        System.out.println("  • application-prod.yml  → Producción (logs WARN/INFO, BBDD Cloud, SSL).");
        System.out.println();
        System.out.println("  Activación:");
        System.out.println("  • En application.yml : spring.profiles.active=dev");
        System.out.println("  • Por terminal       : java -jar app.jar --spring.profiles.active=prod");
        System.out.println("  • En clases Java     : @Profile(\"dev\") (solo se instancia en dev)");
        System.out.println();

        // 4. DOCUMENTACIÓN OPENAPI 3 & SWAGGER UI
        System.out.println("4. DOCUMENTACIÓN VIVA CON OPENAPI 3 / SWAGGER UI");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  • OpenAPI 3 : Es la ESPECIFICACIÓN (el contrato JSON estándar de tu API).");
        System.out.println("  • Swagger UI: Es la WEB interactiva para probar endpoints sin Postman.");
        System.out.println("  Rutas estándar:");
        System.out.println("    → Especificación JSON : http://localhost:8080/v3/api-docs");
        System.out.println("    → Swagger UI visual   : http://localhost:8080/swagger-ui.html");
        System.out.println();
        System.out.println("  Anotaciones imprescindibles:");
        System.out.println("    • @Tag        → En el Controller: agrupa y describe la sección.");
        System.out.println("    • @Operation  → En el método: explica qué hace la acción.");
        System.out.println("    • @ApiResponse→ Describe códigos HTTP devueltos (200, 201, 404...).");
        System.out.println("    • @Schema     → En DTOs: describe campos, formatos y ejemplos.");
        System.out.println();
        System.out.println("═══════════════════════════════════════════════════════════════════════");
    }
}
