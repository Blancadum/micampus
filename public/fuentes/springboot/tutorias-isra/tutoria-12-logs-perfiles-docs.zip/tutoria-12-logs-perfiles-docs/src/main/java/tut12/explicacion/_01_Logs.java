package tut12.explicacion;

import lombok.extern.slf4j.Slf4j;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 1: SISTEMA DE REGISTRO (LOGGING) CON SLF4J Y LOMBOK
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * ¿QUÉ ES SLF4J Y LOGBACK?
 * ────────────────────────
 * • SLF4J (Simple Logging Facade for Java): Es una INTERFAZ/FACHADA. Define
 *   métodos estándar como log.info(), log.error().
 * • Logback: Es la IMPLEMENTACIÓN REAL por defecto de Spring Boot que escribe
 *   en pantalla o en ficheros de texto rotativos.
 *
 * ¿CÓMO INYECTA LOMBOK EL LOGGER?
 * ───────────────────────────────
 * Al colocar @Slf4j encima de una clase, Lombok genera entre bambalinas:
 *
 *   private static final org.slf4j.Logger log =
 *       org.slf4j.LoggerFactory.getLogger(MiClase.class);
 *
 * ¡Te ahorras escribir esa línea en cada clase de tu proyecto!
 *
 *
 * LOS 5 NIVELES DE GRAVEDAD:
 * ──────────────────────────
 * 1. TRACE : Detalles a nivel microscópico (variables internas en bucles).
 * 2. DEBUG : Diagnóstico técnico útil durante el desarrollo.
 * 3. INFO  : Acontecimientos normales y saludables del sistema (arranque, login).
 * 4. WARN  : Situación anómala pero la aplicación puede continuar (reintento, parámetro deprecado).
 * 5. ERROR : Fallo grave que impidió completar la operación (excepción, fallo en BBDD).
 *
 * UMBRAL DE FILTRADO:
 * Si configuras el nivel en INFO:
 *   TRACE y DEBUG se ignoran por completo (no consumen CPU ni ensucian consola).
 *   INFO, WARN y ERROR se muestran.
 */
@Slf4j
public class _01_Logs {

    public static void main(String[] args) {
        String idProducto = "PROD-9812";
        double precio = 49.99;

        // ✅ REGLA DE ORO 1: Uso de placeholders {}
        // En vez de: log.info("Producto: " + idProducto + " precio: " + precio);
        // Usamos:
        log.info("Cargando producto ID {} con precio {}", idProducto, precio);

        // ¿Por qué es mejor {} que concatenar con '+'?
        // Porque si el nivel DEBUG está apagado, la concatenación '+' crearía cadenas
        // innecesarias en la memoria RAM. Con {}, SLF4J ni siquiera calcula el texto.

        // ✅ REGLA DE ORO 2: Registro de excepciones
        try {
            simularFallo();
        } catch (Exception ex) {
            // El último parámetro puede ser la excepción directa: Logback imprime
            // automáticamente la traza de error completa (stack trace).
            log.error("Fallo crítico al procesar el producto {}: {}", idProducto, ex.getMessage(), ex);
        }
    }

    private static void simularFallo() {
        throw new IllegalStateException("Servicio externo de pagos no disponible");
    }
}
