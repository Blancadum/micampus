package tut12.avanzado;

/**
 * [AVANZADO] OpenAPI con seguridad (JWT) y otras anotaciones útiles
 * ═════════════════════════════════════════════════════════════════
 * No aplicado en esta demo (no usa Spring Security): son plantillas de referencia.
 *
 * 1. EL PROBLEMA: SWAGGER UI + SPRING SECURITY = 403
 * ──────────────────────────────────────────────────
 * Con Spring Security y JWT, al abrir Swagger UI y pulsar "Execute": 403. Dos cosas distintas:
 *   • La página de Swagger UI se carga; lo que falla son las llamadas a los endpoints,
 *     que piden token.
 *   • Hay que decirle a Swagger que existe un token y dejar que lo envíes.
 * Sin Spring Security todo funciona sin configurar nada más.
 *
 * 2. LA SOLUCIÓN, EN 3 PASOS
 * ──────────────────────────
 * a) Declarar el esquema de seguridad (@SecurityScheme) -> ver _03_Documentacion_OpenAPI.java,
 *    apartado 6 (name, description, type=HTTP, paramName=Authorization, in=HEADER,
 *    scheme="bearer", bearerFormat="JWT").
 * b) Aplicarlo en @OpenAPIDefinition(security = @SecurityRequirement(name = "Security Token")).
 *    El name debe ser el MISMO que el del @SecurityScheme.
 * c) En Swagger UI: llamar al endpoint de login (el que devuelve el token) -> copiar el token
 *    (solo el valor, sin comillas ni llaves) -> botón "Authorize" -> pegarlo -> Close.
 *    Las llamadas siguientes ya llevan Authorization: Bearer <token>.
 * Detalles:
 *   • Hay que reiniciar la aplicación tras cambiar la configuración, y recargar la página.
 *   • El token caduca: si vuelve el 403, pide uno nuevo.
 *
 * Alcance del candado: con security en @OpenAPIDefinition se aplica a TODOS los endpoints. Para
 * que algunos no lo pidan (el login, p. ej.): @SecurityRequirements({}) en ese método.
 * Y para el caso contrario (solo algunos): quitarlo del @OpenAPIDefinition y poner en cada
 * método @SecurityRequirement(name = "Security Token").
 *
 * 3. OTRAS ANOTACIONES ÚTILES DE OPENAPI
 * ──────────────────────────────────────
 * • @Hidden: Oculta un controlador o método de Swagger UI (ej: endpoints internos de administración o salud).
 * • @Parameter(description = "...", example = "..."): Documenta parámetros en URL (@PathVariable o @RequestParam).
 * • @RequestBody(description = "...", required = true): Documenta el payload esperado.
 * • @ArraySchema: Para respuestas que son colecciones (List<T>).
 */
public class _02_OpenAPI_Seguridad {
}
