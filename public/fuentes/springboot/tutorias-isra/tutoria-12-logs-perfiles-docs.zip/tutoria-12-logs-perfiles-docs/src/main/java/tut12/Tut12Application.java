package tut12;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tut12Application {

    public static void main(String[] args) {
        SpringApplication.run(Tut12Application.class, args);
    }
}
