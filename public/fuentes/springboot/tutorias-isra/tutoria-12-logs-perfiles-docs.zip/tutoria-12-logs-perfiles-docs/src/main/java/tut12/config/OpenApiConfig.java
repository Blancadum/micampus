package tut12.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("API de Catálogo de Productos")
                        .version("1.0.0")
                        .description("Tutoría 12: Demostración de logs, perfiles y OpenAPI 3 con Swagger UI.")
                        .contact(new Contact()
                                .name("Tutoría Spring Boot")
                                .email("formacion@accenture.es")))
                .servers(List.of(
                        new Server().url("http://localhost:8080").description("Servidor Local (Desarrollo)")
                ));
    }
}
