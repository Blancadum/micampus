package tut12.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

/**
 * Este componente SOLO se ejecuta cuando el perfil activo es 'dev'.
 * Demuestra el uso de @Profile("dev") y cómo los logs informan del arranque.
 */
@Slf4j
@Component
@Profile("dev")
public class InicializadorDatosDev implements CommandLineRunner {

    @Override
    public void run(String... args) {
        log.info("⚙️ [PERFIL DEV ACTIVO] Inicializando datos semilla en memoria...");
        log.debug("-> Insertando producto de prueba: Portátil Gamer (Stock: 15)");
        log.debug("-> Insertando producto de prueba: Teclado Mecánico (Stock: 30)");
        log.info("✅ Datos de prueba cargados correctamente para desarrollo local.");
    }
}
