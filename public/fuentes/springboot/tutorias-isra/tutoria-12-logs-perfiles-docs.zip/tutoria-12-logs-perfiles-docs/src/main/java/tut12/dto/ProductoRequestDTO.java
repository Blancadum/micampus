package tut12.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(description = "DTO de solicitud para dar de alta o actualizar un producto")
public class ProductoRequestDTO {

    @Schema(description = "Nombre comercial del producto", example = "Monitor Gaming 27 pulgadas", requiredMode = Schema.RequiredMode.REQUIRED)
    @NotBlank(message = "El nombre es obligatorio")
    @Size(min = 3, max = 80, message = "El nombre debe tener entre 3 y 80 caracteres")
    private String nombre;

    @Schema(description = "Categoría a la que pertenece", example = "INFORMÁTICA")
    @NotBlank(message = "La categoría es obligatoria")
    private String categoria;

    @Schema(description = "Precio unitario en euros", example = "299.99", requiredMode = Schema.RequiredMode.REQUIRED)
    @NotNull(message = "El precio es obligatorio")
    @Positive(message = "El precio debe ser superior a 0")
    private Double precio;

    @Schema(description = "Unidades disponibles en almacén", example = "25")
    @NotNull(message = "El stock es obligatorio")
    @Positive(message = "El stock debe ser un entero positivo")
    private Integer stock;
}
