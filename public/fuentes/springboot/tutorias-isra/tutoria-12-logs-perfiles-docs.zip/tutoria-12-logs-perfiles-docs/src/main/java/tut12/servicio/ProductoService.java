package tut12.servicio;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import tut12.dto.ProductoRequestDTO;
import tut12.dto.ProductoResponseDTO;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Servicio de lógica de negocio para la gestión de productos.
 * 
 * 💡 NOTA ARQUITECTÓNICA SOBRE DOCUMENTACIÓN:
 * En la Capa de Servicio (@Service) NO se usan anotaciones de Swagger/OpenAPI.
 * La documentación aquí se realiza mediante JAVADOC (comentarios /** ... * /),
 * pensados para los desarrolladores Java que mantienen las reglas de negocio.
 */
@Slf4j
@Service
public class ProductoService {

    // Simulación de base de datos en memoria para el ejercicio
    private final Map<Long, ProductoResponseDTO> almacenamiento = new ConcurrentHashMap<>();
    private final AtomicLong contadorId = new AtomicLong(1);

    public ProductoService() {
        guardarSemilla("Portátil Pro 16", "INFORMÁTICA", 1299.99, 10);
        guardarSemilla("Ratón Inalámbrico", "PERIFÉRICOS", 34.50, 45);
    }

    private void guardarSemilla(String nombre, String categoria, double precio, int stock) {
        long id = contadorId.getAndIncrement();
        almacenamiento.put(id, new ProductoResponseDTO(id, nombre, categoria, precio, stock, LocalDateTime.now()));
    }

    /**
     * Recupera la totalidad de los artículos registrados en el catálogo.
     * 
     * @return Lista inmutable o copiada con todos los productos disponibles.
     */
    public List<ProductoResponseDTO> listarTodos() {
        log.debug("Consultando el listado total de productos. Total en memoria: {}", almacenamiento.size());
        return new ArrayList<>(almacenamiento.values());
    }

    /**
     * Busca un producto por su clave primaria única.
     * 
     * @param id Identificador numérico del producto a consultar.
     * @return Un {@link Optional} que contiene el producto si existe, o vacío en caso contrario.
     */
    public Optional<ProductoResponseDTO> buscarPorId(Long id) {
        log.debug("Buscando producto por identificador: {}", id);
        Optional<ProductoResponseDTO> encontrado = Optional.ofNullable(almacenamiento.get(id));

        if (encontrado.isEmpty()) {
            log.warn("⚠️ Producto con ID {} no fue encontrado en el catálogo", id);
        } else {
            log.info("Producto con ID {} recuperado con éxito", id);
        }
        return encontrado;
    }

    /**
     * Registra un nuevo producto en el catálogo tras validar los datos.
     * 
     * @param dto Objeto con los datos de entrada del producto a crear.
     * @return Instancia del producto creado con su ID autogenerado y fecha de registro.
     * @throws IllegalArgumentException Si el producto no cumple las reglas de negocio.
     */
    public ProductoResponseDTO crear(ProductoRequestDTO dto) {
        log.info("Iniciando creación de nuevo producto: '{}' (Categoría: {})", dto.getNombre(), dto.getCategoria());

        long nuevoId = contadorId.getAndIncrement();
        ProductoResponseDTO nuevo = ProductoResponseDTO.builder()
                .id(nuevoId)
                .nombre(dto.getNombre())
                .categoria(dto.getCategoria())
                .precio(dto.getPrecio())
                .stock(dto.getStock())
                .fechaCreacion(LocalDateTime.now())
                .build();

        almacenamiento.put(nuevoId, nuevo);
        log.info("✅ Producto creado satisfactoriamente con ID asignado: {}", nuevoId);
        return nuevo;
    }

    /**
     * Da de baja un producto del catálogo por su ID.
     * 
     * @param id Identificador del producto a eliminar.
     * @return {@code true} si el producto existía y fue eliminado; {@code false} en caso contrario.
     */
    public boolean eliminar(Long id) {
        log.warn("Solicitud de eliminación para el producto ID: {}", id);
        ProductoResponseDTO borrado = almacenamiento.remove(id);
        if (borrado != null) {
            log.info("Producto ID {} eliminado correctamente", id);
            return true;
        } else {
            log.warn("Intento de borrado fallido: el producto ID {} no existía", id);
            return false;
        }
    }
}
