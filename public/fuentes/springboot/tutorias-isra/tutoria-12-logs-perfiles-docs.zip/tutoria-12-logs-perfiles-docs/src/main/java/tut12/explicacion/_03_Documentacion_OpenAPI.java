package tut12.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 3: DOCUMENTACIÓN CON OPENAPI 3 / SWAGGER UI vs JAVADOC
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * 1. SWAGGER (OPENAPI) vs JAVADOC: ¿CUÁNDO Y EN QUÉ CAPA SE USA CADA UNO?
 * ───────────────────────────────────────────────────────────────────────
 *
 *                         [ Frontend / Postman / Cliente Externo ]
 *                                       │
 *                                       ▼ (Documentado con SWAGGER / OPENAPI)
 *    CAPA PRESENTACIÓN     ┌────────────────────────┐
 *                          │    @RestController     │  <-- @Tag, @Operation, @ApiResponse
 *                          │          DTOs          │  <-- @Schema
 *                          └───────────┬────────────┘
 *                                      │
 *                                      ▼ (Documentado con JAVADOC)
 *    CAPA NEGOCIO          ┌────────────────────────┐
 *                          │        @Service        │  <-- Comentarios Javadoc (/** ... * /)
 *                          │     (Lógica pura)      │      con @param, @return, @throws
 *                          └───────────┬────────────┘
 *                                      │
 *    CAPA PERSISTENCIA     ┌───────────▼────────────┐
 *                          │ @Repository / Entidad  │  <-- Javadoc opcional
 *                          └────────────────────────┘
 *
 * • SWAGGER / OPENAPI 3:
 *   - Audiencia: Quien CONSUME la API desde fuera (React, Angular, app móvil, clientes).
 *   - Capa obligatoria: EXCLUSIVAMENTE en Controladores (@RestController) y DTOs.
 *   - Por qué: Describe el contrato HTTP (rutas, verbos, parámetros de URL, JSON y códigos 200/404).
 *   - Regla de oro: NUNCA pongas anotaciones de Swagger en un @Service ni en una @Entity.
 *
 * • JAVADOC:
 *   - Audiencia: El PROGRAMADOR Java del equipo que lee, modifica o depura el código fuente.
 *   - Capa principal: Capa de Servicio (@Service), Interfaces, algoritmos y clases de utilidad.
 *   - Por qué: Explica QUÉ hace un método Java, qué parámetros espera (@param), qué devuelve
 *     (@return) y qué excepciones puede lanzar (@throws) sin tener que leerse 100 líneas de código.
 *   - Ventaja: Al pasar el cursor por encima en el IDE (VS Code o IntelliJ), muestra la ventanita
 *     de ayuda con la documentación al instante.
 *
 *
 * 2. DIFERENCIA CONCEPTUAL: OPENAPI vs SWAGGER
 * ────────────────────────────────────────────
 * • OpenAPI 3 : Es la ESPECIFICACIÓN formal estándar de la industria (un archivo JSON o YAML
 *               que describe de forma agnóstica qué endpoints existen).
 * • Swagger   : Es el conjunto de herramientas que implementan la especificación.
 *               La más famosa es SWAGGER UI, una página web interactiva generada
 *               directamente a partir de ese JSON.
 *
 *
 * 3. INTEGRACIÓN CON SPRING BOOT 3 (LIBRERÍA SPRINGDOC):
 * ──────────────────────────────────────────────────────
 * En Spring Boot 3 NO se usa el antiguo 'Springfox' (está abandonado).
 * Se usa 'springdoc-openapi-starter-webmvc-ui':
 *
 *   <dependency>
 *       <groupId>org.springdoc</groupId>
 *       <artifactId>springdoc-openapi-starter-webmvc-ui</artifactId>
 *       <version>2.3.0</version>
 *   </dependency>
 *
 * ¡Solo con meter esta dependencia, al arrancar ya tienes Swagger funcionando!
 *   👉 http://localhost:8080/swagger-ui.html
 *   👉 http://localhost:8080/v3/api-docs
 *
 *
 * 4. ANOTACIONES FUNDAMENTALES DE OPENAPI:
 * ─────────────────────────────────────────
 *
 * A) A NIVEL DE CONTROLADOR (@RestController):
 *    @Tag(name = "Productos", description = "Gestión del catálogo de artículos")
 *
 * B) A NIVEL DE MÉTODO (@GetMapping, @PostMapping...):
 *    @Operation(summary = "Obtener producto por ID", description = "Devuelve los datos del artículo")
 *    @ApiResponses({
 *        @ApiResponse(responseCode = "200", description = "Producto encontrado"),
 *        @ApiResponse(responseCode = "404", description = "Producto no encontrado")
 *    })
 *
 * C) A NIVEL DE DTOs / MODELOS:
 *    @Schema(description = "Nombre comercial del producto", example = "Monitor 4K 27 pulgadas")
 *    private String nombre;
 */
public class _03_Documentacion_OpenAPI {
}
