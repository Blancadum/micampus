package tut12.excepcion;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Schema(description = "Estructura estandarizada de error devuelta por la API")
public class ErrorResponse {

    @Schema(description = "Momento temporal en que ocurrió el error", example = "2026-10-13T12:00:00")
    private LocalDateTime timestamp;

    @Schema(description = "Código de estado HTTP", example = "400")
    private int status;

    @Schema(description = "Nombre formal del estado HTTP", example = "Bad Request")
    private String error;

    @Schema(description = "Descripción detallada del motivo del fallo", example = "El nombre es obligatorio")
    private String mensaje;
}
