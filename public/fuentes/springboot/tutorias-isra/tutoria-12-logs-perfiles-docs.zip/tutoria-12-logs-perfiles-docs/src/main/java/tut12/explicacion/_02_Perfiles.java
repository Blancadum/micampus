package tut12.explicacion;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 2: PERFILES DE CONFIGURACIÓN (PROFILES)
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * EL PROBLEMA QUE RESUELVEN:
 * ──────────────────────────
 * Nunca querrás que el código de desarrollo se conecte a la base de datos real
 * de producción, ni querrás en producción que la consola se llene de logs DEBUG
 * o que Swagger quede abierto a hackers.
 *
 * CONVENCIÓN DE NOMBRES EN SPRING BOOT:
 * ─────────────────────────────────────
 * • application.yml / properties          → Configuración común base.
 * • application-{perfil}.yml / properties → Configuración específica que sobreescribe la base.
 *
 * Ejemplos:
 *   - application-dev.yml   (desarrollo en tu portátil)
 *   - application-test.yml  (ejecución de tests automáticos en CI/CD)
 *   - application-prod.yml  (servidor de producción en la nube)
 *
 *
 * ¿CÓMO ACTIVAR UN PERFIL?
 * ────────────────────────
 * 1. En application.yml:
 *      spring:
 *        profiles:
 *          active: dev
 *
 * 2. Por variable de entorno del sistema operativo (lo habitual en Kubernetes/Docker):
 *      SPRING_PROFILES_ACTIVE=prod
 *
 * 3. Como argumento de la línea de comandos al ejecutar el .jar:
 *      java -jar app.jar --spring.profiles.active=prod
 *
 * 4. En IntelliJ / Eclipse / VS Code:
 *      Configurando "Active profiles: dev" en las opciones de arranque (Run/Debug Configuration).
 *
 *
 * LA ANOTACIÓN @Profile EN JAVA:
 * ──────────────────────────────
 * Permite que componentes enteros solo existan si un perfil está activo:
 *
 *   @Component
 *   @Profile("dev")
 *   public class CreadorDatosDePrueba implements CommandLineRunner {
 *       // Solo se ejecuta en desarrollo para rellenar datos falsos
 *   }
 *
 *   @Service
 *   @Profile("prod")
 *   public class ServicioEmailReal implements ServicioEmail { ... }
 *
 *   @Service
 *   @Profile("dev")
 *   public class ServicioEmailSimulado implements ServicioEmail { ... }
 */
public class _02_Perfiles {
    // Clase conceptual de referencia.
}
