package tut12.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Schema(description = "DTO de respuesta con los datos completos del producto")
public class ProductoResponseDTO {

    @Schema(description = "Identificador único asignado por el sistema", example = "1")
    private Long id;

    @Schema(description = "Nombre comercial del producto", example = "Monitor Gaming 27 pulgadas")
    private String nombre;

    @Schema(description = "Categoría del producto", example = "INFORMÁTICA")
    private String categoria;

    @Schema(description = "Precio actual en euros", example = "299.99")
    private Double precio;

    @Schema(description = "Unidades disponibles", example = "25")
    private Integer stock;

    @Schema(description = "Fecha y hora de registro", example = "2026-10-13T12:00:00")
    private LocalDateTime fechaCreacion;
}
