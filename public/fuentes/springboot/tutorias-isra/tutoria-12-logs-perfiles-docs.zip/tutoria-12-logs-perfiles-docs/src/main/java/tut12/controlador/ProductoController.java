package tut12.controlador;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tut12.dto.ProductoRequestDTO;
import tut12.dto.ProductoResponseDTO;
import tut12.servicio.ProductoService;

import java.util.List;

@Slf4j
@RestController
@RequestMapping("/api/v1/productos")
@Tag(name = "Productos", description = "Endpoints de gestión y consulta del catálogo de productos")
public class ProductoController {

    private final ProductoService productoService;

    public ProductoController(ProductoService productoService) {
        this.productoService = productoService;
    }

    @GetMapping
    @Operation(summary = "Listar catálogo completo", description = "Retorna una lista con todos los productos registrados en el sistema")
    @ApiResponse(responseCode = "200", description = "Listado devuelto con éxito")
    public ResponseEntity<List<ProductoResponseDTO>> obtenerTodos() {
        log.info("Petición GET /api/v1/productos recibida");
        return ResponseEntity.ok(productoService.listarTodos());
    }

    @GetMapping("/{id}")
    @Operation(summary = "Buscar producto por ID", description = "Devuelve el detalle de un producto a partir de su ID numérico")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Producto localizado"),
            @ApiResponse(responseCode = "404", description = "Producto no encontrado")
    })
    public ResponseEntity<ProductoResponseDTO> obtenerPorId(
            @Parameter(description = "Identificador único del producto", example = "1", required = true)
            @PathVariable Long id) {
        log.info("Petición GET /api/v1/productos/{} recibida", id);
        return productoService.buscarPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @Operation(summary = "Crear nuevo producto", description = "Valida y da de alta un producto en el catálogo")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Producto registrado con éxito"),
            @ApiResponse(responseCode = "400", description = "Datos de entrada inválidos")
    })
    public ResponseEntity<ProductoResponseDTO> crear(
            @Valid @RequestBody ProductoRequestDTO peticion) {
        log.info("Petición POST /api/v1/productos recibida para el producto '{}'", peticion.getNombre());
        ProductoResponseDTO creado = productoService.crear(peticion);
        return ResponseEntity.status(HttpStatus.CREATED).body(creado);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Eliminar un producto", description = "Borra el producto correspondiente al ID indicado")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Producto eliminado con éxito"),
            @ApiResponse(responseCode = "404", description = "No se encontró el producto a eliminar")
    })
    public ResponseEntity<Void> eliminar(
            @Parameter(description = "ID del producto a eliminar", example = "1")
            @PathVariable Long id) {
        log.warn("Petición DELETE /api/v1/productos/{} recibida", id);
        boolean borrado = productoService.eliminar(id);
        if (borrado) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
}
