package tut12.avanzado;

/**
 * ══════════════════════════════════════════════════════════════════════════════════════
 * [AVANZADO] Perfiles de Maven + empaquetar solo la configuración de un entorno + YAML
 * ══════════════════════════════════════════════════════════════════════════════════════
 *
 * 1. LA IDEA: DOS PERFILES, UNO DE SPRING Y OTRO DE MAVEN
 * ───────────────────────────────────────────────────────────
 * Perfil de Spring (apartado anterior): el .jar lleva TODOS los application-*.properties y
 * se elige el activo al ejecutar.
 * Perfil de Maven (este fichero): al COMPILAR se decide qué perfil se mete en el .jar, y el
 * .jar de producción no contiene ni una propiedad de desarrollo (más limpio y seguro: queda
 * separado de los demás ambientes).
 *
 *
 * 2. ¿POR QUÉ "SE PISAN" LOS PERFILES? (HERENCIA EN CASCADA)
 * ───────────────────────────────────────────────────────────
 * Una duda constante: ¿Por qué cuando activo un perfil se sobreescriben valores?
 *
 * Los perfiles funcionan por SOBRESCRITURA SELECTIVA (Override en cascada):
 *   1. Tienes un fichero BASE común (application.yml o propiedades generales en pom.xml).
 *      Aquí defines lo que comparten todos los entornos (ej: nombre de app, zonas horarias).
 *   2. Al activar un perfil (ej: "prod" con application-prod.yml), las propiedades de
 *      ese perfil TIENEN MAYOR PRIORIDAD y "PISAN" a las del fichero base.
 *
 * Ventaja brutal:
 *   NO tienes que reescribir las 50 propiedades comunes de la aplicación.
 *   Solo redefines las 3 o 4 que cambian (puerto, URL de BBDD, credenciales).
 *   Lo que no toques en el perfil específico se hereda intacto de la base.
 *
 *
 * 3. PASO A PASO (pom.xml)
 * ────────────────────────
 * a) Un bloque <profiles> con un <profile> por entorno, con su id y una propiedad:
 *
 *    <profiles>
 *      <profile>
 *        <id>dev</id>
 *        <activation><activeByDefault>true</activeByDefault></activation>
 *        <properties><build.profile.id>dev</build.profile.id></properties>
 *        <build>... excluir lo de prod (ver c) ...</build>
 *      </profile>
 *      <profile>
 *        <id>prod</id>
 *        <activation><activeByDefault>false</activeByDefault></activation>
 *        <properties><build.profile.id>prod</build.profile.id></properties>
 *        <build>... excluir lo de dev ...</build>
 *      </profile>
 *    </profiles>
 *
 *    activeByDefault=true -> es el perfil que se usa si no indicas otro (dev en true y prod
 *    en false; si cambias, recarga el pom). Al pedir -P prod, el de por defecto se desactiva
 *    solo: no hace falta tocar el pom.
 *
 * b) Filtrado de recursos (filtering) en el <build> principal:
 *    Permite sustituir variables tipo @build.profile.id@ en application.yml durante el build.
 *
 * c) Exclusión de ficheros en el <build> del profile:
 *    En el profile 'dev':
 *      <resources>
 *        <resource>
 *          <directory>src/main/resources</directory>
 *          <excludes>
 *            <exclude>application-prod.yml</exclude>
 *          </excludes>
 *        </resource>
 *      </resources>
 *    En el profile 'prod':
 *      <resources>
 *        <resource>
 *          <directory>src/main/resources</directory>
 *          <excludes>
 *            <exclude>application-dev.yml</exclude>
 *          </excludes>
 *        </resource>
 *      </resources>
 *
 *
 * 4. RELACIÓN CON JENKINS Y CI/CD (INTEGRACIÓN CONTINUA)
 * ──────────────────────────────────────────────────────
 * En una empresa tú nunca compilas a mano el .jar de producción en tu portátil.
 *
 * El flujo profesional con Jenkins / GitHub Actions:
 *   1. El desarrollador hace git push a la rama 'release' o 'main'.
 *   2. Jenkins despierta automáticamente y descarga el código limpio.
 *   3. Pasa los tests unitarios: mvn test
 *   4. Si pasan, Jenkins ejecuta el empaquetado del perfil de producción:
 *        mvn clean package -P prod -DskipTests=false
 *   5. Maven lee el perfil 'prod':
 *      -> Excluye application-dev.yml y credenciales de prueba.
 *      -> Deja únicamente la configuración de producción.
 *   6. Jenkins toma ese .jar limpio y seguro y lo despliega al servidor / Kubernetes.
 *   7. Además, Jenkins inyecta contraseñas reales desde su almacén de credenciales
 *      (Jenkins Credentials / Vault) como variables de entorno, evitando que nadie
 *      las suba a Git.
 *
 *
 * 5. EJECUCIÓN CON MAVEN
 * ──────────────────────
 * Compilar para desarrollo (por defecto):
 *   mvn clean package
 *
 * Compilar para producción:
 *   mvn clean package -P prod
 *
 *
 * 6. COMBINACIÓN CON YAML
 * ───────────────────────
 * YAML es más jerárquico y limpio que .properties:
 *   spring:
 *     profiles:
 *       active: @build.profile.id@
 */
public class _01_Perfiles_Maven_YAML {
}
