package tut03;

/**
 * Ejecuta esta clase para ver el mapa conceptual de la Tutoría 3.
 */
public class _00_Resumen {

    public static void main(String[] args) {

        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  TUTORÍA 3 — MAVEN + LOMBOK");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // 1. MAVEN
        // ════════════════════════════════════════════════════════════════════
        System.out.println("1. MAVEN — Qué hace por ti");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  Gestión de dependencias  → declaras Jackson, Spring, etc. en pom.xml");
        System.out.println("                             Maven las descarga de Maven Central");
        System.out.println("  Build automatizado       → mvn clean install → compila + testa + empaqueta");
        System.out.println("  Estructura estándar      → src/main/java  src/test/java  src/main/resources");
        System.out.println();
        System.out.println("  Ciclo de vida (fases que más usarás):");
        System.out.println("  validate → compile → test → package → verify → install → deploy");
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // 2. pom.xml
        // ════════════════════════════════════════════════════════════════════
        System.out.println("2. pom.xml — La configuración de tu proyecto");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  <parent>        → hereda configuración (Spring Boot BOM)");
        System.out.println("  <dependencies>  → librerías que usas");
        System.out.println("  <properties>    → versión Java, encoding...");
        System.out.println("  <build>         → plugins (Surefire, Failsafe...)");
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // 3. LOMBOK
        // ════════════════════════════════════════════════════════════════════
        System.out.println("3. LOMBOK — Las anotaciones que más usarás");
        System.out.println("───────────────────────────────────────────────────────────────────────");
        System.out.println("  @Getter / @Setter    → genera getters y setters");
        System.out.println("  @NoArgsConstructor   → constructor vacío");
        System.out.println("  @AllArgsConstructor  → constructor con todos los campos");
        System.out.println("  @Builder             → patrón Builder");
        System.out.println("  @Data                → @Getter + @Setter + @ToString + @EqualsAndHashCode");
        System.out.println("  @Slf4j               → variable 'log' lista para usar");
        System.out.println();
        System.out.println("  ⚠️  @Data en entidades JPA: CUIDADO con @EqualsAndHashCode");
        System.out.println("      (puede causar bucles en relaciones bidireccionales)");
        System.out.println();

        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  Demo ejecutable: _03_Lombok_Demo.java");
        System.out.println("  Preguntas tipo test: Preguntas.java");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
    }
}
