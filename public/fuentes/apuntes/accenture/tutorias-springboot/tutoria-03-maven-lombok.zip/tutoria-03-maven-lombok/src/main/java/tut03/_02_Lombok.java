package tut03;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 2: LOMBOK — Eliminar boilerplate en clases Java
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *
 * ¿QUÉ ES LOMBOK?
 * ───────────────
 * Librería que genera código boilerplate en TIEMPO DE COMPILACIÓN
 * a través de anotaciones. Nunca ves el código generado en el .java,
 * pero sí está en el .class.
 *
 *
 * EL PROBLEMA QUE RESUELVE
 * ────────────────────────
 * Una clase Java simple con 5 campos requiere escribir:
 *   - 5 getters
 *   - 5 setters
 *   - 1 constructor vacío
 *   - 1 constructor con todos los parámetros
 *   - toString()
 *   - equals() y hashCode()
 *
 * → ~80 líneas de código para representar 5 campos.
 *
 * Con Lombok: esas 80 líneas se reemplazan con 3 anotaciones.
 *
 *
 * LAS ANOTACIONES MÁS USADAS
 * ───────────────────────────
 *
 *   @Getter          → genera getter para todos los campos (o uno si va en el campo)
 *   @Setter          → genera setter para todos los campos
 *   @NoArgsConstructor  → genera constructor vacío  public Empleado() {}
 *   @AllArgsConstructor → genera constructor con todos los parámetros
 *   @RequiredArgsConstructor → constructor con campos final / @NonNull
 *   @ToString        → genera toString() con todos los campos
 *   @EqualsAndHashCode → genera equals() y hashCode() basados en los campos
 *
 *   @Data            → equivale a: @Getter + @Setter + @ToString
 *                                  + @EqualsAndHashCode + @RequiredArgsConstructor
 *
 *   @Builder         → implementa el patrón Builder
 *   @Slf4j           → inyecta  private static final Logger log = ...
 *   @Value           → clase inmutable (todos los campos final + solo getters)
 *
 *
 * EJEMPLO SIN LOMBOK (la forma antigua)
 * ───────────────────────────────────────
 *
 *   public class Empleado {
 *       private Long id;
 *       private String nombre;
 *       private String departamento;
 *       private Double salario;
 *
 *       public Empleado() {}
 *
 *       public Empleado(Long id, String nombre, String departamento, Double salario) {
 *           this.id = id; this.nombre = nombre;
 *           this.departamento = departamento; this.salario = salario;
 *       }
 *
 *       public Long getId() { return id; }
 *       public void setId(Long id) { this.id = id; }
 *       public String getNombre() { return nombre; }
 *       // ... 6 getters/setters más ...
 *
 *       @Override public String toString() { ... }
 *       @Override public boolean equals(Object o) { ... }
 *       @Override public int hashCode() { ... }
 *   }
 *
 *
 * EJEMPLO CON LOMBOK (la forma actual)
 * ──────────────────────────────────────
 *
 *   @Data
 *   @NoArgsConstructor
 *   @AllArgsConstructor
 *   public class Empleado {
 *       private Long id;
 *       private String nombre;
 *       private String departamento;
 *       private Double salario;
 *   }
 *
 *   → Mismo resultado, 4 líneas en vez de ~50.
 *
 *
 * @BUILDER — PATRÓN BUILDER
 * ──────────────────────────
 * Permite crear objetos con una sintaxis fluida y legible,
 * especialmente útil cuando una clase tiene muchos campos opcionales.
 *
 *   @Builder
 *   public class Empleado { ... }
 *
 *   // Uso:
 *   Empleado emp = Empleado.builder()
 *       .nombre("Ana García")
 *       .departamento("IT")
 *       .salario(45000.0)
 *       .build();
 *
 *   → No necesitas recordar el orden de los parámetros del constructor.
 *   → Los campos no especificados quedan null (o con valor por defecto).
 *
 *
 * @SLF4J — LOGS SIN BOILERPLATE
 * ───────────────────────────────
 * Sin Lombok:
 *   private static final Logger log = LoggerFactory.getLogger(MiClase.class);
 *
 * Con @Slf4j (en la clase):
 *   log.info("Procesando empleado: {}", empleado.getNombre());
 *   log.error("Error al procesar: {}", e.getMessage());
 *   log.debug("Estado interno: {}", estado);
 *
 *
 * ⚠️ ADVERTENCIA: @DATA EN ENTIDADES JPA
 * ─────────────────────────────────────────
 * @Data incluye @EqualsAndHashCode que genera equals() basado en TODOS los campos.
 * En entidades JPA con relaciones (listas de hijos), esto provoca:
 *
 *   → Bucles infinitos al serializar a JSON (padre → hijos → padre → hijos...)
 *   → StackOverflowError en toString() si hay relaciones bidireccionales
 *
 *   SOLUCIÓN en entidades JPA:
 *   - Usar @Getter + @Setter + @NoArgsConstructor + @AllArgsConstructor
 *     (sin @EqualsAndHashCode)
 *   - O @EqualsAndHashCode(onlyExplicitlyIncluded = true) y marcar solo el id
 *
 * En Spring Boot, con entidades JPA, la práctica recomendada es
 * NO usar @Data en entidades → usarlo solo en DTOs.
 *
 * Nota breve: hoy también existe `record` como alternativa moderna para
 * DTOs inmutables simples. Aquí mantenemos el foco en Lombok.
 *
 * Si quieres el detalle comparativo (record vs Lombok) revisa:
 *   tut03.avanzado._02_Record_Avanzado
 *
 *
 * PREREQUISITO: PLUGIN EN EL IDE
 * ────────────────────────────────
 * Lombok requiere un plugin en el IDE para que el IDE "vea" el código generado:
 *   - IntelliJ IDEA: plugin "Lombok" (preinstalado en versiones recientes)
 *   - VS Code: extensión "Lombok Annotations Support"
 *
 * Sin el plugin, el IDE marca errores aunque el código compile correctamente.
 */
public class _02_Lombok {
    // Referencia conceptual. Demo ejecutable en _03_Lombok_Demo.java
}
