package tut03.avanzado;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO] RECORD EN JAVA — Cuándo usarlo frente a Lombok
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * ⚠️ Contenido extra — no entra en el temario estándar del curso.
 *
 *
 * ¿QUÉ ES UN RECORD?
 * ───────────────────
 * Un `record` (Java 16+) es una clase de datos inmutable y compacta.
 * A partir de su cabecera, Java genera automáticamente:
 *
 *   - Constructor canónico
 *   - Getters (accesores con el nombre del componente)
 *   - equals() / hashCode()
 *   - toString()
 *
 * Ejemplo:
 *   record ProductoDTO(Long id, String nombre, Double precio) {}
 *
 *
 * ¿POR QUÉ ES RELEVANTE HOY?
 * ────────────────────────────
 * Para DTOs simples evita gran parte del boilerplate y reduce la
 * dependencia en librerías externas para tareas básicas.
 *
 *   - Menos código repetitivo
 *   - Inmutabilidad por defecto
 *   - Modelo de datos más explícito
 *   - Excelente encaje con serialización JSON (Jackson actual)
 *
 *
 * RECORD VS LOMBOK (RESUMEN PRÁCTICO)
 * ─────────────────────────────────────
 * 1) DTOs inmutables simples (request/response):
 *    → Preferir `record`.
 *
 * 2) Entidades JPA:
 *    → Usar clase tradicional (no record).
 *    Razones: ciclo de vida de entidad, proxies de Hibernate,
 *    necesidad de mutabilidad controlada y constructor vacío en muchos casos.
 *
 * 3) Construcción compleja de objetos:
 *    → Lombok `@Builder` sigue siendo muy útil.
 *
 * 4) Logging y utilidades:
 *    → Lombok `@Slf4j` y otras anotaciones siguen aportando productividad.
 *
 *
 * ESTRATEGIA RECOMENDADA EN PROYECTOS REALES
 * ───────────────────────────────────────────
 * Migración gradual y sin riesgo:
 *
 *   Paso 1: mantener entidades JPA como clases.
 *   Paso 2: migrar DTOs nuevos a record.
 *   Paso 3: refactorizar DTOs antiguos cuando se toquen por negocio.
 *   Paso 4: mantener Lombok donde aporta valor real (Builder, logs).
 *
 *
 * MENSAJE PARA CLASE
 * ───────────────────
 * "No es record o Lombok como guerra de herramientas.
 *  Es usar cada cosa donde encaja mejor: record para transporte
 *  de datos inmutables; Lombok para productividad en casos concretos."
 */
public class _02_Record_Avanzado {
    // Contenido avanzado — referencia conceptual.
}
