﻿package tut03;

/**
 * TEST DE 6 PREGUNTAS — TUTORÍA 3: MAVEN + LOMBOK
 */
public class Preguntas {

    public static void main(String[] args) {
        pregunta1();
        pregunta2();
        pregunta3();
        pregunta4();
        pregunta5();
        pregunta6();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta1() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 1                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  Ejecutas: mvn package");
        System.out.println("  ¿Qué fases del ciclo de vida se ejecutan?");
        System.out.println();
        System.out.println("  a) Solo la fase 'package'");
        System.out.println("  b) validate → compile → test → package");
        System.out.println("  c) compile → package (saltando test)");
        System.out.println("  d) package → install → deploy");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) validate → compile → test → package");
        // System.out.println("  → Ejecutar una fase ejecuta todas las anteriores.");
        // System.out.println("    Si quieres saltar tests: mvn package -DskipTests");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta2() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 2                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  Añades 'spring-boot-starter-web' al pom.xml.");
        System.out.println("  ¿Qué incluye esta dependencia?");
        System.out.println();
        System.out.println("  a) Solo Spring MVC");
        System.out.println("  b) Spring MVC + Tomcat embebido + Jackson");
        System.out.println("  c) Todo Spring: MVC + Security + Data JPA + Test");
        System.out.println("  d) Solo el servidor Tomcat");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) Spring MVC + Tomcat + Jackson");
        // System.out.println("  → Los starters agrupan dependencias relacionadas. El BOM");
        // System.out.println("    garantiza versiones compatibles entre sí.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta3() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 3                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  Tienes una entidad JPA 'Pedido' con una lista de 'Lineas'.");
        System.out.println("  Añades @Data a la entidad. ¿Qué puede pasar?");
        System.out.println();
        System.out.println("  a) Nada, @Data funciona perfectamente en entidades JPA");
        System.out.println("  b) StackOverflowError al serializar por el toString() recursivo");
        System.out.println("  c) Los getters no se generan correctamente con JPA");
        System.out.println("  d) La BBDD no puede persistir los datos");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) StackOverflowError / bucle infinito");
        // System.out.println("  → @Data incluye @ToString y @EqualsAndHashCode que pueden");
        // System.out.println("    entrar en bucle con relaciones bidireccionales JPA.");
        // System.out.println("    Usar @Data solo en DTOs, no en entidades.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta4() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 4                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  ¿Cuál es la principal ventaja de @Builder frente a un constructor?");
        System.out.println();
        System.out.println("  a) Es más rápido en ejecución");
        System.out.println("  b) Permite especificar solo los campos que necesitas,");
        System.out.println("     sin importar el orden, mejorando la legibilidad");
        System.out.println("  c) Genera código más eficiente que el constructor normal");
        System.out.println("  d) Es obligatorio cuando la clase tiene más de 5 campos");
        System.out.println();




























































        // System.out.println("  RESPUESTA: b) Legibilidad y campos opcionales");
        // System.out.println("  → Con un constructor de 10 parámetros es fácil equivocarse de orden.");
        // System.out.println("    Con builder: Objeto.builder().campo1(v1).campo3(v3).build()");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta5() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 5                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  JUnit solo debe estar disponible al ejecutar los tests,");
        System.out.println("  no en el .jar final de producción. ¿Qué scope usas?");
        System.out.println();
        System.out.println("  a) compile (por defecto)");
        System.out.println("  b) provided");
        System.out.println("  c) test");
        System.out.println("  d) runtime");
        System.out.println();




























































        // System.out.println("  RESPUESTA: c) test");
        // System.out.println("  → scope=test: la dependencia solo está disponible en src/test.");
        // System.out.println("    No aparece en el .jar final → el paquete de producción es más ligero.");
        System.out.println();
    }

    // ════════════════════════════════════════════════════════════════════════
    static void pregunta6() {
        System.out.println("┌─────────────────────────────────────────────────────────────────┐");
        System.out.println("│ PREGUNTA 6                                                     │");
        System.out.println("└─────────────────────────────────────────────────────────────────┘");
        System.out.println();
        System.out.println("  Tienes esta clase: @Getter @Setter @NoArgsConstructor");
        System.out.println("  public class Libro { private String titulo; private Double precio; }");
        System.out.println("  ¿Qué métodos genera Lombok?");
        System.out.println();
        System.out.println("  a) getTitulo(), setTitulo(), getPrecio(), setPrecio()");
        System.out.println("     + constructor vacío Libro()");
        System.out.println("  b) Solo getTitulo() y getPrecio()");
        System.out.println("  c) getTitulo(), setTitulo(), getPrecio(), setPrecio()");
        System.out.println("     + constructor vacío + toString() + equals()");
        System.out.println("  d) Todos los getters, setters, constructores y toString()");
        System.out.println();




























































        // System.out.println("  RESPUESTA: a) Solo lo que pides con las anotaciones declaradas.");
        // System.out.println("  → @Getter = getters, @Setter = setters, @NoArgsConstructor = Libro().");
        // System.out.println("    toString() y equals() requieren @ToString y @EqualsAndHashCode");
        // System.out.println("    (o @Data que los incluye todos).");
        System.out.println();
    }
}
