package tut03;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * BLOQUE 1: APACHE MAVEN — Gestión de dependencias y ciclo de vida
 * ═══════════════════════════════════════════════════════════════════════════
 *
 *
 * ¿QUÉ ES MAVEN?
 * ──────────────
 * Herramienta de build y gestión de dependencias para proyectos Java.
 * Lema: "convención sobre configuración".
 *
 * Resuelve tres problemas cotidianos:
 *
 *   1. DEPENDENCIAS: antes había que descargar JARs a mano y añadirlos al classpath.
 *      Maven descarga y gestiona automáticamente desde Maven Central.
 *
 *   2. BUILD: compilar + empaquetar + testear con un solo comando.
 *
 *   3. ESTANDARIZACIÓN: todos los proyectos Maven tienen la misma estructura.
 *      Cualquier desarrollador sabe dónde está el código, los tests, los recursos.
 *
 *
 * ESTRUCTURA ESTÁNDAR DE UN PROYECTO MAVEN
 * ─────────────────────────────────────────
 *
 *   mi-proyecto/
 *   ├── pom.xml                    ← configuración del proyecto
 *   └── src/
 *       ├── main/
 *       │   ├── java/              ← código fuente
 *       │   └── resources/         ← application.properties, XML, plantillas...
 *       └── test/
 *           ├── java/              ← tests (JUnit, Mockito...)
 *           └── resources/         ← recursos solo para tests (H2, datos de prueba...)
 *
 *
 * EL CICLO DE VIDA DE MAVEN
 * ─────────────────────────
 * Maven tiene un ciclo de vida predefinido con FASES en orden.
 * Ejecutar una fase ejecuta TODAS LAS ANTERIORES primero.
 *
 *   validate   → verifica que el pom.xml es correcto
 *       ↓
 *   compile    → compila el código fuente → target/classes
 *       ↓
 *   test       → ejecuta los tests unitarios
 *       ↓
 *   package    → crea el .jar o .war → target/
 *       ↓
 *   verify     → ejecuta tests de integración
 *       ↓
 *   install    → instala el .jar en el repositorio local (~/.m2)
 *       ↓
 *   deploy     → publica en repositorio remoto (Nexus, Artifactory...)
 *
 *
 * COMANDOS MÁS USADOS
 * ─────────────────────
 *   mvn clean            → elimina target/ (limpia compilados anteriores)
 *   mvn compile          → compila el código fuente
 *   mvn test             → ejecuta tests unitarios
 *   mvn package          → compila + testa + empaqueta (.jar)
 *   mvn clean install    → clean + todas las fases hasta install
 *   mvn clean install -DskipTests  → igual pero sin ejecutar tests
 *   mvn spring-boot:run  → arranca el servidor Spring Boot embebido
 *
 *
 * EL ARCHIVO pom.xml
 * ────────────────────
 * "Project Object Model" — describe el proyecto en XML.
 *
 *   <?xml version="1.0" encoding="UTF-8"?>
 *   <project>
 *       <!-- Identificador único del proyecto -->
 *       <groupId>com.miprojecto</groupId>
 *       <artifactId>mi-api</artifactId>
 *       <version>1.0.0</version>
 *
 *       <!-- Hereda configuración de Spring Boot (BOM — Bill of Materials) -->
 *       <parent>
 *           <groupId>org.springframework.boot</groupId>
 *           <artifactId>spring-boot-starter-parent</artifactId>
 *           <version>3.3.0</version>
 *       </parent>
 *
 *       <!-- Propiedades del proyecto -->
 *       <properties>
 *           <java.version>17</java.version>
 *       </properties>
 *
 *       <!-- Dependencias -->
 *       <dependencies>
 *           <dependency>
 *               <groupId>org.springframework.boot</groupId>
 *               <artifactId>spring-boot-starter-web</artifactId>
 *               <!-- sin <version>: la hereda del parent (BOM) -->
 *           </dependency>
 *       </dependencies>
 *   </project>
 *
 *
 * STARTERS DE SPRING BOOT — QUÉ SON
 * ────────────────────────────────────
 * Un starter es una dependencia que agrupa todo lo necesario para una funcionalidad.
 *
 *   spring-boot-starter-web  → Spring MVC + Tomcat embebido + Jackson
 *   spring-boot-starter-data-jpa → JPA + Hibernate + autoconfiguración
 *   spring-boot-starter-security → Spring Security completo
 *   spring-boot-starter-test → JUnit 5 + Mockito + AssertJ
 *
 * En vez de declarar 5-10 dependencias individuales, declaras UN starter
 * y el BOM gestiona las versiones compatibles entre sí.
 *
 *
 * SCOPES DE DEPENDENCIAS
 * ───────────────────────
 *   compile  (default) → disponible en compilación y runtime
 *   provided           → el contenedor lo provee (ej: Servlet API en servidor externo)
 *   test               → solo para tests (JUnit, Mockito)
 *   runtime            → solo en runtime, no en compilación (drivers JDBC)
 */
public class _01_Maven {
    // Referencia conceptual.
}
