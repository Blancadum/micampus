package tut03.avanzado;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * [AVANZADO] MAVEN — Multi-module y Maven Wrapper
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * ⚠️ Contenido extra — no entra en el temario estándar del curso.
 *
 *
 * PROYECTO MULTI-MODULE
 * ──────────────────────
 * En proyectos grandes, se divide el código en múltiples módulos Maven.
 * Cada módulo es un sub-proyecto con su propio pom.xml.
 *
 *   empresa-app/                    ← POM padre (packaging=pom)
 *   ├── pom.xml                     ← declara los módulos hijos
 *   ├── empresa-api/                ← módulo 1: DTOs compartidos
 *   │   ├── pom.xml
 *   │   └── src/
 *   ├── empresa-service/            ← módulo 2: lógica de negocio
 *   │   ├── pom.xml                 ← depende de empresa-api
 *   │   └── src/
 *   └── empresa-web/                ← módulo 3: Spring Boot app
 *       ├── pom.xml                 ← depende de empresa-service
 *       └── src/
 *
 *   Ventajas:
 *   → Separación de responsabilidades a nivel de artefacto
 *   → Compilación incremental (solo recompila lo que cambió)
 *   → Reutilización entre proyectos (empresa-api puede publicarse en Nexus)
 *
 *
 * MAVEN WRAPPER (mvnw)
 * ─────────────────────
 * Un script que garantiza que todos los desarrolladores usan la misma
 * versión de Maven, sin necesidad de instalarlo globalmente.
 *
 *   ./mvnw clean install        ← en Linux/Mac
 *   mvnw.cmd clean install      ← en Windows
 *
 * Spring Initializr genera el wrapper automáticamente. En proyectos de empresa
 * es estándar usar el wrapper para garantizar builds reproducibles en CI/CD.
 *
 *
 * BOM — BILL OF MATERIALS
 * ────────────────────────
 * El `spring-boot-starter-parent` es un BOM especial que define
 * las versiones de CIENTOS de dependencias compatibles con esa versión de Spring Boot.
 *
 * Si declaras `spring-boot-starter-web` sin `<version>`, Maven la toma del BOM.
 * El BOM garantiza que Jackson, Hibernate, Tomcat, etc. son versiones compatibles.
 *
 * Sin BOM: tendrías que gestionar manualmente que
 * Jackson 2.17 es compatible con Spring 6.1 que usa Hibernate 6.4...
 *
 *
 * GRADLE — LA ALTERNATIVA
 * ────────────────────────
 * Gradle usa scripts en Groovy o Kotlin en vez de XML.
 *
 *   Maven:   pom.xml (verbose, declarativo)
 *   Gradle:  build.gradle o build.gradle.kts (conciso, imperativo/declarativo)
 *
 *   dependencies {
 *       implementation 'org.springframework.boot:spring-boot-starter-web'
 *       testImplementation 'org.springframework.boot:spring-boot-starter-test'
 *   }
 *
 * Gradle es más rápido en proyectos grandes (builds incrementales mejores).
 * El curso usa Maven. Gradle sigue la misma lógica con diferente sintaxis.
 */
public class _01_Maven_Avanzado {
    // Contenido avanzado — referencia conceptual.
}
