package tut03;

import lombok.*;
import lombok.extern.slf4j.Slf4j;

/**
 * ═══════════════════════════════════════════════════════════════════════════
 * DEMO EJECUTABLE: LOMBOK — Anotaciones en acción
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Ejecuta esta clase para ver Lombok en funcionamiento.
 * En tiempo de compilación, Lombok genera el código que nunca escribiste.
 *
 * Requiere: dependencia lombok en pom.xml + plugin Lombok en el IDE.
 */
@Slf4j  // genera: private static final Logger log = LoggerFactory.getLogger(_03_Lombok_Demo.class);
public class _03_Lombok_Demo {

    // ── @Data — el más completo ───────────────────────────────────────────────
    // Genera: @Getter + @Setter + @ToString + @EqualsAndHashCode + @RequiredArgsConstructor
    // ⚠️ No usar en entidades JPA — ver _02_Lombok.java
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    static class EmpleadoDTO {
        private Long id;
        private String nombre;
        private String departamento;
        private Double salario;
    }

    // ── @Builder — construcción fluida ───────────────────────────────────────
    @Builder
    @Getter
    @ToString
    static class Proyecto {
        private Long id;
        private String nombre;
        private String cliente;
        private Integer duracionMeses;
        private boolean activo;
    }

    // ── @Value — objeto inmutable ─────────────────────────────────────────────
    // Todos los campos son final, solo genera getters (no setters)
    @Value
    static class ConfiguracionApp {
        String host;
        int puerto;
        String entorno;
    }

    // ────────────────────────────────────────────────────────────────────────

    public static void main(String[] args) {

        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  LOMBOK DEMO");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // @Data: getters, setters, toString, equals/hashCode
        // ════════════════════════════════════════════════════════════════════
        System.out.println("1. @Data — EmpleadoDTO");
        System.out.println("─".repeat(55));

        EmpleadoDTO emp1 = new EmpleadoDTO(1L, "Ana García", "IT", 45000.0);
        EmpleadoDTO emp2 = new EmpleadoDTO();  // constructor vacío
        emp2.setId(2L);
        emp2.setNombre("Luis Martínez");
        emp2.setDepartamento("RRHH");
        emp2.setSalario(38000.0);

        System.out.println("emp1 → " + emp1);  // toString() generado por Lombok
        System.out.println("emp2 → " + emp2);
        System.out.println("emp1.getNombre() → " + emp1.getNombre());  // getter generado
        System.out.println("emp1.equals(emp2) → " + emp1.equals(emp2)); // equals generado
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // @Builder: construcción fluida, sin recordar orden de parámetros
        // ════════════════════════════════════════════════════════════════════
        System.out.println("2. @Builder — Proyecto");
        System.out.println("─".repeat(55));

        Proyecto proyecto = Proyecto.builder()
                .id(10L)
                .nombre("Migración a Cloud")
                .cliente("Acme Corp")
                .duracionMeses(6)
                .activo(true)
                .build();

        System.out.println("Proyecto → " + proyecto);
        System.out.println("Nombre → " + proyecto.getNombre());

        // Un proyecto sin cliente (campo opcional)
        Proyecto sinCliente = Proyecto.builder()
                .id(11L)
                .nombre("Proyecto interno")
                .activo(false)
                .build();
        System.out.println("Sin cliente → " + sinCliente);
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // @Value: objeto inmutable — no hay setters
        // ════════════════════════════════════════════════════════════════════
        System.out.println("3. @Value — ConfiguracionApp (inmutable)");
        System.out.println("─".repeat(55));

        ConfiguracionApp config = new ConfiguracionApp("localhost", 8080, "DEV");
        System.out.println("Config → " + config);
        System.out.println("Host → " + config.getHost());
        // config.setHost("otro")  // ← NO compila: no hay setters
        System.out.println();

        // ════════════════════════════════════════════════════════════════════
        // @Slf4j: variable 'log' lista para usar (definida en la clase)
        // ════════════════════════════════════════════════════════════════════
        System.out.println("4. @Slf4j — Logs sin boilerplate");
        System.out.println("─".repeat(55));

        log.info("Aplicación iniciada en entorno: {}", config.getEntorno());
        log.debug("Empleado cargado: {}", emp1.getNombre());
        log.warn("Salario bajo umbral recomendado para: {}", emp2.getNombre());

        System.out.println("(Ver los mensajes de log por encima de este bloque)");
        System.out.println();

        System.out.println("═══════════════════════════════════════════════════════════════════════");
        System.out.println("  Sin Lombok: ~120 líneas de boilerplate. Con Lombok: 12 anotaciones.");
        System.out.println("═══════════════════════════════════════════════════════════════════════");
    }
}
